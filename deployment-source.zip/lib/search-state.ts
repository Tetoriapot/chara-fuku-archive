import {
  ageGroupFromExactAge,
  extractSearchKeywords,
  parseCharacterQuery,
} from "@/lib/search";
import { emptySearchFilters, filterOptions, type SearchFilters } from "@/lib/search-filters";

export type SearchParamSource = URLSearchParams | Record<string, string | string[] | undefined>;

const filterKeys = ["ageGroup", "lifeStage", "gender", "season", "scene", "style", "occupation"] as const;

function readValue(source: SearchParamSource, key: string) {
  if (source instanceof URLSearchParams) return source.get(key) ?? "";
  const value = source[key];
  return Array.isArray(value) ? value[0] ?? "" : value ?? "";
}

function hasKey(source: SearchParamSource, key: string) {
  if (source instanceof URLSearchParams) return source.has(key);
  return Object.prototype.hasOwnProperty.call(source, key);
}

function allowed(value: string, options: readonly string[]) {
  return options.includes(value) ? value : "";
}

export function readSearchState(source: SearchParamSource) {
  const query = readValue(source, "q");
  const parsed = parseCharacterQuery(query);
  const hasStructuredFilters = ["exactAge", ...filterKeys].some((key) => hasKey(source, key));
  if (!hasStructuredFilters) return { query, filters: parsed };

  const filters: SearchFilters = { ...emptySearchFilters, ...parsed };
  if (hasKey(source, "exactAge")) {
    const exactAgeRaw = readValue(source, "exactAge");
    const exactAgeNumber = exactAgeRaw === "" ? null : Number(exactAgeRaw);
    filters.exactAge = Number.isInteger(exactAgeNumber) && exactAgeNumber !== null && exactAgeNumber >= 0 && exactAgeNumber <= 99
      ? exactAgeNumber
      : null;
    filters.ageGroup = ageGroupFromExactAge(filters.exactAge);
  } else if (hasKey(source, "ageGroup")) {
    filters.exactAge = null;
    filters.ageGroup = allowed(readValue(source, "ageGroup"), filterOptions.ageGroups);
  }

  const optionFilters: [keyof Pick<SearchFilters, "lifeStage" | "gender" | "season" | "scene" | "style">, readonly string[]][] = [
    ["lifeStage", filterOptions.lifeStages],
    ["gender", filterOptions.genders],
    ["season", filterOptions.seasons],
    ["scene", filterOptions.scenes],
    ["style", filterOptions.styles],
  ];
  optionFilters.forEach(([key, options]) => {
    if (hasKey(source, key)) filters[key] = allowed(readValue(source, key), options);
  });
  if (hasKey(source, "occupation")) filters.occupation = readValue(source, "occupation").slice(0, 40);

  const residualQuery = extractSearchKeywords(query, parsed).join(" ");
  return { query: residualQuery, filters };
}

export function buildSearchPath(query: string, filters: SearchFilters, includeStructuredFilters = true) {
  const params = new URLSearchParams();
  if (query.trim()) params.set("q", query.trim());

  if (includeStructuredFilters) {
    if (filters.exactAge !== null) params.set("exactAge", String(filters.exactAge));
    filterKeys.forEach((key) => {
      const value = filters[key];
      if (value) params.set(key, value);
    });
  }

  const search = params.toString();
  return search ? `/search?${search}` : "/search";
}
