import { ageGroupFromExactAge, emptySearchFilters, filterOptions, type SearchFilters } from "@/lib/search-filters";
import {
  CHARACTER_BOARD_LIBRARY_VERSION,
  CHARACTER_BOARD_VERSION,
  MAX_BOARD_BRANDS,
  MAX_BOARD_OUTFITS,
  MAX_CHARACTER_BOARDS,
} from "@/lib/board-constants";

export {
  CHARACTER_BOARD_ACTIVE_STORAGE_KEY,
  CHARACTER_BOARD_CHANGE_EVENT,
  CHARACTER_BOARD_LIBRARY_STORAGE_KEY,
  CHARACTER_BOARD_LIBRARY_VERSION,
  CHARACTER_BOARD_STORAGE_KEY,
  CHARACTER_BOARD_VERSION,
  MAX_BOARD_BRANDS,
  MAX_BOARD_OUTFITS,
  MAX_CHARACTER_BOARDS,
} from "@/lib/board-constants";

const MAX_FRAGMENT_LENGTH = 64_000;
const DEFAULT_BOARD_ID = "local-character-board";
const BOARD_ID_PATTERN = /^[a-zA-Z0-9_-]+$/;
const base64Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

export type CharacterBoard = {
  version: typeof CHARACTER_BOARD_VERSION;
  id: string;
  name: string;
  premise: string;
  filters: SearchFilters;
  brandSlugs: string[];
  outfitIds: string[];
  brandReasons: Record<string, string>;
  note: string;
  updatedAt: string;
};

export type CharacterBoardLibrary = {
  version: typeof CHARACTER_BOARD_LIBRARY_VERSION;
  activeBoardId: string;
  boards: CharacterBoard[];
};

export type BoardCatalog = {
  brandSlugs?: Iterable<string>;
  outfitIds?: Iterable<string>;
};

export type BoardNormalizationResult = {
  board: CharacterBoard;
  staleBrandSlugs: string[];
  staleOutfitIds: string[];
  recovered: boolean;
};

export type CharacterBoardLibraryNormalizationResult = {
  library: CharacterBoardLibrary;
  staleBrandSlugs: string[];
  staleOutfitIds: string[];
  recovered: boolean;
};

export type BoardDecodeResult = BoardNormalizationResult & {
  error: "" | "missing" | "invalid" | "too-large";
};

export type BoardLibraryMutationReason =
  | "created"
  | "duplicated"
  | "deleted"
  | "selected"
  | "imported"
  | "existing"
  | "limit"
  | "missing"
  | "last-reset"
  | "reset";

export type BoardLibraryMutationResult = {
  library: CharacterBoardLibrary;
  changed: boolean;
  reason: BoardLibraryMutationReason;
  boardId?: string;
};

export type BoardIdFactory = () => string;

type MutationOptions = {
  idFactory?: BoardIdFactory;
  now?: string;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function limitedString(value: unknown, maxLength: number) {
  return typeof value === "string" ? value.slice(0, maxLength) : "";
}

function allowed(value: unknown, options: readonly string[]) {
  return typeof value === "string" && options.includes(value) ? value : "";
}

function normalizeFilters(value: unknown): SearchFilters {
  if (!isRecord(value)) return { ...emptySearchFilters };
  const exactAge = typeof value.exactAge === "number" && Number.isInteger(value.exactAge) && value.exactAge >= 0 && value.exactAge <= 99
    ? value.exactAge
    : null;

  return {
    exactAge,
    ageGroup: exactAge === null ? allowed(value.ageGroup, filterOptions.ageGroups) : ageGroupFromExactAge(exactAge),
    lifeStage: allowed(value.lifeStage, filterOptions.lifeStages),
    gender: allowed(value.gender, filterOptions.genders),
    season: allowed(value.season, filterOptions.seasons),
    scene: allowed(value.scene, filterOptions.scenes),
    style: allowed(value.style, filterOptions.styles),
    occupation: limitedString(value.occupation, 40),
  };
}

function normalizeIdList(
  value: unknown,
  max: number,
  knownValues?: Iterable<string>,
) {
  const known = knownValues ? new Set(knownValues) : null;
  const stale: string[] = [];
  const valid: string[] = [];
  const candidates = Array.isArray(value) ? value : [];

  for (const item of candidates) {
    if (typeof item !== "string" || !item || item.length > 100 || !BOARD_ID_PATTERN.test(item)) continue;
    if (known && !known.has(item)) {
      if (!stale.includes(item)) stale.push(item);
      continue;
    }
    if (!valid.includes(item) && valid.length < max) valid.push(item);
  }

  return { valid, stale };
}

function validUpdatedAt(value: unknown) {
  if (typeof value !== "string" || value.length > 40 || Number.isNaN(Date.parse(value))) return new Date(0).toISOString();
  return value;
}

function serializedEquals(left: unknown, right: unknown) {
  try {
    return JSON.stringify(left) === JSON.stringify(right);
  } catch {
    return false;
  }
}

function addUnique(target: string[], values: Iterable<string>) {
  for (const value of values) {
    if (!target.includes(value)) target.push(value);
  }
}

function validLibraryBoardId(value: unknown): value is string {
  return typeof value === "string" && value.length > 0 && value.length <= 100 && BOARD_ID_PATTERN.test(value);
}

function deterministicLibraryBoardId(value: unknown, index: number, used: Set<string>) {
  const requested = validLibraryBoardId(value) ? value : `board-${index + 1}`;
  if (!used.has(requested)) return requested;
  let suffix = 2;
  while (suffix <= MAX_CHARACTER_BOARDS + 1) {
    const suffixText = `-${suffix}`;
    const candidate = `${requested.slice(0, 100 - suffixText.length)}${suffixText}`;
    if (!used.has(candidate)) return candidate;
    suffix += 1;
  }
  return `board-${index + 1}-${suffix}`.slice(0, 100);
}

function normalizedNow(value?: string) {
  return value && !Number.isNaN(Date.parse(value)) ? value : new Date().toISOString();
}

export function createCharacterBoardId() {
  const uuid = typeof globalThis.crypto?.randomUUID === "function"
    ? globalThis.crypto.randomUUID()
    : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  return `board-${uuid}`.slice(0, 100);
}

function uniqueFreshBoardId(boards: readonly CharacterBoard[], idFactory: BoardIdFactory = createCharacterBoardId) {
  const used = new Set(boards.map((board) => board.id));
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const candidate = idFactory();
    if (validLibraryBoardId(candidate) && !used.has(candidate)) return candidate;
  }
  let suffix = boards.length + 1;
  while (used.has(`board-${suffix}`)) suffix += 1;
  return `board-${suffix}`;
}

export function createEmptyCharacterBoard(id = DEFAULT_BOARD_ID): CharacterBoard {
  return {
    version: CHARACTER_BOARD_VERSION,
    id,
    name: "",
    premise: "",
    filters: { ...emptySearchFilters },
    brandSlugs: [],
    outfitIds: [],
    brandReasons: {},
    note: "",
    updatedAt: new Date(0).toISOString(),
  };
}

export function createEmptyCharacterBoardLibrary(): CharacterBoardLibrary {
  const board = createEmptyCharacterBoard();
  return {
    version: CHARACTER_BOARD_LIBRARY_VERSION,
    activeBoardId: board.id,
    boards: [board],
  };
}

export function normalizeCharacterBoard(value: unknown, catalog: BoardCatalog = {}): BoardNormalizationResult {
  const fallback = createEmptyCharacterBoard();
  if (!isRecord(value)) {
    return { board: fallback, staleBrandSlugs: [], staleOutfitIds: [], recovered: value !== null && value !== undefined };
  }

  const normalizedBrands = normalizeIdList(value.brandSlugs, MAX_BOARD_BRANDS, catalog.brandSlugs);
  const normalizedOutfits = normalizeIdList(value.outfitIds, MAX_BOARD_OUTFITS, catalog.outfitIds);
  const rawReasons = isRecord(value.brandReasons) ? value.brandReasons : {};
  const brandReasons = Object.fromEntries(
    normalizedBrands.valid
      .map((slug) => [slug, limitedString(rawReasons[slug], 600)] as const)
      .filter(([, reason]) => reason.length > 0),
  );
  const board: CharacterBoard = {
    version: CHARACTER_BOARD_VERSION,
    id: limitedString(value.id, 100) || DEFAULT_BOARD_ID,
    name: limitedString(value.name, 80),
    premise: limitedString(value.premise, 400),
    filters: normalizeFilters(value.filters),
    brandSlugs: normalizedBrands.valid,
    outfitIds: normalizedOutfits.valid,
    brandReasons,
    note: limitedString(value.note, 8_000),
    updatedAt: validUpdatedAt(value.updatedAt),
  };

  const recovered = value.version !== CHARACTER_BOARD_VERSION ||
    !serializedEquals(board, value) ||
    normalizedBrands.stale.length > 0 ||
    normalizedOutfits.stale.length > 0;

  return {
    board,
    staleBrandSlugs: normalizedBrands.stale,
    staleOutfitIds: normalizedOutfits.stale,
    recovered,
  };
}

export function parseCharacterBoard(raw: string | null | undefined, catalog: BoardCatalog = {}): BoardNormalizationResult {
  if (!raw) return normalizeCharacterBoard(null, catalog);
  try {
    return normalizeCharacterBoard(JSON.parse(raw) as unknown, catalog);
  } catch {
    return { ...normalizeCharacterBoard(null, catalog), recovered: true };
  }
}

export function normalizeCharacterBoardLibrary(value: unknown, catalog: BoardCatalog = {}): CharacterBoardLibraryNormalizationResult {
  const fallback = createEmptyCharacterBoardLibrary();
  if (!isRecord(value)) {
    return {
      library: fallback,
      staleBrandSlugs: [],
      staleOutfitIds: [],
      recovered: value !== null && value !== undefined,
    };
  }

  const staleBrandSlugs: string[] = [];
  const staleOutfitIds: string[] = [];
  const boards: CharacterBoard[] = [];
  const usedIds = new Set<string>();
  const candidates = Array.isArray(value.boards) ? value.boards.slice(0, MAX_CHARACTER_BOARDS) : [];
  let nestedRecovery = !Array.isArray(value.boards) || (Array.isArray(value.boards) && value.boards.length > MAX_CHARACTER_BOARDS);

  candidates.forEach((candidate, index) => {
    if (!isRecord(candidate)) {
      nestedRecovery = true;
      return;
    }
    const normalized = normalizeCharacterBoard(candidate, catalog);
    const id = deterministicLibraryBoardId(normalized.board.id, index, usedIds);
    usedIds.add(id);
    boards.push(id === normalized.board.id ? normalized.board : { ...normalized.board, id });
    addUnique(staleBrandSlugs, normalized.staleBrandSlugs);
    addUnique(staleOutfitIds, normalized.staleOutfitIds);
    nestedRecovery ||= normalized.recovered || id !== normalized.board.id;
  });

  if (!boards.length) {
    boards.push(fallback.boards[0]);
    nestedRecovery = true;
  }

  const requestedActiveId = limitedString(value.activeBoardId, 100);
  const activeBoardId = boards.some((board) => board.id === requestedActiveId) ? requestedActiveId : boards[0].id;
  const library: CharacterBoardLibrary = {
    version: CHARACTER_BOARD_LIBRARY_VERSION,
    activeBoardId,
    boards,
  };

  return {
    library,
    staleBrandSlugs,
    staleOutfitIds,
    recovered: value.version !== CHARACTER_BOARD_LIBRARY_VERSION ||
      nestedRecovery ||
      !serializedEquals(library, value),
  };
}

export function parseCharacterBoardLibrary(raw: string | null | undefined, catalog: BoardCatalog = {}): CharacterBoardLibraryNormalizationResult {
  if (!raw) return normalizeCharacterBoardLibrary(null, catalog);
  try {
    return normalizeCharacterBoardLibrary(JSON.parse(raw) as unknown, catalog);
  } catch {
    return { ...normalizeCharacterBoardLibrary(null, catalog), recovered: true };
  }
}

function insertAfterActive(library: CharacterBoardLibrary, board: CharacterBoard) {
  const boards = [...library.boards];
  const activeIndex = boards.findIndex((item) => item.id === library.activeBoardId);
  boards.splice(activeIndex < 0 ? boards.length : activeIndex + 1, 0, board);
  return boards;
}

export function createCharacterBoardInLibrary(
  value: CharacterBoardLibrary,
  options: MutationOptions = {},
): BoardLibraryMutationResult {
  const library = normalizeCharacterBoardLibrary(value).library;
  if (library.boards.length >= MAX_CHARACTER_BOARDS) return { library, changed: false, reason: "limit" };
  const boardId = uniqueFreshBoardId(library.boards, options.idFactory);
  const board = { ...createEmptyCharacterBoard(boardId), updatedAt: normalizedNow(options.now) };
  return {
    library: {
      ...library,
      activeBoardId: boardId,
      boards: insertAfterActive(library, board),
    },
    changed: true,
    reason: "created",
    boardId,
  };
}

export function duplicateCharacterBoardInLibrary(
  value: CharacterBoardLibrary,
  boardId: string,
  options: MutationOptions = {},
): BoardLibraryMutationResult {
  const library = normalizeCharacterBoardLibrary(value).library;
  const source = library.boards.find((board) => board.id === boardId);
  if (!source) return { library, changed: false, reason: "missing", boardId };
  if (library.boards.length >= MAX_CHARACTER_BOARDS) return { library, changed: false, reason: "limit", boardId };
  const duplicateId = uniqueFreshBoardId(library.boards, options.idFactory);
  const duplicate: CharacterBoard = {
    ...source,
    id: duplicateId,
    name: `${source.name || "名称未設定"}のコピー`.slice(0, 80),
    filters: { ...source.filters },
    brandSlugs: [...source.brandSlugs],
    outfitIds: [...source.outfitIds],
    brandReasons: { ...source.brandReasons },
    updatedAt: normalizedNow(options.now),
  };
  const sourceIndex = library.boards.findIndex((board) => board.id === boardId);
  const boards = [...library.boards];
  boards.splice(sourceIndex + 1, 0, duplicate);
  return {
    library: { ...library, activeBoardId: duplicateId, boards },
    changed: true,
    reason: "duplicated",
    boardId: duplicateId,
  };
}

export function deleteCharacterBoardFromLibrary(
  value: CharacterBoardLibrary,
  boardId: string,
  options: MutationOptions = {},
): BoardLibraryMutationResult {
  const library = normalizeCharacterBoardLibrary(value).library;
  const index = library.boards.findIndex((board) => board.id === boardId);
  if (index < 0) return { library, changed: false, reason: "missing", boardId };

  if (library.boards.length === 1) {
    const replacementId = uniqueFreshBoardId(library.boards, options.idFactory);
    const replacement = { ...createEmptyCharacterBoard(replacementId), updatedAt: normalizedNow(options.now) };
    return {
      library: { ...library, activeBoardId: replacementId, boards: [replacement] },
      changed: true,
      reason: "last-reset",
      boardId: replacementId,
    };
  }

  const boards = library.boards.filter((board) => board.id !== boardId);
  const activeBoardId = library.activeBoardId === boardId
    ? boards[Math.min(index, boards.length - 1)].id
    : library.activeBoardId;
  return {
    library: { ...library, activeBoardId, boards },
    changed: true,
    reason: "deleted",
    boardId: activeBoardId,
  };
}

export function selectCharacterBoardInLibrary(
  value: CharacterBoardLibrary,
  boardId: string,
): BoardLibraryMutationResult {
  const library = normalizeCharacterBoardLibrary(value).library;
  if (!library.boards.some((board) => board.id === boardId)) return { library, changed: false, reason: "missing", boardId };
  if (library.activeBoardId === boardId) return { library, changed: false, reason: "existing", boardId };
  return {
    library: { ...library, activeBoardId: boardId },
    changed: true,
    reason: "selected",
    boardId,
  };
}

function comparableBoard(board: CharacterBoard) {
  return JSON.stringify({ ...board, id: "", updatedAt: "" });
}

export function importCharacterBoardIntoLibrary(
  value: CharacterBoardLibrary,
  importedValue: unknown,
  catalog: BoardCatalog = {},
  options: MutationOptions = {},
): BoardLibraryMutationResult {
  const library = normalizeCharacterBoardLibrary(value, catalog).library;
  const imported = normalizeCharacterBoard(importedValue, catalog).board;
  const existing = library.boards.find((board) => comparableBoard(board) === comparableBoard(imported));
  if (existing) return { library, changed: false, reason: "existing", boardId: existing.id };
  if (library.boards.length >= MAX_CHARACTER_BOARDS) return { library, changed: false, reason: "limit" };

  const boardId = uniqueFreshBoardId(library.boards, options.idFactory);
  const board: CharacterBoard = {
    ...imported,
    id: boardId,
    filters: { ...imported.filters },
    brandSlugs: [...imported.brandSlugs],
    outfitIds: [...imported.outfitIds],
    brandReasons: { ...imported.brandReasons },
    updatedAt: normalizedNow(options.now),
  };
  return {
    library: {
      ...library,
      activeBoardId: boardId,
      boards: insertAfterActive(library, board),
    },
    changed: true,
    reason: "imported",
    boardId,
  };
}

export function resetCharacterBoardInLibrary(
  value: CharacterBoardLibrary,
  boardId: string,
  options: Pick<MutationOptions, "now"> = {},
): BoardLibraryMutationResult {
  const library = normalizeCharacterBoardLibrary(value).library;
  const index = library.boards.findIndex((board) => board.id === boardId);
  if (index < 0) return { library, changed: false, reason: "missing", boardId };
  const boards = [...library.boards];
  boards[index] = { ...createEmptyCharacterBoard(boardId), updatedAt: normalizedNow(options.now) };
  return {
    library: { ...library, activeBoardId: boardId, boards },
    changed: true,
    reason: "reset",
    boardId,
  };
}

function encodeBase64(bytes: Uint8Array) {
  let output = "";
  for (let index = 0; index < bytes.length; index += 3) {
    const first = bytes[index];
    const second = bytes[index + 1];
    const third = bytes[index + 2];
    const value = (first << 16) | ((second ?? 0) << 8) | (third ?? 0);
    output += base64Alphabet[(value >> 18) & 63];
    output += base64Alphabet[(value >> 12) & 63];
    output += second === undefined ? "=" : base64Alphabet[(value >> 6) & 63];
    output += third === undefined ? "=" : base64Alphabet[value & 63];
  }
  return output;
}

function decodeBase64(value: string) {
  const normalized = value.replaceAll("-", "+").replaceAll("_", "/");
  if (!normalized || !/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) throw new Error("invalid base64url");
  const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, "=");
  const bytes: number[] = [];
  for (let index = 0; index < padded.length; index += 4) {
    const block = padded.slice(index, index + 4);
    const values = [...block].map((character) => character === "=" ? 0 : base64Alphabet.indexOf(character));
    if (values.some((item) => item < 0)) throw new Error("invalid base64url");
    const decoded = (values[0] << 18) | (values[1] << 12) | (values[2] << 6) | values[3];
    bytes.push((decoded >> 16) & 255);
    if (block[2] !== "=") bytes.push((decoded >> 8) & 255);
    if (block[3] !== "=") bytes.push(decoded & 255);
  }
  return new Uint8Array(bytes);
}

export function encodeCharacterBoard(board: CharacterBoard) {
  const normalized = normalizeCharacterBoard(board).board;
  const encoded = encodeBase64(new TextEncoder().encode(JSON.stringify(normalized)));
  return encoded.replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/, "");
}

export function encodeCharacterBoardFragment(board: CharacterBoard) {
  return `#board=${encodeCharacterBoard(board)}`;
}

export function decodeCharacterBoardFragment(fragment: string, catalog: BoardCatalog = {}): BoardDecodeResult {
  const hash = fragment.startsWith("#") ? fragment.slice(1) : fragment;
  const encoded = new URLSearchParams(hash).get("board");
  if (!encoded) return { ...normalizeCharacterBoard(null, catalog), error: "missing" };
  if (encoded.length > MAX_FRAGMENT_LENGTH) return { ...normalizeCharacterBoard(null, catalog), recovered: true, error: "too-large" };

  try {
    const json = new TextDecoder("utf-8", { fatal: true }).decode(decodeBase64(encoded));
    return { ...normalizeCharacterBoard(JSON.parse(json) as unknown, catalog), error: "" };
  } catch {
    return { ...normalizeCharacterBoard(null, catalog), recovered: true, error: "invalid" };
  }
}
