import { brands, filterOptions, getOutfitsForBrand, type Brand } from "@/lib/brands";
import { MAX_COMPARE_BRANDS, parseCompareStorage } from "@/lib/compare-storage";

export { COMPARE_CHANGE_EVENT, COMPARE_STORAGE_KEY, MAX_COMPARE_BRANDS } from "@/lib/compare-storage";

const brandBySlug = new Map(brands.map((brand) => [brand.slug, brand]));

export type ComparePreset = {
  id: string;
  label: string;
  description: string;
  slugs: string[];
};

export const comparePresets: ComparePreset[] = [
  {
    id: "college-casual",
    label: "大学生の定番カジュアル",
    description: "通学服の価格感と雰囲気を比べる",
    slugs: ["gu", "lowrys-farm", "global-work", "niko-and"],
  },
  {
    id: "mens-campus",
    label: "男子大学生の休日服",
    description: "ストリート寄りからきれいめまで",
    slugs: ["wego", "rageblue", "sense-of-place", "beams"],
  },
  {
    id: "new-worker",
    label: "新社会人のきれいめ服",
    description: "仕事にも休日にも使いやすい4候補",
    slugs: ["uniqlo", "vis", "plst", "green-label-relaxing"],
  },
];

/** URL・端末保存値など、信頼できない入力を比較可能なslugだけに整えます。 */
export function normalizeCompareSlugs(value: unknown): string[] {
  const rawValues = Array.isArray(value) ? value : [value];
  const candidates = rawValues.flatMap((raw) =>
    typeof raw === "string" ? raw.split(",") : [],
  );

  const unique: string[] = [];
  for (const candidate of candidates) {
    const slug = candidate.trim().toLowerCase();
    if (!slug || !brandBySlug.has(slug) || unique.includes(slug)) continue;
    unique.push(slug);
    if (unique.length === MAX_COMPARE_BRANDS) break;
  }
  return unique;
}

export function parseStoredCompareSlugs(rawValue: string | null): string[] {
  return normalizeCompareSlugs(parseCompareStorage(rawValue));
}

export function getCompareBrands(slugs: readonly string[]): Brand[] {
  return normalizeCompareSlugs([...slugs])
    .map((slug) => brandBySlug.get(slug))
    .filter((brand): brand is Brand => Boolean(brand));
}

export function buildCompareHref(slugs: readonly string[]): string {
  const normalized = normalizeCompareSlugs([...slugs]);
  return normalized.length
    ? `/compare?brands=${encodeURIComponent(normalized.join(","))}`
    : "/compare";
}

export function getRegisteredOutfitSeasons(slug: string): string[] {
  const registered = new Set(getOutfitsForBrand(slug).map((outfit) => outfit.season));
  return filterOptions.seasons.filter((season) => registered.has(season));
}
