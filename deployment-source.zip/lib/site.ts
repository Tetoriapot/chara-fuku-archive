export const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://chara-fuku-archive.tetoriapot.chatgpt.site";
export const SITE_NAME = "キャラ服資料館";
export const SITE_DESCRIPTION = "年齢・性別・職業・雰囲気から、現代日本のキャラクターが着ていそうなファッションブランドとコーデ資料を探せる創作者向けサイト。";
