// Next Link adds basePath itself; browser APIs and native forms need it explicitly.
export function publicPath(path: string): string {
  const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";
  if (process.env.NEXT_PUBLIC_STATIC_EXPORT !== "true") return `${basePath}${path}`;
  const boundary = path.search(/[?#]/);
  const pathname = boundary < 0 ? path : path.slice(0, boundary);
  const suffix = boundary < 0 ? "" : path.slice(boundary);
  return `${basePath}${pathname.replace(/\/$/, "")}/${suffix}`;
}
