export type SearchFilters = {
  exactAge: number | null;
  ageGroup: string;
  lifeStage: string;
  gender: string;
  season: string;
  scene: string;
  style: string;
  occupation: string;
};

export const emptySearchFilters: SearchFilters = {
  exactAge: null,
  ageGroup: "",
  lifeStage: "",
  gender: "",
  season: "",
  scene: "",
  style: "",
  occupation: "",
};

export const filterOptions = {
  ageGroups: ["10代以下", "10代", "20代", "30代", "40代", "50代", "60代以上"],
  lifeStages: ["幼児", "小学生", "中学生", "高校生", "大学生", "新社会人", "社会人", "子育て中", "シニア"],
  genders: ["女性", "男性", "ジェンダーレス"],
  seasons: ["春", "夏", "秋", "冬"],
  scenes: ["普段着", "通勤", "通学", "デート", "フォーマル", "部屋着", "買い物", "冠婚葬祭"],
  styles: [
    "カジュアル",
    "ナチュラル",
    "ストリート",
    "韓国系",
    "量産型",
    "地雷系",
    "シンプル",
    "オフィスカジュアル",
    "きれいめ",
    "スポーティ",
    "モード",
    "アウトドア",
    "フェミニン",
    "フォーマル",
  ],
} as const;

export function ageGroupFromExactAge(age: number | null) {
  if (age === null || !Number.isInteger(age) || age < 0 || age > 99) return "";
  if (age <= 12) return "10代以下";
  if (age <= 19) return "10代";
  if (age <= 29) return "20代";
  if (age <= 39) return "30代";
  if (age <= 49) return "40代";
  if (age <= 59) return "50代";
  return "60代以上";
}
