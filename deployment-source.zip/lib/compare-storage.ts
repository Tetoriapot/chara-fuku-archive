export const MAX_COMPARE_BRANDS = 4;
export const COMPARE_STORAGE_KEY = "chara-fuku:compare-brands:v1";
export const COMPARE_CHANGE_EVENT = "chara-fuku:compare-change";

export function parseCompareStorage(rawValue: string | null) {
  if (!rawValue) return [];
  try {
    const value: unknown = JSON.parse(rawValue);
    if (!Array.isArray(value)) return [];
    return Array.from(new Set(value.filter((item): item is string => typeof item === "string" && /^[a-z0-9-]+$/.test(item)))).slice(0, MAX_COMPARE_BRANDS);
  } catch {
    return [];
  }
}
