import type { Metadata } from "next";
import { SITE_NAME } from "@/lib/site";

const socialImage = {
  url: "/og-p0.png",
  width: 1728,
  height: 910,
  alt: `${SITE_NAME} — このキャラなら何を着る？`,
};

export function buildPageSocialMetadata({ title, description, path }: { title: string; description: string; path: string }) {
  return {
    openGraph: {
      title,
      description,
      url: path,
      siteName: SITE_NAME,
      locale: "ja_JP",
      type: "website" as const,
      images: [socialImage],
    },
    twitter: {
      card: "summary_large_image" as const,
      title,
      description,
      images: ["/og-p0.png"],
    },
  } satisfies Pick<Metadata, "openGraph" | "twitter">;
}
