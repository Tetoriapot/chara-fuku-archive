import brandsData from "@/data/brands.json";
import outfitsData from "@/data/outfits.generated.json";
import { filterOptions } from "@/lib/search-filters";

export { filterOptions } from "@/lib/search-filters";

export type Confidence = "high" | "medium" | "low";

export type EditorialSource = {
  label: string;
  url: string;
  kind: "official" | "editorial";
};

export type Brand = {
  slug: string;
  name: string;
  officialUrl: string;
  logo: string;
  accent: string;
  priceLevel: number;
  priceLabel: string;
  gender: string[];
  genderNote: string;
  ageRange: string[];
  style: string[];
  scenes: string[];
  occupations: string[];
  description: string;
  creatorNote: string;
  recommendedFor: string[];
  popularItems: string[];
  tags: string[];
  related: string[];
  mapX: number;
  mapY: number;
  featured: boolean;
  sources: EditorialSource[];
  updatedAt: string;
  officialUrlCheckedAt?: string;
  confidence: Confidence;
  editorialNote: string;
};

export type OutfitParts = {
  outer?: string;
  top: string;
  bottom: string;
  shoes: string;
  bag: string;
  accessory?: string;
};

export type OutfitRecipe = {
  id: string;
  title: string;
  season: string;
  scene: string;
  ageGroups: string[];
  lifeStages: string[];
  genders: string[];
  styles: string[];
  occupations: string[];
  brandSlugs: string[];
  parts: OutfitParts;
  palette: { name: string; hex: string }[];
  materials: string[];
  silhouette: string;
  drawingTips: string[];
  prose: string;
};

type BrandInput = Omit<Brand, "sources" | "updatedAt" | "confidence" | "editorialNote"> &
  Partial<Pick<Brand, "sources" | "updatedAt" | "officialUrlCheckedAt" | "confidence" | "editorialNote">>;

export const EDITORIAL_UPDATED_AT = "2026-07-20";

const defaultEditorialNote =
  "年齢層・価格帯・人物像は、公式サイトのブランド表現と掲載商品の傾向をもとにした編集部の相対的な目安です。地域・時期・個人によって異なります。";

export const brands = (brandsData as BrandInput[]).map((brand): Brand => ({
  ...brand,
  sources: brand.sources?.length
    ? brand.sources
    : [{ label: `${brand.name} 公式サイト`, url: brand.officialUrl, kind: "official" }],
  updatedAt: brand.updatedAt ?? EDITORIAL_UPDATED_AT,
  confidence: brand.confidence ?? "medium",
  editorialNote: brand.editorialNote ?? defaultEditorialNote,
}));

export const outfits = outfitsData as OutfitRecipe[];

const outfitSeasonOrder = new Map<string, number>(
  filterOptions.seasons.map((season, index) => [season, index]),
);
const outfitsByBrandSlug = new Map<string, OutfitRecipe[]>();

for (const outfit of outfits) {
  for (const slug of new Set(outfit.brandSlugs)) {
    const indexed = outfitsByBrandSlug.get(slug);
    if (indexed) indexed.push(outfit);
    else outfitsByBrandSlug.set(slug, [outfit]);
  }
}

for (const indexed of outfitsByBrandSlug.values()) {
  indexed.sort(
    (first, second) =>
      (outfitSeasonOrder.get(first.season) ?? 9) -
      (outfitSeasonOrder.get(second.season) ?? 9),
  );
}

export function getBrand(slug: string) {
  return brands.find((brand) => brand.slug === slug);
}

export function getRelatedBrands(brand: Brand) {
  return brand.related.map(getBrand).filter((item): item is Brand => Boolean(item));
}

export function getOutfitsForBrand(slug: string) {
  return [...(outfitsByBrandSlug.get(slug) ?? [])];
}

export function getInitials(name: string) {
  const latin = name.replace(/[^A-Za-z0-9 ]/g, "").trim();
  if (!latin) return name.slice(0, 1);
  const words = latin.split(/\s+/).filter(Boolean);
  return (words.length > 1 ? words.map((word) => word[0]).join("") : latin.slice(0, 2)).slice(0, 3).toUpperCase();
}

function relativeLuminance(hex: string) {
  const normalized = hex.replace("#", "");
  if (!/^[0-9a-f]{6}$/i.test(normalized)) return null;
  const channels = [0, 2, 4].map((index) => Number.parseInt(normalized.slice(index, index + 2), 16) / 255);
  const [red, green, blue] = channels.map((channel) => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
  return 0.2126 * red + 0.7152 * green + 0.0722 * blue;
}

function contrastRatio(first: number, second: number) {
  const lighter = Math.max(first, second);
  const darker = Math.min(first, second);
  return (lighter + 0.05) / (darker + 0.05);
}

export function getContrastText(hex: string) {
  const background = relativeLuminance(hex);
  if (background === null) return "#ffffff";
  const candidates = ["#15211f", "#ffffff", "#000000"];
  return candidates.find((candidate) => {
    const foreground = relativeLuminance(candidate);
    return foreground !== null && contrastRatio(background, foreground) >= 4.5;
  }) ?? "#000000";
}
