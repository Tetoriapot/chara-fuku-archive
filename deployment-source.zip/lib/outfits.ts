import { brands, filterOptions, outfits, type OutfitRecipe } from "@/lib/brands";

export type OutfitFilters = {
  season: string;
  scene: string;
  ageGroup: string;
  lifeStage: string;
  gender: string;
  occupation: string;
  style: string;
  brandSlug: string;
};

export const emptyOutfitFilters: OutfitFilters = {
  season: "",
  scene: "",
  ageGroup: "",
  lifeStage: "",
  gender: "",
  occupation: "",
  style: "",
  brandSlug: "",
};

export const outfitRecipeCount = outfits.length;

const unique = (values: string[]) => [...new Set(values)];

function inReferenceOrder(values: string[], reference: readonly string[]) {
  const order = new Map(reference.map((value, index) => [value, index]));
  return unique(values).sort((a, b) => (order.get(a) ?? 99) - (order.get(b) ?? 99) || a.localeCompare(b, "ja"));
}

function genderMatches(values: readonly string[], gender: string) {
  return values.includes(gender) ||
    values.includes("ジェンダーレス") ||
    (gender === "ジェンダーレス" && values.includes("女性") && values.includes("男性"));
}

function occupationMatches(values: readonly string[], occupation: string) {
  return values.some((item) => item.includes(occupation) || occupation.includes(item));
}

const usedBrandSlugs = new Set(outfits.flatMap((outfit) => outfit.brandSlugs));

export const outfitFilterOptions = {
  seasons: inReferenceOrder(outfits.map((outfit) => outfit.season), filterOptions.seasons),
  scenes: inReferenceOrder(outfits.map((outfit) => outfit.scene), filterOptions.scenes),
  ageGroups: inReferenceOrder(outfits.flatMap((outfit) => outfit.ageGroups), filterOptions.ageGroups),
  lifeStages: inReferenceOrder(outfits.flatMap((outfit) => outfit.lifeStages), filterOptions.lifeStages),
  genders: inReferenceOrder(outfits.flatMap((outfit) => outfit.genders), filterOptions.genders),
  occupations: unique(outfits.flatMap((outfit) => outfit.occupations)).sort((a, b) => a.localeCompare(b, "ja")),
  styles: unique(outfits.flatMap((outfit) => outfit.styles)).sort((a, b) => a.localeCompare(b, "ja")),
  brands: brands
    .filter((brand) => usedBrandSlugs.has(brand.slug))
    .map((brand) => ({ slug: brand.slug, name: brand.name })),
};

export function filterOutfitRecipes(filters: OutfitFilters): OutfitRecipe[] {
  return outfits.filter((outfit) => {
    if (filters.season && outfit.season !== filters.season) return false;
    if (filters.scene && outfit.scene !== filters.scene) return false;
    if (filters.ageGroup && !outfit.ageGroups.includes(filters.ageGroup)) return false;
    if (filters.lifeStage && !outfit.lifeStages.includes(filters.lifeStage)) return false;
    if (filters.gender && !genderMatches(outfit.genders, filters.gender)) return false;
    if (filters.occupation && !occupationMatches(outfit.occupations, filters.occupation)) return false;
    if (filters.style && !outfit.styles.includes(filters.style)) return false;
    if (filters.brandSlug && !outfit.brandSlugs.includes(filters.brandSlug)) return false;
    return true;
  });
}

export function getOutfitBrandRecords(outfit: OutfitRecipe) {
  return outfit.brandSlugs
    .map((slug) => brands.find((brand) => brand.slug === slug))
    .filter((brand): brand is (typeof brands)[number] => Boolean(brand));
}

export function readOutfitFilters(source: Record<string, string | string[] | undefined> | URLSearchParams): OutfitFilters {
  const read = (key: string) => {
    if (source instanceof URLSearchParams) return source.get(key) ?? "";
    const value = source[key];
    return Array.isArray(value) ? value[0] ?? "" : value ?? "";
  };
  const select = (key: string, options: string[]) => {
    const value = read(key);
    return options.includes(value) ? value : "";
  };
  return {
    season: select("season", outfitFilterOptions.seasons),
    scene: select("scene", outfitFilterOptions.scenes),
    ageGroup: select("ageGroup", outfitFilterOptions.ageGroups),
    lifeStage: select("lifeStage", outfitFilterOptions.lifeStages),
    gender: select("gender", outfitFilterOptions.genders),
    occupation: read("occupation").trim().slice(0, 80),
    style: select("style", outfitFilterOptions.styles),
    brandSlug: select("brandSlug", outfitFilterOptions.brands.map((brand) => brand.slug)) || select("brand", outfitFilterOptions.brands.map((brand) => brand.slug)),
  };
}

export function buildOutfitPath(filters: OutfitFilters) {
  const params = new URLSearchParams();
  (Object.entries(filters) as [keyof OutfitFilters, string][]).forEach(([key, value]) => {
    if (value) params.set(key, value);
  });
  const search = params.toString();
  return search ? `/outfits?${search}` : "/outfits";
}
