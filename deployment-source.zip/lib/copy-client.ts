type TextControl = HTMLInputElement | HTMLTextAreaElement;

type FocusSnapshot = {
  activeElement: HTMLElement | null;
  inputSelection: {
    element: TextControl;
    start: number | null;
    end: number | null;
    direction: "forward" | "backward" | "none" | null;
  } | null;
  documentRanges: Range[];
};

function captureFocus(): FocusSnapshot {
  const activeElement = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const inputSelection = activeElement instanceof HTMLInputElement || activeElement instanceof HTMLTextAreaElement
    ? {
        element: activeElement,
        start: activeElement.selectionStart,
        end: activeElement.selectionEnd,
        direction: activeElement.selectionDirection,
      }
    : null;
  const selection = document.getSelection();
  const documentRanges = selection
    ? Array.from({ length: selection.rangeCount }, (_, index) => selection.getRangeAt(index).cloneRange())
    : [];

  return { activeElement, inputSelection, documentRanges };
}

function restoreFocus(snapshot: FocusSnapshot) {
  const { activeElement, inputSelection, documentRanges } = snapshot;

  if (activeElement?.isConnected) {
    try {
      activeElement.focus({ preventScroll: true });
    } catch {
      activeElement.focus();
    }
  }

  if (inputSelection?.element.isConnected && inputSelection.start !== null && inputSelection.end !== null) {
    try {
      inputSelection.element.setSelectionRange(inputSelection.start, inputSelection.end, inputSelection.direction ?? undefined);
    } catch {
      // type="number" など選択範囲を持たない入力では復元を省略します。
    }
    return;
  }

  if (documentRanges.length) {
    const selection = document.getSelection();
    if (!selection) return;
    selection.removeAllRanges();
    for (const range of documentRanges) {
      try {
        selection.addRange(range);
      } catch {
        // コピー中に対象ノードが消えた場合は、残りの選択範囲だけ復元します。
      }
    }
  }
}

function copyWithTemporaryField(text: string) {
  const field = document.createElement("textarea");
  field.value = text;
  field.readOnly = true;
  field.tabIndex = -1;
  field.setAttribute("aria-hidden", "true");
  Object.assign(field.style, {
    position: "fixed",
    inset: "0 auto auto 0",
    width: "2px",
    height: "2px",
    padding: "0",
    border: "0",
    opacity: "0",
    pointerEvents: "none",
  });
  document.body.appendChild(field);

  try {
    try {
      field.focus({ preventScroll: true });
    } catch {
      field.focus();
    }
    field.select();
    field.setSelectionRange(0, field.value.length);
    if (!document.execCommand("copy")) throw new Error("copy command failed");
  } finally {
    field.remove();
  }
}

/**
 * Clipboard API を優先し、利用できない環境では一時フィールドでコピーします。
 * フォールバック時も、呼び出し元のフォーカスと選択範囲を維持します。
 */
export async function copyText(text: string) {
  if (typeof document === "undefined") throw new Error("clipboard is only available in the browser");

  const focusSnapshot = captureFocus();
  try {
    if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
      try {
        await navigator.clipboard.writeText(text);
        return;
      } catch {
        // 権限拒否や非対応環境では、同期的なフォールバックを試します。
      }
    }
    copyWithTemporaryField(text);
  } finally {
    restoreFocus(focusSnapshot);
  }
}
