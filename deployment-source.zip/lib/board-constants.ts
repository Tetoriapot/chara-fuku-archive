export const CHARACTER_BOARD_VERSION = 1 as const;
/** Legacy single-board storage. Kept for a non-destructive v1 -> v2 migration. */
export const CHARACTER_BOARD_STORAGE_KEY = "character-board:v1";
export const CHARACTER_BOARD_LIBRARY_VERSION = 2 as const;
export const CHARACTER_BOARD_LIBRARY_STORAGE_KEY = "character-boards:v2";
export const CHARACTER_BOARD_ACTIVE_STORAGE_KEY = "character-boards:active:v2";
export const CHARACTER_BOARD_CHANGE_EVENT = "character-board:change";
export const MAX_CHARACTER_BOARDS = 12;
export const MAX_BOARD_BRANDS = 4;
export const MAX_BOARD_OUTFITS = 6;
