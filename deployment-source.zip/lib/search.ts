import {
  brands,
  getOutfitsForBrand,
  outfits,
  type Brand,
  type OutfitRecipe,
} from "@/lib/brands";
import { ageGroupFromExactAge, emptySearchFilters, filterOptions, type SearchFilters } from "@/lib/search-filters";

export { ageGroupFromExactAge, emptySearchFilters, type SearchFilters } from "@/lib/search-filters";

export type MatchEvidenceSource = "brand" | "outfit" | "editorial";

export type MatchReason = {
  code: string;
  condition: string;
  label: string;
  points: number;
  source: MatchEvidenceSource;
};

export type MatchCaution = {
  code: string;
  label: string;
  status: "mismatch" | "unknown";
};

export type BrandScore = {
  score: number;
  maxScore: number;
  matchPercent: number;
  matchedConditionCount: number;
  totalConditionCount: number;
  exactOutfitMatch: boolean;
  evidenceCounts: Record<MatchEvidenceSource, number>;
  reasons: MatchReason[];
  cautions: MatchCaution[];
  bestOutfit?: OutfitRecipe;
};

type OutfitStructuralCondition =
  | "ageGroup"
  | "lifeStage"
  | "gender"
  | "season"
  | "scene"
  | "style"
  | "occupation";

export type OutfitSearchMatch = {
  outfit: OutfitRecipe;
  matchedConditionCount: number;
  totalConditionCount: number;
};

export type FilterSummaryItem = {
  key: keyof SearchFilters;
  label: string;
};

const lifeStageAliases: { value: string; patterns: RegExp[] }[] = [
  { value: "新社会人", patterns: [/新社会人/] },
  { value: "子育て中", patterns: [/子育て中/, /子育て/, /育児中/] },
  { value: "大学生", patterns: [/大学院生/, /大学生/] },
  { value: "高校生", patterns: [/女子高生/, /男子高校生/, /高校生/] },
  { value: "中学生", patterns: [/中学生/] },
  { value: "小学生", patterns: [/小学生/] },
  { value: "幼児", patterns: [/幼児/, /未就学児/] },
  { value: "シニア", patterns: [/シニア/, /高齢者/] },
  { value: "社会人", patterns: [/社会人/] },
];

const nonOccupationLabels = new Set([
  ...filterOptions.lifeStages,
  "学生",
]);

const occupations = Array.from(new Set([
  ...brands.flatMap((brand) => brand.occupations),
  ...outfits.flatMap((outfit) => outfit.occupations),
]))
  .filter((item) => !nonOccupationLabels.has(item))
  .sort((a, b) => b.length - a.length);

export function parseCharacterQuery(query: string): SearchFilters {
  const next = { ...emptySearchFilters };
  const normalizedQuery = query.normalize("NFKC");
  const compact = normalizedQuery.replace(/\s/g, "");
  const exactAgeMatch = normalizedQuery.match(/(?:^|[^\d])(\d{1,2})歳(?!\d)/);

  if (exactAgeMatch) {
    next.exactAge = Number(exactAgeMatch[1]);
    next.ageGroup = ageGroupFromExactAge(next.exactAge);
  } else {
    const olderAgeAlias = /(?:60|70|80|90)代(?:以上)?/.test(compact) ? "60代以上" : "";
    next.ageGroup = olderAgeAlias || ([...filterOptions.ageGroups]
      .sort((a, b) => b.length - a.length)
      .find((item) => compact.includes(item)) ?? "");
  }

  next.lifeStage = lifeStageAliases.find(({ patterns }) => patterns.some((pattern) => pattern.test(compact)))?.value ?? "";

  next.gender = filterOptions.genders.find((item) => compact.includes(item)) ?? "";
  if (!next.gender && /女子|女性|彼女/.test(compact)) next.gender = "女性";
  if (!next.gender && /男子|男性|彼氏/.test(compact)) next.gender = "男性";

  const queryTokens = normalizedQuery.split(/[\s、,，・/／]+/).filter(Boolean);
  next.season = filterOptions.seasons.find((item) =>
    queryTokens.includes(item) ||
    compact.endsWith(item) ||
    [`${item}服`, `${item}物`, `${item}コーデ`, `${item}向け`, `${item}の`].some((phrase) => compact.includes(phrase)),
  ) ?? "";
  const sceneCandidates = [...filterOptions.scenes]
    .sort((a, b) => b.length - a.length)
    .filter((item) => compact.includes(item));
  const styleCandidates = [...filterOptions.styles]
    .sort((a, b) => b.length - a.length)
    .filter((item) => compact.includes(item));
  next.scene = sceneCandidates[0] ?? "";
  next.style = styleCandidates[0] ?? "";
  if (next.scene === "フォーマル" && next.style === "フォーマル") {
    const explicitFormalStyle = /フォーマル(?:系|テイスト|スタイル)/.test(compact);
    const explicitFormalScene = /フォーマル(?:シーン|な場|の場)/.test(compact);
    if (explicitFormalStyle && !explicitFormalScene) {
      next.scene = sceneCandidates.find((item) => item !== "フォーマル") ?? "";
    } else if (!explicitFormalStyle) {
      next.style = styleCandidates.find((item) => item !== "フォーマル") ?? "";
    }
  }
  next.occupation = occupations.find((item) => compact.includes(item)) ?? "";

  return next;
}

export type SearchDiagnostic = {
  code: "invalid-age" | "age-life-stage-conflict" | "unknown-keyword" | "unknown-occupation";
  severity: "error" | "warning";
  message: string;
};

const lifeStageAgeRanges: Partial<Record<string, [number, number]>> = {
  幼児: [0, 6],
  小学生: [6, 12],
  中学生: [12, 15],
  高校生: [15, 18],
  大学生: [18, 29],
  新社会人: [18, 29],
  シニア: [60, 99],
};

export function getSearchDiagnostics(query: string, filters: SearchFilters): SearchDiagnostic[] {
  const diagnostics: SearchDiagnostic[] = [];
  const normalizedQuery = query.normalize("NFKC");
  const invalidAge = normalizedQuery.match(/(?:^|[^\d])(\d{3,})歳(?!\d)/);
  if (invalidAge || (filters.exactAge !== null && (filters.exactAge < 0 || filters.exactAge > 99))) {
    diagnostics.push({ code: "invalid-age", severity: "error", message: "年齢として解釈できません。0〜99歳で入力してください。" });
  }
  if (filters.exactAge !== null && filters.lifeStage) {
    const range = lifeStageAgeRanges[filters.lifeStage];
    if (range && (filters.exactAge < range[0] || filters.exactAge > range[1])) {
      diagnostics.push({
        code: "age-life-stage-conflict",
        severity: "error",
        message: `${filters.exactAge}歳と「${filters.lifeStage}」は同時条件として矛盾しています。どちらかを修正してください。`,
      });
    }
  }
  if (filters.occupation && !occupations.some((item) =>
    item.includes(filters.occupation) || filters.occupation.includes(item))) {
    diagnostics.push({
      code: "unknown-occupation",
      severity: "warning",
      message: `職業「${filters.occupation}」は当館の登録語に直接一致しません。`,
    });
  }
  const searchableCatalog = brands.map((brand) => [
    brand.name,
    brand.description,
    brand.creatorNote,
    ...brand.tags,
    ...brand.recommendedFor,
    ...brand.occupations,
  ].join(" ").toLowerCase());
  for (const keyword of extractSearchKeywords(query, filters)) {
    if (!searchableCatalog.some((text) => text.includes(keyword))) {
      diagnostics.push({ code: "unknown-keyword", severity: "warning", message: `「${keyword}」は当館の登録語に直接一致しません。` });
    }
  }
  return diagnostics;
}

function ageRangeMatches(brand: Brand, ageGroup: string, exactAge: number | null) {
  if (!ageGroup) return false;
  const aliases: Record<string, string[]> = {
    "10代以下": ["幼児", "小学生"],
    "10代": ["10代", "中学生", "高校生", ...(exactAge !== null && exactAge >= 18 ? ["大学生"] : [])],
    "20代": ["20代", "大学生", "新社会人"],
    "30代": ["30代"],
    "40代": ["40代"],
    "50代": ["50代"],
    "60代以上": ["60代以上", "シニア"],
  };
  return (aliases[ageGroup] ?? [ageGroup]).some((item) => brand.ageRange.includes(item));
}

function genderMatches(values: readonly string[], gender: string) {
  return values.includes(gender) ||
    values.includes("ジェンダーレス") ||
    (gender === "ジェンダーレス" && values.includes("女性") && values.includes("男性"));
}

function occupationListMatches(values: readonly string[], occupation: string) {
  return values.some((item) => item.includes(occupation) || occupation.includes(item));
}

function occupationMatches(brand: Brand, occupation: string) {
  return occupationListMatches(brand.occupations, occupation);
}

function lifeStageMatches(brand: Brand, lifeStage: string) {
  if (brand.ageRange.includes(lifeStage) || brand.occupations.includes(lifeStage)) return true;
  if (lifeStage === "新社会人") {
    return brand.ageRange.includes("20代") && brand.occupations.some((item) => ["会社員", "新社会人"].includes(item));
  }
  if (lifeStage === "社会人") {
    return brand.ageRange.some((item) => /20代|30代|40代|50代|60代以上/.test(item)) &&
      brand.occupations.some((item) => !/学生/.test(item));
  }
  if (lifeStage === "子育て中") {
    return [...brand.tags, ...brand.recommendedFor, ...brand.occupations]
      .some((item) => /子育て|親|ファミリー|主婦|主夫/.test(item));
  }
  if (lifeStage === "シニア") return brand.ageRange.includes("60代以上");
  return false;
}

export function extractSearchKeywords(query: string, filters: SearchFilters) {
  let residual = query.normalize("NFKC").toLowerCase();
  const lifeStageTerms: Partial<Record<string, string[]>> = {
    大学生: ["大学院生", "大学生"],
    高校生: ["女子高生", "男子高校生", "高校生"],
    中学生: ["中学生"],
    小学生: ["小学生"],
    幼児: ["幼児", "未就学児"],
    シニア: ["シニア", "高齢者"],
    子育て中: ["子育て中", "子育て", "育児中"],
  };
  const known = [
    filters.exactAge === null ? "" : `${filters.exactAge}歳`,
    filters.ageGroup,
    filters.lifeStage,
    filters.gender,
    filters.season,
    filters.scene,
    filters.style,
    filters.occupation,
    ...(filters.ageGroup === "60代以上"
      ? ["60代以上", "70代以上", "80代以上", "90代以上", "60代", "70代", "80代", "90代"]
      : []),
    ...(lifeStageTerms[filters.lifeStage] ?? []),
    ...(filters.gender === "女性" ? ["女性", "女子", "彼女"] : []),
    ...(filters.gender === "男性" ? ["男性", "男子", "彼氏"] : []),
  ].filter(Boolean).sort((a, b) => b.length - a.length);

  known.forEach((item) => {
    residual = residual.replaceAll(item.toLowerCase(), " ");
  });

  const searchStopWords = new Set([
    "コーデ", "コーディネート", "服", "の服", "服装", "の服装",
    "ファッション", "のファッション", "向け", "向けコーデ", "向けの服",
    "な場", "の場", "場", "シーン", "系", "風", "テイスト", "スタイル", "用",
  ]);

  return Array.from(new Set(
    residual
      .split(/[\s、,，・/／]+/)
      .map((item) => item.trim())
      .filter((item) => item.length > 1 && !searchStopWords.has(item)),
  )).slice(0, 4);
}

function scoreOutfit(outfit: OutfitRecipe, filters: SearchFilters) {
  let score = 0;
  if (filters.season && outfit.season === filters.season) score += 8;
  if (filters.scene && outfit.scene === filters.scene) score += 5;
  if (filters.ageGroup && outfit.ageGroups.includes(filters.ageGroup)) score += 4;
  if (filters.lifeStage && outfit.lifeStages.includes(filters.lifeStage)) score += 4;
  if (filters.gender && outfit.genders.includes(filters.gender)) score += 3;
  if (filters.style && outfit.styles.includes(filters.style)) score += 3;
  if (filters.occupation && outfit.occupations.includes(filters.occupation)) score += 4;
  return score;
}

const outfitStructuralConditions: readonly OutfitStructuralCondition[] = [
  "ageGroup",
  "lifeStage",
  "gender",
  "season",
  "scene",
  "style",
  "occupation",
];

function outfitMatchesCondition(
  outfit: OutfitRecipe,
  filters: SearchFilters,
  condition: OutfitStructuralCondition,
) {
  switch (condition) {
    case "ageGroup":
      return outfit.ageGroups.includes(filters.ageGroup);
    case "lifeStage":
      return outfit.lifeStages.includes(filters.lifeStage);
    case "gender":
      return genderMatches(outfit.genders, filters.gender);
    case "season":
      return outfit.season === filters.season;
    case "scene":
      return outfit.scene === filters.scene;
    case "style":
      return outfit.styles.includes(filters.style);
    case "occupation":
      return occupationListMatches(outfit.occupations, filters.occupation);
  }
}

function evaluateOutfitStructuralMatch(
  outfit: OutfitRecipe,
  filters: SearchFilters,
): Omit<OutfitSearchMatch, "outfit"> {
  // コーデ側は個別年齢を持たないため、exactAge は入力時に変換された ageGroup で判定する。
  const activeConditions = outfitStructuralConditions.filter((condition) => Boolean(filters[condition]));
  const matchedConditionCount = activeConditions.filter((condition) =>
    outfitMatchesCondition(outfit, filters, condition)).length;

  return {
    matchedConditionCount,
    totalConditionCount: activeConditions.length,
  };
}

export function getMatchingOutfits(brand: Brand, filters: SearchFilters) {
  const candidates = getOutfitsForBrand(brand.slug);
  const compatibleCandidates = candidates.filter((outfit) => {
    const match = evaluateOutfitStructuralMatch(outfit, filters);
    return match.matchedConditionCount === match.totalConditionCount;
  });
  return compatibleCandidates
    .map((outfit) => ({ outfit, score: scoreOutfit(outfit, filters) }))
    .sort((a, b) => b.score - a.score || a.outfit.id.localeCompare(b.outfit.id))
    .map(({ outfit }) => outfit);
}

export function getExactOutfitMatches(filters: SearchFilters): OutfitSearchMatch[] {
  const matches = outfits.map((outfit) => ({
    outfit,
    ...evaluateOutfitStructuralMatch(outfit, filters),
  }));
  if (!matches[0]?.totalConditionCount) return [];

  return matches
    .filter((match) => match.matchedConditionCount === match.totalConditionCount)
    .sort((first, second) =>
      scoreOutfit(second.outfit, filters) - scoreOutfit(first.outfit, filters) ||
      first.outfit.id.localeCompare(second.outfit.id),
    );
}

export function scoreBrand(brand: Brand, query: string, filters: SearchFilters): BrandScore {
  let score = 0;
  let maxScore = 0;
  const reasons: MatchReason[] = [];
  const cautions: MatchCaution[] = [];
  const matchedConditions = new Set<string>();
  const evidenceCounts: Record<MatchEvidenceSource, number> = { brand: 0, outfit: 0, editorial: 0 };
  const addMatch = (condition: string, code: string, label: string, points: number, source: MatchEvidenceSource) => {
    score += points;
    matchedConditions.add(condition);
    evidenceCounts[source] += 1;
    reasons.push({ code, condition, label, points, source });
  };
  const brandOutfits = getOutfitsForBrand(brand.slug);
  const matchingOutfits = getMatchingOutfits(brand, filters);
  const hasOutfitConditions = Boolean(
    filters.ageGroup || filters.lifeStage || filters.gender || filters.style ||
    filters.scene || filters.occupation || filters.season,
  );
  const exactOutfitMatch = hasOutfitConditions && matchingOutfits.length > 0;
  const residualTokens = extractSearchKeywords(query, filters);
  const hasOutfitEvidence = {
    age: Boolean(filters.ageGroup && brandOutfits.some((outfit) => outfit.ageGroups.includes(filters.ageGroup))),
    lifeStage: Boolean(filters.lifeStage && brandOutfits.some((outfit) => outfit.lifeStages.includes(filters.lifeStage))),
    gender: Boolean(filters.gender && brandOutfits.some((outfit) => genderMatches(outfit.genders, filters.gender))),
    style: Boolean(filters.style && brandOutfits.some((outfit) => outfit.styles.includes(filters.style))),
    scene: Boolean(filters.scene && brandOutfits.some((outfit) => outfit.scene === filters.scene)),
    occupation: Boolean(filters.occupation && brandOutfits.some((outfit) =>
      outfit.occupations.some((occupation) => occupation.includes(filters.occupation) || filters.occupation.includes(occupation)))),
    season: Boolean(filters.season && brandOutfits.some((outfit) => outfit.season === filters.season)),
  };
  const addSeparateOutfitEvidence = (
    condition: string,
    code: string,
    label: string,
    points: number,
  ) => {
    addMatch(condition, code, label, points, "outfit");
    if (hasOutfitConditions && !exactOutfitMatch) {
      cautions.push({
        code: `${condition}-cooccurrence`,
        label: `${label}。ほかの選択条件との同時一致コーデは資料未登録`,
        status: "unknown",
      });
    }
  };
  const totalConditionCount = [
    filters.ageGroup,
    filters.lifeStage,
    filters.gender,
    filters.style,
    filters.scene,
    filters.occupation,
    filters.season,
  ].filter(Boolean).length + residualTokens.length;

  if (filters.ageGroup) {
    maxScore += 6;
    if (ageRangeMatches(brand, filters.ageGroup, filters.exactAge)) {
      addMatch("age", "age", `${filters.ageGroup}の年代目安${filters.exactAge === null ? "" : `（${filters.exactAge}歳は年代換算）`}`, 6, "brand");
    } else if (exactOutfitMatch) {
      addMatch("age", "age-outfit", `${filters.ageGroup}を含む同時一致コーデ`, 4, "outfit");
    } else if (hasOutfitEvidence.age) {
      addSeparateOutfitEvidence("age", "age-outfit-separate", `${filters.ageGroup}向けコーデの登録あり`, 2);
    }
    else cautions.push({ code: "age", label: `${filters.ageGroup}は主な年代目安の外`, status: "mismatch" });
  }

  if (filters.lifeStage) {
    maxScore += 6;
    if (lifeStageMatches(brand, filters.lifeStage)) {
      addMatch("lifeStage", "lifeStage", `${filters.lifeStage}の生活像`, 6, "brand");
    } else if (exactOutfitMatch) {
      addMatch("lifeStage", "lifeStage-outfit", `${filters.lifeStage}を含む同時一致コーデ`, 4, "outfit");
    } else if (hasOutfitEvidence.lifeStage) {
      addSeparateOutfitEvidence("lifeStage", "lifeStage-outfit-separate", `${filters.lifeStage}向けコーデの登録あり`, 2);
    }
    else cautions.push({ code: "lifeStage", label: `${filters.lifeStage}との直接一致なし`, status: "unknown" });
  }

  if (filters.gender) {
    maxScore += 5;
    if (genderMatches(brand.gender, filters.gender)) {
      addMatch("gender", "gender", `${filters.gender}向け展開`, 5, "brand");
    } else if (exactOutfitMatch) {
      addMatch("gender", "gender-outfit", `${filters.gender}を含む同時一致コーデ`, 4, "outfit");
    } else if (hasOutfitEvidence.gender) {
      addSeparateOutfitEvidence("gender", "gender-outfit-separate", `${filters.gender}向けコーデの登録あり`, 2);
    }
    else cautions.push({ code: "gender", label: `${filters.gender}向け表記なし`, status: "mismatch" });
  }

  if (filters.style) {
    maxScore += 4;
    if (brand.style.includes(filters.style)) {
      addMatch("style", "style", `${filters.style}テイスト`, 4, "brand");
    } else if (exactOutfitMatch) {
      addMatch("style", "style-outfit", `${filters.style}を含む同時一致コーデ`, 3, "outfit");
    } else if (hasOutfitEvidence.style) {
      addSeparateOutfitEvidence("style", "style-outfit-separate", `${filters.style}コーデの登録あり`, 2);
    }
    else cautions.push({ code: "style", label: `${filters.style}は主要テイスト外`, status: "mismatch" });
  }

  if (filters.scene) {
    maxScore += 5;
    if (brand.scenes.includes(filters.scene)) {
      addMatch("scene", "scene", `${filters.scene}に対応`, 3, "brand");
    } else if (exactOutfitMatch) {
      addMatch("scene", "scene-outfit", `${filters.scene}を含む同時一致コーデ`, 2, "outfit");
    } else if (hasOutfitEvidence.scene) {
      addSeparateOutfitEvidence("scene", "scene-outfit-separate", `${filters.scene}コーデの登録あり`, 2);
    } else {
      cautions.push({ code: "scene", label: `${filters.scene}は主要シーン情報に直接一致なし`, status: "unknown" });
    }
    if (exactOutfitMatch) {
      addMatch("scene", "outfitScene", `${filters.scene}の同時一致コーデあり`, 2, "outfit");
    }
  }

  if (filters.occupation) {
    maxScore += 5;
    if (occupationMatches(brand, filters.occupation)) {
      addMatch("occupation", "occupation", `${filters.occupation}の人物像`, 5, "brand");
    } else if (exactOutfitMatch) {
      addMatch("occupation", "occupation-outfit", `${filters.occupation}を含む同時一致コーデ`, 3, "outfit");
    } else if (hasOutfitEvidence.occupation) {
      addSeparateOutfitEvidence("occupation", "occupation-outfit-separate", `${filters.occupation}向けコーデの登録あり`, 2);
    }
    else cautions.push({ code: "occupation", label: `${filters.occupation}との直接一致なし`, status: "unknown" });
  }

  if (filters.season) {
    maxScore += 2;
    if (exactOutfitMatch) {
      addMatch("season", "season", `${filters.season}の同時一致コーデあり`, 2, "outfit");
    } else if (hasOutfitEvidence.season) {
      addSeparateOutfitEvidence("season", "season-outfit-separate", `${filters.season}コーデの登録あり`, 1);
    }
    else cautions.push({ code: "season", label: `ほかの条件も同時に満たす${filters.season}コーデは資料未登録`, status: "unknown" });
  }

  const searchable = [
    brand.name,
    brand.description,
    brand.creatorNote,
    ...brand.tags,
    ...brand.recommendedFor,
    ...brand.occupations,
  ].join(" ").toLowerCase();
  maxScore += residualTokens.length * 2;
  residualTokens.forEach((token, index) => {
    if (searchable.includes(token)) {
      addMatch(`keyword-${index}`, `keyword-${index}`, `「${token}」に関連`, 2, "editorial");
    } else {
      cautions.push({ code: `keyword-${index}`, label: `「${token}」は当館の登録語に直接一致なし`, status: "unknown" });
    }
  });

  return {
    score,
    maxScore,
    matchPercent: maxScore ? Math.round((score / maxScore) * 100) : 0,
    matchedConditionCount: matchedConditions.size,
    totalConditionCount,
    exactOutfitMatch,
    evidenceCounts,
    reasons,
    cautions: cautions.filter((item, index, all) => all.findIndex((other) => other.code === item.code) === index),
    bestOutfit: matchingOutfits[0],
  };
}

export function rankBrands(query: string, filters: SearchFilters) {
  const active = Boolean(query.trim() || Object.values(filters).some((value) => value !== "" && value !== null));
  if (getSearchDiagnostics(query, filters).some((diagnostic) => diagnostic.severity === "error")) return [];
  return brands
    .map((brand) => ({ brand, ...scoreBrand(brand, query, filters) }))
    .filter((item) => {
      if (!active) return true;
      const requiredMatches = item.totalConditionCount;
      const criticalMismatch = item.cautions.some((caution) =>
        caution.status === "mismatch" && (caution.code === "gender" || caution.code === "style"),
      );
      return item.score > 0 && item.matchedConditionCount === requiredMatches && !criticalMismatch;
    })
    .sort((a, b) =>
      a.cautions.filter((item) => item.status === "mismatch").length - b.cautions.filter((item) => item.status === "mismatch").length ||
      Number(b.exactOutfitMatch) - Number(a.exactOutfitMatch) ||
      b.matchedConditionCount - a.matchedConditionCount ||
      b.matchPercent - a.matchPercent ||
      b.reasons.filter((item) => item.source === "brand").reduce((sum, item) => sum + item.points, 0) -
        a.reasons.filter((item) => item.source === "brand").reduce((sum, item) => sum + item.points, 0) ||
      b.score - a.score ||
      ({ high: 3, medium: 2, low: 1 }[b.brand.confidence] - { high: 3, medium: 2, low: 1 }[a.brand.confidence]) ||
      Date.parse(b.brand.updatedAt) - Date.parse(a.brand.updatedAt) ||
      Number(b.brand.featured) - Number(a.brand.featured) ||
      a.brand.slug.localeCompare(b.brand.slug),
    );
}

export function buildFilterSummary(filters: SearchFilters): FilterSummaryItem[] {
  const items: FilterSummaryItem[] = [];
  if (filters.exactAge !== null) items.push({ key: "exactAge", label: `${filters.exactAge}歳` });
  else if (filters.ageGroup) items.push({ key: "ageGroup", label: filters.ageGroup });
  if (filters.lifeStage) items.push({ key: "lifeStage", label: filters.lifeStage });
  if (filters.gender) items.push({ key: "gender", label: filters.gender });
  if (filters.occupation) items.push({ key: "occupation", label: filters.occupation });
  if (filters.scene) items.push({ key: "scene", label: filters.scene });
  if (filters.style) items.push({ key: "style", label: filters.style });
  if (filters.season) items.push({ key: "season", label: filters.season });
  return items;
}
