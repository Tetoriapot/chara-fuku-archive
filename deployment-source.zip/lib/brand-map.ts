import type { Brand } from "@/lib/brands";

export type BrandQuadrantId = "clean-invest" | "casual-invest" | "clean-value" | "casual-value";

export type BrandQuadrant = {
  id: BrandQuadrantId;
  title: string;
  description: string;
};

export const brandQuadrants: BrandQuadrant[] = [
  { id: "clean-invest", title: "きれいめ × 高価格", description: "端正な印象に寄せたい、服へ投資する人物" },
  { id: "casual-invest", title: "カジュアル × 高価格", description: "肩の力を抜きつつ、素材や店選びにこだわる人物" },
  { id: "clean-value", title: "きれいめ × 手頃", description: "予算を抑えて通学・通勤の清潔感を整える人物" },
  { id: "casual-value", title: "カジュアル × 手頃", description: "日常性・動きやすさ・買いやすさを優先する人物" },
];

export function getBrandQuadrant(brand: Pick<Brand, "mapX" | "mapY">): BrandQuadrantId {
  const casual = brand.mapX >= 50;
  const invest = brand.mapY >= 50;
  if (!casual && invest) return "clean-invest";
  if (casual && invest) return "casual-invest";
  if (!casual && !invest) return "clean-value";
  return "casual-value";
}

export function getQuadrantBrands<T extends Pick<Brand, "mapX" | "mapY">>(allBrands: T[], quadrantId: BrandQuadrantId) {
  return allBrands.filter((brand) => getBrandQuadrant(brand) === quadrantId);
}
