"use client";

import Link from "next/link";
import { ArrowRight, CheckCircle2, Palette } from "lucide-react";
import { BoardToggle } from "@/components/BoardToggle";
import type { OutfitRecipe } from "@/lib/brands";
import { getOutfitBrandRecords } from "@/lib/outfits";
import type { SearchFilters } from "@/lib/search";

type OutfitMatchCardProps = {
  outfit: OutfitRecipe;
  matchedConditionCount: number;
  totalConditionCount: number;
  filters?: SearchFilters;
  premise?: string;
};

export function OutfitMatchCard({
  outfit,
  matchedConditionCount,
  totalConditionCount,
  filters,
  premise,
}: OutfitMatchCardProps) {
  const outfitBrands = getOutfitBrandRecords(outfit);

  return (
    <article className="search-outfit-card">
      <header className="search-outfit-card-header">
        <p
          className="search-outfit-card-score"
          aria-label={`登録条件${totalConditionCount}件中${matchedConditionCount}件一致`}
        >
          <CheckCircle2 size={17} aria-hidden="true" />
          <strong>登録条件 {matchedConditionCount}/{totalConditionCount}一致</strong>
        </p>
        <p className="search-outfit-card-meta">
          <span>{outfit.season}</span>
          <span aria-hidden="true">・</span>
          <span>{outfit.scene}</span>
        </p>
      </header>

      <h3>{outfit.title}</h3>

      <dl className="search-outfit-card-parts">
        <div>
          <dt>トップス</dt>
          <dd>{outfit.parts.top}</dd>
        </div>
        <div>
          <dt>ボトムス</dt>
          <dd>{outfit.parts.bottom}</dd>
        </div>
        <div>
          <dt>靴</dt>
          <dd>{outfit.parts.shoes}</dd>
        </div>
      </dl>

      <section className="search-outfit-card-palette" aria-label="配色">
        <h4><Palette size={15} aria-hidden="true" /> 配色</h4>
        <ul>
          {outfit.palette.map((color) => (
            <li key={`${color.name}-${color.hex}`}>
              <i style={{ backgroundColor: color.hex }} aria-hidden="true" />
              <span>{color.name}</span>
            </li>
          ))}
        </ul>
      </section>

      <p className="search-outfit-card-silhouette">
        <strong>シルエット</strong>
        <span>{outfit.silhouette}</span>
      </p>

      {outfitBrands.length > 0 ? (
        <footer className="search-outfit-card-brands">
          <span>参照ブランド</span>
          <ul>
            {outfitBrands.map((brand) => (
              <li key={brand.slug}>
                <Link href={`/brands/${brand.slug}`}>{brand.name}</Link>
              </li>
            ))}
          </ul>
        </footer>
      ) : null}

      <div className="search-outfit-card-actions">
        <Link href={`/outfits#${outfit.id}`}>
          コーデ資料を詳しく見る
          <ArrowRight size={15} aria-hidden="true" />
        </Link>
        <BoardToggle
          type="outfit"
          itemId={outfit.id}
          itemName={outfit.title}
          filters={filters}
          premise={premise}
          className="board-toggle search-outfit-card-board-toggle print-hidden"
        />
      </div>
    </article>
  );
}
