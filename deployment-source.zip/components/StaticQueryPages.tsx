"use client";

import { useSearchParams } from "next/navigation";
import { SearchExplorer } from "@/components/SearchExplorer";
import { OutfitExplorer } from "@/components/OutfitExplorer";
import { BrandCompare } from "@/components/BrandCompare";
import { readSearchState } from "@/lib/search-state";
import { readOutfitFilters } from "@/lib/outfits";
import { normalizeCompareSlugs } from "@/lib/compare";

export function StaticSearchExplorer() {
  const params = useSearchParams();
  const { query, filters } = readSearchState(new URLSearchParams(params.toString()));
  return <SearchExplorer initialQuery={query} initialFilters={filters} />;
}

export function StaticOutfitExplorer() {
  const params = useSearchParams();
  const filters = readOutfitFilters(new URLSearchParams(params.toString()));
  return <OutfitExplorer initialFilters={filters} />;
}

export function StaticBrandCompare() {
  const params = useSearchParams();
  return <BrandCompare initialSlugs={normalizeCompareSlugs(params.getAll("brands"))} restoreStoredSelection={!params.has("brands")} />;
}
