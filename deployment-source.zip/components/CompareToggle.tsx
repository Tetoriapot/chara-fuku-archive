"use client";

import { useState } from "react";
import { Check, GitCompareArrows, X } from "lucide-react";
import { useCompareSelection } from "@/components/useCompareSelection";

export function CompareToggle({ slug, name, className = "compare-toggle" }: { slug: string; name: string; className?: string }) {
  const { selectedSlugs, add, remove } = useCompareSelection();
  const [status, setStatus] = useState("");
  const selected = selectedSlugs.includes(slug);

  function toggle() {
    if (selected) {
      remove(slug);
      setStatus(`${name}を比較候補から外しました`);
      return;
    }
    const result = add(slug);
    setStatus(result.reason === "limit" ? "比較候補は4件までです。候補を外してから追加してください" : `${name}を比較候補に追加しました`);
  }

  return (
    <>
      <button className={className} type="button" aria-pressed={selected} onClick={toggle}>
        {selected ? <X size={17} aria-hidden="true" /> : <GitCompareArrows size={17} aria-hidden="true" />}
        {selected ? "比較候補から外す" : "比較候補に追加"}
        {selected ? <Check className="compare-toggle-check" size={14} aria-hidden="true" /> : null}
      </button>
      <span className="sr-only" role="status" aria-live="polite">{status}</span>
    </>
  );
}
