"use client";

import { publicPath } from "@/lib/public-path";
import { useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { AlertTriangle, ArrowRight, CalendarDays, Check, RotateCcw, Search, Share2, ShieldCheck, SlidersHorizontal, Sparkles } from "lucide-react";
import { BrandCard } from "@/components/BrandCard";
import { BoardToggle } from "@/components/BoardToggle";
import { CompareToggle } from "@/components/CompareToggle";
import { OutfitMatchCard } from "@/components/OutfitMatchCard";
import { useCharacterBoard } from "@/components/useCharacterBoard";
import { filterOptions } from "@/lib/brands";
import { copyText } from "@/lib/copy-client";
import { buildOutfitPath } from "@/lib/outfits";
import {
  ageGroupFromExactAge,
  buildFilterSummary,
  emptySearchFilters,
  extractSearchKeywords,
  getExactOutfitMatches,
  getSearchDiagnostics,
  parseCharacterQuery,
  rankBrands,
  type SearchFilters,
} from "@/lib/search";
import { buildSearchPath, readSearchState } from "@/lib/search-state";

function SelectField({ label, value, options, onChange }: { label: string; value: string; options: readonly string[]; onChange: (value: string) => void }) {
  return (
    <label className="filter-field">
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        <option value="">指定しない</option>
        {options.map((option) => <option key={option} value={option}>{option}</option>)}
      </select>
    </label>
  );
}

function formatJapaneseDate(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return `${year}年${month}月${day}日`;
}

const confidenceLabels = {
  high: "高（公式確認項目が多い）",
  medium: "中（編集部推定を含む）",
  low: "参考（人物像のヒント）",
} as const;

const evidenceSourceLabels = {
  brand: "ブランド情報",
  outfit: "登録コーデ",
  editorial: "編集キーワード",
} as const;

export function SearchExplorer({ initialQuery, initialFilters }: { initialQuery: string; initialFilters?: SearchFilters }) {
  const [query, setQuery] = useState(initialQuery);
  const [committedQuery, setCommittedQuery] = useState(initialQuery);
  const [filters, setFilters] = useState<SearchFilters>(() => initialFilters ?? parseCharacterQuery(initialQuery));
  const [exactAgeInput, setExactAgeInput] = useState(() => {
    const initialAge = (initialFilters ?? parseCharacterQuery(initialQuery)).exactAge;
    return initialAge === null ? "" : String(initialAge);
  });
  const [ageInputError, setAgeInputError] = useState("");
  const [shareStatus, setShareStatus] = useState("");
  const resultsHeadingRef = useRef<HTMLHeadingElement>(null);
  const { board, setFields } = useCharacterBoard();

  const results = useMemo(() => rankBrands(committedQuery, filters), [committedQuery, filters]);
  const exactOutfitMatches = useMemo(() => getExactOutfitMatches(filters), [filters]);
  const summary = useMemo(() => buildFilterSummary(filters), [filters]);
  const keywords = useMemo(() => extractSearchKeywords(committedQuery, filters), [committedQuery, filters]);
  const diagnostics = useMemo(() => getSearchDiagnostics(committedQuery, filters), [committedQuery, filters]);
  const outfitStructuralConditionCount = [
    filters.ageGroup,
    filters.lifeStage,
    filters.gender,
    filters.season,
    filters.scene,
    filters.style,
    filters.occupation,
  ].filter(Boolean).length;
  const matchingOutfitsPath = useMemo(() => buildOutfitPath({
    season: filters.season,
    scene: filters.scene,
    ageGroup: filters.ageGroup,
    lifeStage: filters.lifeStage,
    gender: filters.gender,
    style: filters.style,
    occupation: filters.occupation,
    brandSlug: "",
  }), [filters]);
  const interpretedConditions = useMemo(() => [
    ...summary.map((item) => item.key === "exactAge"
      ? `${item.label}（${filters.ageGroup || "年代不明"}データで判定）`
      : item.label),
    ...keywords.map((keyword) => `キーワード：${keyword}`),
  ], [filters.ageGroup, keywords, summary]);
  const hasActiveConditions = Boolean(committedQuery.trim() || summary.length);
  const hasSearchErrors = diagnostics.some((diagnostic) => diagnostic.severity === "error");

  useEffect(() => {
    function restoreFromHistory() {
      const restored = readSearchState(new URLSearchParams(window.location.search));
      setQuery(restored.query);
      setCommittedQuery(restored.query);
      setFilters(restored.filters);
      setExactAgeInput(restored.filters.exactAge === null ? "" : String(restored.filters.exactAge));
      setAgeInputError("");
      setShareStatus("");
    }
    window.addEventListener("popstate", restoreFromHistory);
    return () => window.removeEventListener("popstate", restoreFromHistory);
  }, []);

  function applyManualFilters(next: SearchFilters) {
    const keywords = extractSearchKeywords(committedQuery, filters).join(" ");
    setQuery(keywords);
    setCommittedQuery(keywords);
    setFilters(next);
    setExactAgeInput(next.exactAge === null ? "" : String(next.exactAge));
    setAgeInputError("");
    setShareStatus("");
    window.history.replaceState(null, "", publicPath(buildSearchPath(keywords, next)));
  }

  function updateFilter(key: keyof SearchFilters, value: string) {
    applyManualFilters({ ...filters, [key]: value });
  }

  function updateExactAge(rawValue: string) {
    setExactAgeInput(rawValue);
    if (!rawValue) {
      applyManualFilters({ ...filters, exactAge: null, ageGroup: "" });
      return;
    }
    const parsedAge = Number(rawValue);
    if (!Number.isInteger(parsedAge) || parsedAge < 0 || parsedAge > 99) {
      setAgeInputError("0〜99歳の整数で入力してください。");
      return;
    }
    const exactAge = parsedAge;
    applyManualFilters({ ...filters, exactAge, ageGroup: ageGroupFromExactAge(exactAge) });
  }

  function submitQuery(event: React.FormEvent) {
    event.preventDefault();
    const parsed = parseCharacterQuery(query);
    setCommittedQuery(query);
    setFilters(parsed);
    setExactAgeInput(parsed.exactAge === null ? "" : String(parsed.exactAge));
    setAgeInputError("");
    setShareStatus("");
    window.history.replaceState(null, "", publicPath(buildSearchPath(query, parsed, false)));
  }

  function reset() {
    setQuery("");
    setCommittedQuery("");
    setFilters({ ...emptySearchFilters });
    setExactAgeInput("");
    setAgeInputError("");
    setShareStatus("");
    window.history.replaceState(null, "", publicPath("/search"));
    window.requestAnimationFrame(() => document.getElementById("character-query")?.focus());
  }

  function clearSummaryFilter(key: keyof SearchFilters) {
    if (key === "exactAge") {
      applyManualFilters({ ...filters, exactAge: null, ageGroup: "" });
    } else {
      updateFilter(key, "");
    }
    window.requestAnimationFrame(() => {
      const nextFilter = document.querySelector<HTMLElement>(".results-panel .active-filters button");
      if (nextFilter) nextFilter.focus();
      else resultsHeadingRef.current?.focus();
    });
  }

  function saveConditionsToBoard() {
    const saved = setFields({ filters, premise: board.premise || committedQuery.trim() });
    const characterName = board.name.trim() || "名称未設定のキャラクター";
    setShareStatus(saved ? `「${characterName}」に検索条件を保存しました` : "このブラウザでは条件を保存できませんでした");
  }

  async function shareConditions() {
    const path = buildSearchPath(committedQuery, filters);
    window.history.replaceState(null, "", publicPath(path));
    const url = new URL(publicPath(path), window.location.origin).toString();
    if (navigator.share) {
      try {
        await navigator.share({ title: "キャラ服資料館の検索条件", text: "このキャラクター設定のブランド候補", url });
        setShareStatus("共有メニューを開きました");
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
      }
    }
    try {
      await copyText(url);
      setShareStatus("条件URLをコピーしました");
    } catch {
      setShareStatus("共有できませんでした。アドレス欄のURLをご利用ください");
    }
  }

  return (
    <div className="search-explorer">
      <form className="search-page-bar" onSubmit={submitQuery}>
        <Search size={22} aria-hidden="true" />
        <label htmlFor="character-query" className="sr-only">キャラクター設定を入力</label>
        <input id="character-query" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="例：22歳 女性 大学生 インドア 夏" />
        <button type="submit">条件を反映</button>
      </form>

      <div className="search-layout">
        <aside className="filters-panel">
          <div className="filters-title"><span><SlidersHorizontal size={18} aria-hidden="true" /> 絞り込み</span><button onClick={reset} type="button"><RotateCcw size={15} aria-hidden="true" />リセット</button></div>
          <label className="filter-field">
            <span>年齢（ぴったり）</span>
            <span className="age-input-wrap">
              <input type="number" min="0" max="99" step="1" inputMode="numeric" value={exactAgeInput} aria-invalid={Boolean(ageInputError)} aria-describedby={ageInputError ? "exact-age-error" : undefined} onChange={(event) => updateExactAge(event.target.value)} placeholder="例：22" />
              <i>歳</i>
            </span>
            {ageInputError ? <small id="exact-age-error" className="filter-field-error" role="alert">{ageInputError}</small> : null}
          </label>
          <SelectField label="年代" value={filters.ageGroup} options={filterOptions.ageGroups} onChange={(value) => applyManualFilters({ ...filters, exactAge: null, ageGroup: value })} />
          <SelectField label="学齢・ライフステージ" value={filters.lifeStage} options={filterOptions.lifeStages} onChange={(value) => updateFilter("lifeStage", value)} />
          <SelectField label="性別" value={filters.gender} options={filterOptions.genders} onChange={(value) => updateFilter("gender", value)} />
          <SelectField label="季節" value={filters.season} options={filterOptions.seasons} onChange={(value) => updateFilter("season", value)} />
          <SelectField label="シーン" value={filters.scene} options={filterOptions.scenes} onChange={(value) => updateFilter("scene", value)} />
          <SelectField label="テイスト" value={filters.style} options={filterOptions.styles} onChange={(value) => updateFilter("style", value)} />
          <label className="filter-field">
            <span>職業</span>
            <input value={filters.occupation} onChange={(event) => updateFilter("occupation", event.target.value)} placeholder="例：保育士、会社員" />
          </label>
          <div className="filter-note"><Sparkles size={17} aria-hidden="true" /><p><strong>創作のヒント</strong>年齢・立場・職業は別々に指定できます。人物像の核になる2〜3項目だけでも探せます。</p></div>
        </aside>

        <section className="results-panel">
          <div className="results-header">
            <div>
              <p className="eyebrow">MATCHED BRAND FILES</p>
              <h2 ref={resultsHeadingRef} tabIndex={-1}>{interpretedConditions.length ? interpretedConditions.join("・") : committedQuery.trim() || "すべてのブランド"}</h2>
            </div>
            <div className="results-header-actions">
              <button className="share-search-button" type="button" onClick={saveConditionsToBoard} disabled={!hasActiveConditions}><Sparkles size={16} aria-hidden="true" />条件をボードに保存</button>
              <button className="share-search-button" type="button" onClick={shareConditions}><Share2 size={16} aria-hidden="true" />条件を共有</button>
              <span className="result-count" role="status" aria-live="polite"><strong>{results.length}</strong> 件</span>
            </div>
          </div>
          <p className="share-status" role="status" aria-live="polite">{shareStatus ? <><Check size={15} aria-hidden="true" />{shareStatus}</> : null}</p>
          <aside className="search-method-note" aria-label="検索結果の見方">
            <ShieldCheck size={21} aria-hidden="true" />
            <div><strong>検索結果の見方</strong><p>すべての判定項目に登録根拠がある候補だけを、根拠の強さで並べています。人気順位・実際の着用率・ブランド公式の推奨ではありません。</p></div>
          </aside>
          {interpretedConditions.length > 0 && (
            <section className="search-interpretation" aria-labelledby="search-interpretation-heading">
              <strong id="search-interpretation-heading">判定に使った条件</strong>
              <ul>{interpretedConditions.map((condition) => <li key={condition}>{condition}</li>)}</ul>
            </section>
          )}
          {diagnostics.length > 0 && (
            <div className="search-query-warning" role="alert">
              <AlertTriangle size={19} aria-hidden="true" />
              <div><strong>{diagnostics.some((diagnostic) => diagnostic.severity === "error") ? "検索条件を確認してください" : "検索語の解釈に注意"}</strong><ul>{diagnostics.map((diagnostic) => <li key={`${diagnostic.code}-${diagnostic.message}`}>{diagnostic.message}</li>)}</ul></div>
            </div>
          )}
          {summary.length > 0 && (
            <div className="active-filters" aria-label="選択中の条件">
              {summary.map((item) => <button type="button" key={item.key} onClick={() => clearSummaryFilter(item.key)}>{item.label}<span aria-hidden="true">×</span><span className="sr-only">の条件を解除</span></button>)}
            </div>
          )}

          {outfitStructuralConditionCount > 0 && !hasSearchErrors && (
            <section className="exact-outfit-results" aria-labelledby="exact-outfit-results-heading">
              <div className="exact-outfit-results-heading">
                <div>
                  <p className="eyebrow">REGISTERED OUTFIT MATCHES</p>
                  <h3 id="exact-outfit-results-heading">この設定のコーデ候補</h3>
                </div>
                <span role="status"><strong>{exactOutfitMatches.length}</strong>件</span>
              </div>
              <p className="exact-outfit-results-note">
                選択した{outfitStructuralConditionCount}条件を、1つの登録コーデ内で同時に満たす資料です。人気順・着用率順ではありません。
              </p>
              {exactOutfitMatches.length > 0 ? (
                <>
                  <div className="search-outfit-match-grid">
                    {exactOutfitMatches.slice(0, 6).map((match) => (
                      <OutfitMatchCard
                        key={match.outfit.id}
                        {...match}
                        filters={filters}
                        premise={committedQuery}
                      />
                    ))}
                  </div>
                  <Link className="exact-outfit-results-link" href={matchingOutfitsPath}>
                    コーデ資料集で同じ条件を開く
                    {exactOutfitMatches.length > 6 ? `（全${exactOutfitMatches.length}件）` : ""}
                    <ArrowRight size={15} aria-hidden="true" />
                  </Link>
                </>
              ) : (
                <div className="exact-outfit-empty" role="note">
                  <strong>この条件を同時に満たす登録コーデはまだありません</strong>
                  <p>条件を自動では緩めていません。下のブランド候補は、ブランド情報と個別の登録資料を根拠に表示します。</p>
                  <Link href={matchingOutfitsPath}>同じ条件でコーデ資料集を確認 <ArrowRight size={14} aria-hidden="true" /></Link>
                </div>
              )}
            </section>
          )}

          {results.length ? (
            <ol className="search-results-grid">
              {results.map(({ brand, matchPercent, matchedConditionCount, totalConditionCount, exactOutfitMatch, evidenceCounts, reasons, cautions, bestOutfit }, index) => {
                const mismatches = cautions.filter((caution) => caution.status === "mismatch");
                const unknowns = cautions.filter((caution) => caution.status === "unknown");
                return (
                  <li className="result-card-wrap" key={brand.slug}>
                    <div className="match-line">
                      <span>{hasActiveConditions ? "候補" : "掲載"} {String(index + 1).padStart(2, "0")}</span>
                      <span>{hasActiveConditions ? `登録データ一致度 ${matchPercent}%・${matchedConditionCount}/${totalConditionCount}項目` : "ブランド資料一覧"}</span>
                    </div>
                    <BrandCard brand={brand} />
                    {hasActiveConditions && (
                      <div className="result-evidence">
                        <div className="result-evidence-summary">
                          <strong>{exactOutfitMatch ? <><Check size={15} aria-hidden="true" />年代・性別・季節などの構造条件を同時に満たす登録コーデあり</> : "各条件の登録根拠を個別に確認"}</strong>
                          <span>ブランド根拠 {evidenceCounts.brand}・コーデ根拠 {evidenceCounts.outfit}・キーワード根拠 {evidenceCounts.editorial}</span>
                        </div>
                        <div className="reason-list" aria-label="順位判定に使った一致根拠">
                          {reasons.map((reason) => <span className={`reason-pill source-${reason.source}`} key={reason.code}><small>{evidenceSourceLabels[reason.source]}</small>{reason.label}</span>)}
                        </div>
                        {mismatches.length > 0 && (
                          <div className="match-conflicts" role="note">
                            <strong><AlertTriangle size={16} aria-hidden="true" />条件不一致</strong>
                            <ul>{mismatches.map((caution) => <li key={caution.code}>{caution.label}</li>)}</ul>
                          </div>
                        )}
                        {bestOutfit && (
                          <Link className="result-outfit" href={`/outfits#${bestOutfit.id}`}>
                            <small>編集部作成の資料コーデ・{bestOutfit.season}・{bestOutfit.scene}</small>
                            <strong>{bestOutfit.title}</strong>
                            <span>{[bestOutfit.parts.top, bestOutfit.parts.bottom, bestOutfit.parts.shoes].join(" / ")}</span>
                          </Link>
                        )}
                        {unknowns.length > 0 && (
                          <details className="match-cautions">
                            <summary>根拠の注意 {unknowns.length}件</summary>
                            <p>同時一致資料の未登録や、編集語の未一致を示します。不向きを意味するものではありません。</p>
                            <ul>{unknowns.map((caution) => <li key={caution.code}>{caution.label}</li>)}</ul>
                          </details>
                        )}
                        <div className="result-trust-meta">
                          <span><CalendarDays size={15} aria-hidden="true" />編集データ更新：{formatJapaneseDate(brand.updatedAt)}</span>
                          <span><ShieldCheck size={15} aria-hidden="true" />確度：{confidenceLabels[brand.confidence]}</span>
                          <Link href={`/brands/${brand.slug}#sources`}>根拠と出典を見る <ArrowRight size={14} aria-hidden="true" /></Link>
                        </div>
                        <p className="result-editorial-label">年代・人物像・テイストは、公式サイトの掲載内容を参考に当館編集部が整理した目安です。</p>
                      </div>
                    )}
                    <div className="result-resource-actions print-hidden">
                      <CompareToggle className="compare-from-result" slug={brand.slug} name={brand.name} />
                      <BoardToggle type="brand" itemId={brand.slug} itemName={brand.name} filters={filters} premise={committedQuery} />
                    </div>
                  </li>
                );
              })}
            </ol>
          ) : (
            <div className="empty-state">
              {diagnostics.length ? <AlertTriangle size={36} aria-hidden="true" /> : <Search size={36} aria-hidden="true" />}
              <h3>{diagnostics.some((diagnostic) => diagnostic.severity === "error") ? "検索条件を修正してください" : "登録済みブランド内に、基準を満たす資料候補がありませんでした"}</h3>
              <p>{diagnostics.some((diagnostic) => diagnostic.severity === "error") ? "上の案内を確認し、矛盾している条件を変更してください。" : "未登録は不向きを意味しません。条件を1つ減らすか、近い言葉で試してください。"}</p>
              <button type="button" onClick={reset}>すべてのブランドを見る</button>
            </div>
          )}
          <div className="results-footer-note">
            <p>順位と一致度は当館の登録範囲内の比較です。最終的な服装資料は、各ブランドの公式サイトで現在の商品もご確認ください。</p>
            <Link href="/brand-map">ブランドマップで比較 <ArrowRight size={16} aria-hidden="true" /></Link>
          </div>
        </section>
      </div>
    </div>
  );
}
