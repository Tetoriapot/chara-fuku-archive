"use client";

import { BookmarkPlus, Check, X } from "lucide-react";
import { useState } from "react";
import { useCharacterBoard } from "@/components/useCharacterBoard";
import type { SearchFilters } from "@/lib/search";

type BoardToggleProps = {
  type: "brand" | "outfit";
  itemId: string;
  itemName: string;
  filters?: SearchFilters;
  premise?: string;
  className?: string;
};

export function BoardToggle({ type, itemId, itemName, filters, premise, className = "board-toggle" }: BoardToggleProps) {
  const { board, toggleBrand, toggleOutfit } = useCharacterBoard();
  const [status, setStatus] = useState("");
  const selected = type === "brand" ? board.brandSlugs.includes(itemId) : board.outfitIds.includes(itemId);

  function toggle() {
    const characterName = board.name.trim() || "名称未設定のキャラクター";
    const result = type === "brand" ? toggleBrand(itemId, filters, premise) : toggleOutfit(itemId, filters, premise);
    if (result.reason === "limit") {
      setStatus(type === "brand" ? "ブランド候補は4件までです。ボードから候補を外してから追加してください" : "コーデ候補は6件までです。ボードから候補を外してから追加してください");
      return;
    }
    if (result.reason === "storage") {
      setStatus("このブラウザではキャラクターボードを保存できませんでした");
      return;
    }
    if (result.reason === "missing") {
      setStatus("編集中のキャラクターが別のタブで削除されました。キャラクター管理で選び直してください");
      return;
    }
    setStatus(`${itemName}を${result.reason === "added" ? `「${characterName}」に追加しました` : `「${characterName}」から外しました`}`);
  }

  return (
    <>
      <button className={className} type="button" aria-pressed={selected} aria-label={`${itemName}を「${board.name.trim() || "名称未設定のキャラクター"}」${selected ? "から外す" : "に追加"}`} onClick={toggle}>
        {selected ? <X size={17} aria-hidden="true" /> : <BookmarkPlus size={17} aria-hidden="true" />}
        {selected ? "ボードから外す" : "ボードに追加"}
        {selected ? <Check size={14} aria-hidden="true" /> : null}
      </button>
      <span className="sr-only" role="status" aria-live="polite">{status}</span>
    </>
  );
}
