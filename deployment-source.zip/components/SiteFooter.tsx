import Link from "next/link";

export function SiteFooter() {
  return (
    <footer className="site-footer">
      <div className="shell footer-grid">
        <div>
          <div className="brand-lockup footer-lockup">
            <span className="brand-mark" aria-hidden="true">服</span>
            <span><strong>キャラ服資料館</strong><small>CHARACTER FASHION ARCHIVE</small></span>
          </div>
          <p>
            「このキャラなら何を着る？」を考えるための、創作者向けファッション資料サイト。<br />
            <small>テーマ・比較候補・キャラクター資料は、このブラウザ内だけに保存されます。</small>
          </p>
        </div>
        <div className="footer-links">
          <Link href="/search">キャラから探す</Link>
          <Link href="/outfits">コーデ資料</Link>
          <Link href="/brand-map">ブランドマップ</Link>
          <Link href="/compare">ブランド比較</Link>
          <Link href="/board">キャラクター管理</Link>
          <Link href="/#about">このサイトについて</Link>
          <Link href="/updates">更新情報</Link>
          <Link href="/help">Help・使い方</Link>
        </div>
      </div>
      <div className="shell footer-bottom">
        <span>© 2026 キャラ服資料館</span>
        <span>掲載情報は創作資料用の編集データです。最新商品は各公式サイトをご確認ください。</span>
      </div>
    </footer>
  );
}
