"use client";

import Link from "next/link";
import { Check, Copy, Link as LinkIcon, Palette } from "lucide-react";
import { useState, type CSSProperties } from "react";
import { BoardToggle } from "@/components/BoardToggle";
import type { OutfitRecipe } from "@/lib/brands";
import { copyText } from "@/lib/copy-client";
import { getOutfitBrandRecords } from "@/lib/outfits";

type MemoKind = "drawing" | "prose" | "all";
type CopyFeedback = { kind: MemoKind; status: "copied" | "error" } | null;

function MemoCopyButton({ kind, copied, onCopy, title }: { kind: "drawing" | "prose"; copied: boolean; onCopy: () => void; title: string }) {
  const memoName = kind === "drawing" ? "作画メモ" : "描写メモ";
  return (
    <button className="outfit-copy-button" type="button" onClick={onCopy} aria-label={`${title}の${memoName}をコピー`}>
      {copied ? <Check size={14} aria-hidden="true" /> : <Copy size={14} aria-hidden="true" />}
      <span>{copied ? "コピー済み" : "コピー"}</span>
    </button>
  );
}

export function OutfitCard({ outfit }: { outfit: OutfitRecipe }) {
  const [copyFeedback, setCopyFeedback] = useState<CopyFeedback>(null);
  const outfitBrands = getOutfitBrandRecords(outfit);
  const accent = outfitBrands[0]?.accent ?? "#246b5b";

  const fullOutfitText = [
    `# ${outfit.title}`,
    `季節・シーン: ${outfit.season} / ${outfit.scene}`,
    `対象: ${[...outfit.ageGroups, ...outfit.lifeStages, ...outfit.genders].join("・")}`,
    `テイスト: ${outfit.styles.join("・")}`,
    "",
    "## アイテム",
    ...[
      ["アウター", outfit.parts.outer],
      ["トップス", outfit.parts.top],
      ["ボトムス", outfit.parts.bottom],
      ["靴", outfit.parts.shoes],
      ["バッグ", outfit.parts.bag],
      ["小物", outfit.parts.accessory],
    ].filter(([, value]) => value).map(([label, value]) => `- ${label}: ${value}`),
    "",
    `配色: ${outfit.palette.map((color) => `${color.name} (${color.hex})`).join(" / ")}`,
    `素材: ${outfit.materials.join(" / ")}`,
    `シルエット: ${outfit.silhouette}`,
    "",
    "## 作画メモ",
    ...outfit.drawingTips.map((tip) => `- ${tip}`),
    "",
    "## 描写メモ",
    outfit.prose,
    "",
    `参照ブランド: ${outfitBrands.map((brand) => brand.name).join(" / ")}`,
  ].join("\n");

  async function handleCopy(kind: MemoKind, text: string) {
    try {
      await copyText(text);
      setCopyFeedback({ kind, status: "copied" });
    } catch {
      setCopyFeedback({ kind, status: "error" });
    }
    window.setTimeout(() => setCopyFeedback((current) => (current?.kind === kind ? null : current)), 2400);
  }

  const parts = [
    ["アウター", outfit.parts.outer],
    ["トップス", outfit.parts.top],
    ["ボトムス", outfit.parts.bottom],
    ["靴", outfit.parts.shoes],
    ["バッグ", outfit.parts.bag],
    ["小物", outfit.parts.accessory],
  ].filter((part): part is [string, string] => Boolean(part[1]));

  return (
    <article
      id={outfit.id}
      tabIndex={-1}
      className="outfit-recipe-card outfit-library-card"
      style={{ "--brand-accent": accent } as CSSProperties}
    >
      <header className="outfit-library-card-header">
        <div className="outfit-recipe-meta">
          <span>{outfit.season}</span>
          <span>{outfit.scene}</span>
          {outfit.ageGroups.map((ageGroup) => <span key={ageGroup}>{ageGroup}</span>)}
          {outfit.lifeStages.map((lifeStage) => <span key={lifeStage}>{lifeStage}</span>)}
        </div>
        <a className="outfit-anchor-link" href={`#${outfit.id}`} aria-label={`${outfit.title}へのページ内リンク`}>
          <LinkIcon size={16} aria-hidden="true" />
        </a>
      </header>

      <h3>{outfit.title}</h3>
      <div className="outfit-card-tags" aria-label="対象とテイスト">
        {outfit.genders.map((gender) => <span key={gender}>{gender}</span>)}
        {outfit.styles.map((style) => <span key={style}>{style}</span>)}
      </div>

      <dl className="outfit-parts">
        {parts.map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>

      <div className="outfit-palette">
        <span><Palette size={14} aria-hidden="true" /> 配色</span>
        <div aria-hidden="true">
          {outfit.palette.map((color) => <i key={`${color.name}-${color.hex}`} style={{ backgroundColor: color.hex }} />)}
        </div>
        <small>{outfit.palette.map((color) => color.name).join("・")}</small>
      </div>
      <div className="outfit-materials"><strong>素材</strong><span>{outfit.materials.join("・")}</span></div>
      <div className="outfit-silhouette"><strong>シルエット</strong><p>{outfit.silhouette}</p></div>

      <div className="outfit-memo-grid">
        <section className="drawing-tips outfit-memo-panel">
          <div className="outfit-memo-heading">
            <strong>作画メモ</strong>
            <MemoCopyButton
              kind="drawing"
              title={outfit.title}
              copied={copyFeedback?.kind === "drawing" && copyFeedback.status === "copied"}
              onCopy={() => handleCopy("drawing", outfit.drawingTips.join("\n"))}
            />
          </div>
          <ul>{outfit.drawingTips.map((tip) => <li key={tip}>{tip}</li>)}</ul>
        </section>
        <section className="outfit-prose-panel outfit-memo-panel">
          <div className="outfit-memo-heading">
            <strong>描写メモ</strong>
            <MemoCopyButton
              kind="prose"
              title={outfit.title}
              copied={copyFeedback?.kind === "prose" && copyFeedback.status === "copied"}
              onCopy={() => handleCopy("prose", outfit.prose)}
            />
          </div>
          <p className="outfit-prose">{outfit.prose}</p>
        </section>
      </div>
      <div className="outfit-card-actions print-hidden">
        <button className="outfit-copy-all" type="button" onClick={() => handleCopy("all", fullOutfitText)} aria-label={`${outfit.title}のコーデ一式をコピー`}>
          {copyFeedback?.kind === "all" && copyFeedback.status === "copied" ? <Check size={15} aria-hidden="true" /> : <Copy size={15} aria-hidden="true" />}
          {copyFeedback?.kind === "all" && copyFeedback.status === "copied" ? "一式をコピー済み" : "コーデ一式をコピー"}
        </button>
        <BoardToggle type="outfit" itemId={outfit.id} itemName={outfit.title} />
      </div>
      <p className={`outfit-copy-status ${copyFeedback?.status ?? ""}`} role="status" aria-live="polite">
        {copyFeedback ? (copyFeedback.status === "copied" ? `${copyFeedback.kind === "all" ? "コーデ一式" : "メモ"}をコピーしました` : "コピーできませんでした。文章を選択してコピーしてください") : ""}
      </p>

      <footer className="outfit-card-brands">
        <span>参照ブランド</span>
        <div>
          {outfitBrands.map((brand) => <Link key={brand.slug} href={`/brands/${brand.slug}`}>{brand.name}</Link>)}
        </div>
      </footer>
    </article>
  );
}
