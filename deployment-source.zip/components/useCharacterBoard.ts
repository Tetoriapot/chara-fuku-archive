"use client";

import { useCallback, useEffect, useMemo, useSyncExternalStore } from "react";
import catalogIndex from "@/data/catalog-index.json";
import {
  CHARACTER_BOARD_ACTIVE_STORAGE_KEY,
  CHARACTER_BOARD_CHANGE_EVENT,
  CHARACTER_BOARD_LIBRARY_STORAGE_KEY,
  CHARACTER_BOARD_LIBRARY_VERSION,
  CHARACTER_BOARD_STORAGE_KEY,
  MAX_BOARD_BRANDS,
  MAX_BOARD_OUTFITS,
  createEmptyCharacterBoardLibrary,
  createCharacterBoardInLibrary,
  deleteCharacterBoardFromLibrary,
  duplicateCharacterBoardInLibrary,
  importCharacterBoardIntoLibrary,
  normalizeCharacterBoard,
  normalizeCharacterBoardLibrary,
  parseCharacterBoard,
  parseCharacterBoardLibrary,
  resetCharacterBoardInLibrary,
  selectCharacterBoardInLibrary,
  type BoardCatalog,
  type BoardLibraryMutationReason,
  type BoardLibraryMutationResult,
  type CharacterBoard,
  type CharacterBoardLibrary,
} from "@/lib/board-storage";
import type { SearchFilters } from "@/lib/search";

const defaultBoardCatalog: BoardCatalog = catalogIndex;
const EMPTY_EXTERNAL_SNAPSHOT = JSON.stringify(["", "", ""]);

type ExternalSnapshot = {
  libraryRaw: string;
  sessionActiveId: string;
  legacyRaw: string;
};

export type CharacterBoardLibraryActionResult = {
  changed: boolean;
  reason: BoardLibraryMutationReason | "storage";
  boardId?: string;
};

type ToggleResult = {
  changed: boolean;
  reason: "added" | "removed" | "limit" | "missing" | "storage";
  boardId?: string;
};

function subscribe(onStoreChange: () => void) {
  function handleStorage(event: StorageEvent) {
    if (
      event.key === null ||
      event.key === CHARACTER_BOARD_LIBRARY_STORAGE_KEY ||
      event.key === CHARACTER_BOARD_STORAGE_KEY ||
      event.key === CHARACTER_BOARD_ACTIVE_STORAGE_KEY
    ) {
      onStoreChange();
    }
  }
  window.addEventListener("storage", handleStorage);
  window.addEventListener(CHARACTER_BOARD_CHANGE_EVENT, onStoreChange);
  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(CHARACTER_BOARD_CHANGE_EVENT, onStoreChange);
  };
}

function readStorageItem(storage: Storage, key: string) {
  try {
    return storage.getItem(key);
  } catch {
    return null;
  }
}

function getSnapshot() {
  const libraryValue = readStorageItem(localStorage, CHARACTER_BOARD_LIBRARY_STORAGE_KEY);
  const sessionActiveId = readStorageItem(sessionStorage, CHARACTER_BOARD_ACTIVE_STORAGE_KEY) ?? "";
  const legacyValue = libraryValue === null ? readStorageItem(localStorage, CHARACTER_BOARD_STORAGE_KEY) : null;
  return JSON.stringify([libraryValue ?? "", sessionActiveId, legacyValue ?? ""]);
}

function getServerSnapshot() {
  return EMPTY_EXTERNAL_SNAPSHOT;
}

function parseExternalSnapshot(value: string): ExternalSnapshot {
  try {
    const parsed: unknown = JSON.parse(value);
    if (!Array.isArray(parsed)) return { libraryRaw: "", sessionActiveId: "", legacyRaw: "" };
    return {
      libraryRaw: typeof parsed[0] === "string" ? parsed[0] : "",
      sessionActiveId: typeof parsed[1] === "string" ? parsed[1] : "",
      legacyRaw: typeof parsed[2] === "string" ? parsed[2] : "",
    };
  } catch {
    return { libraryRaw: "", sessionActiveId: "", legacyRaw: "" };
  }
}

function libraryFromLegacy(raw: string, catalog: BoardCatalog) {
  const parsed = parseCharacterBoard(raw, catalog);
  return {
    normalized: normalizeCharacterBoardLibrary({
      version: CHARACTER_BOARD_LIBRARY_VERSION,
      activeBoardId: parsed.board.id,
      boards: [parsed.board],
    }, catalog),
    boardRecovered: parsed.recovered,
  };
}

function resolveActiveBoardId(library: CharacterBoardLibrary, preferredId?: string | null) {
  if (preferredId && library.boards.some((board) => board.id === preferredId)) return preferredId;
  if (library.boards.some((board) => board.id === library.activeBoardId)) return library.activeBoardId;
  return library.boards[0].id;
}

function readLatestLibrary(catalog: BoardCatalog) {
  const libraryRaw = readStorageItem(localStorage, CHARACTER_BOARD_LIBRARY_STORAGE_KEY);
  if (libraryRaw !== null) return parseCharacterBoardLibrary(libraryRaw, catalog).library;
  const legacyRaw = readStorageItem(localStorage, CHARACTER_BOARD_STORAGE_KEY);
  if (legacyRaw !== null) return libraryFromLegacy(legacyRaw, catalog).normalized.library;
  return createEmptyCharacterBoardLibrary();
}

function readSessionActiveId() {
  return readStorageItem(sessionStorage, CHARACTER_BOARD_ACTIVE_STORAGE_KEY);
}

function dispatchBoardChange() {
  window.dispatchEvent(new Event(CHARACTER_BOARD_CHANGE_EVENT));
}

export function saveCharacterBoardLibrary(library: CharacterBoardLibrary, catalog: BoardCatalog = {}) {
  const normalized = normalizeCharacterBoardLibrary(library, catalog).library;
  try {
    localStorage.setItem(CHARACTER_BOARD_LIBRARY_STORAGE_KEY, JSON.stringify(normalized));
  } catch {
    return false;
  }

  try {
    sessionStorage.setItem(CHARACTER_BOARD_ACTIVE_STORAGE_KEY, normalized.activeBoardId);
  } catch {
    // The persisted active id remains a usable fallback when sessionStorage is unavailable.
  }
  try {
    localStorage.removeItem(CHARACTER_BOARD_STORAGE_KEY);
  } catch {
    // The v2 value takes precedence, so a legacy backup can safely remain.
  }
  dispatchBoardChange();
  return normalized;
}

export function migrateLegacyCharacterBoard(catalog: BoardCatalog = {}) {
  if (readStorageItem(localStorage, CHARACTER_BOARD_LIBRARY_STORAGE_KEY) !== null) return true;
  const legacyRaw = readStorageItem(localStorage, CHARACTER_BOARD_STORAGE_KEY);
  if (legacyRaw === null) return true;
  return Boolean(saveCharacterBoardLibrary(libraryFromLegacy(legacyRaw, catalog).normalized.library, catalog));
}

/**
 * Compatibility helper: replaces the latest active board without changing its library identity.
 */
export function saveCharacterBoard(board: CharacterBoard, catalog: BoardCatalog = {}) {
  const latest = readLatestLibrary(catalog);
  const activeBoardId = resolveActiveBoardId(latest, readSessionActiveId());
  const index = latest.boards.findIndex((item) => item.id === activeBoardId);
  if (index < 0) return false;
  const nextBoard = normalizeCharacterBoard({
    ...board,
    id: activeBoardId,
    updatedAt: new Date().toISOString(),
  }, catalog).board;
  const boards = [...latest.boards];
  boards[index] = nextBoard;
  return Boolean(saveCharacterBoardLibrary({ ...latest, activeBoardId, boards }, catalog));
}

function publicMutationResult(result: BoardLibraryMutationResult): CharacterBoardLibraryActionResult {
  return {
    changed: result.changed,
    reason: result.reason,
    ...(result.boardId ? { boardId: result.boardId } : {}),
  };
}

export function useCharacterBoard(catalog: BoardCatalog = defaultBoardCatalog) {
  const rawValue = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const external = useMemo(() => parseExternalSnapshot(rawValue), [rawValue]);
  const brandKey = useMemo(() => Array.from(catalog.brandSlugs ?? []).join("\u0000"), [catalog.brandSlugs]);
  const outfitKey = useMemo(() => Array.from(catalog.outfitIds ?? []).join("\u0000"), [catalog.outfitIds]);
  const stableCatalog = useMemo<BoardCatalog>(() => ({
    brandSlugs: brandKey ? brandKey.split("\u0000") : undefined,
    outfitIds: outfitKey ? outfitKey.split("\u0000") : undefined,
  }), [brandKey, outfitKey]);

  const parsed = useMemo(() => {
    if (external.libraryRaw) return parseCharacterBoardLibrary(external.libraryRaw, stableCatalog);
    if (external.legacyRaw) {
      const legacy = libraryFromLegacy(external.legacyRaw, stableCatalog);
      return {
        ...legacy.normalized,
        recovered: legacy.normalized.recovered || legacy.boardRecovered,
      };
    }
    return parseCharacterBoardLibrary(null, stableCatalog);
  }, [external.legacyRaw, external.libraryRaw, stableCatalog]);

  const activeBoardId = resolveActiveBoardId(parsed.library, external.sessionActiveId);
  const collection = useMemo<CharacterBoardLibrary>(() => ({
    ...parsed.library,
    activeBoardId,
  }), [activeBoardId, parsed.library]);
  const board = collection.boards.find((item) => item.id === activeBoardId) ?? collection.boards[0];

  useEffect(() => {
    if (external.libraryRaw || !external.legacyRaw) return;
    migrateLegacyCharacterBoard(stableCatalog);
  }, [external.legacyRaw, external.libraryRaw, stableCatalog]);

  useEffect(() => {
    if (external.sessionActiveId === activeBoardId) return;
    try {
      sessionStorage.setItem(CHARACTER_BOARD_ACTIVE_STORAGE_KEY, activeBoardId);
    } catch {
      return;
    }
    dispatchBoardChange();
  }, [activeBoardId, external.sessionActiveId]);

  const commit = useCallback((updater: CharacterBoard | ((current: CharacterBoard) => CharacterBoard)) => {
    const latest = readLatestLibrary(stableCatalog);
    const targetIndex = latest.boards.findIndex((item) => item.id === activeBoardId);
    if (targetIndex < 0) return false;
    const current = latest.boards[targetIndex];
    const requested = typeof updater === "function" ? updater(current) : updater;
    const next = normalizeCharacterBoard({
      ...requested,
      id: activeBoardId,
      updatedAt: new Date().toISOString(),
    }, stableCatalog).board;
    const boards = [...latest.boards];
    boards[targetIndex] = next;
    return Boolean(saveCharacterBoardLibrary({ ...latest, activeBoardId, boards }, stableCatalog));
  }, [activeBoardId, stableCatalog]);

  const setFields = useCallback((fields: Partial<Omit<CharacterBoard, "version" | "id" | "updatedAt">>) => (
    commit((current) => ({ ...current, ...fields }))
  ), [commit]);

  const toggleBrand = useCallback((slug: string, filters?: SearchFilters, premise?: string): ToggleResult => {
    const latest = readLatestLibrary(stableCatalog);
    const targetIndex = latest.boards.findIndex((item) => item.id === activeBoardId);
    if (targetIndex < 0) return { changed: false, reason: "missing", boardId: activeBoardId };
    const current = latest.boards[targetIndex];
    let reason: ToggleResult["reason"];
    let next: CharacterBoard;

    if (current.brandSlugs.includes(slug)) {
      reason = "removed";
      next = {
        ...current,
        brandSlugs: current.brandSlugs.filter((item) => item !== slug),
        brandReasons: Object.fromEntries(Object.entries(current.brandReasons).filter(([item]) => item !== slug)),
      };
    } else {
      if (current.brandSlugs.length >= MAX_BOARD_BRANDS) return { changed: false, reason: "limit", boardId: activeBoardId };
      reason = "added";
      const hasSavedFilters = Object.values(current.filters).some((value) => value !== "" && value !== null);
      const canSeedContext = !hasSavedFilters && !current.premise.trim() && !current.note.trim() && !current.brandSlugs.length && !current.outfitIds.length;
      next = {
        ...current,
        brandSlugs: [...current.brandSlugs, slug],
        filters: filters && canSeedContext ? filters : current.filters,
        premise: premise?.trim() && canSeedContext ? premise.trim() : current.premise,
      };
    }

    const normalized = normalizeCharacterBoard({ ...next, id: activeBoardId, updatedAt: new Date().toISOString() }, stableCatalog).board;
    const boards = [...latest.boards];
    boards[targetIndex] = normalized;
    const saved = saveCharacterBoardLibrary({ ...latest, activeBoardId, boards }, stableCatalog);
    return saved
      ? { changed: true, reason, boardId: activeBoardId }
      : { changed: false, reason: "storage", boardId: activeBoardId };
  }, [activeBoardId, stableCatalog]);

  const toggleOutfit = useCallback((id: string, filters?: SearchFilters, premise?: string): ToggleResult => {
    const latest = readLatestLibrary(stableCatalog);
    const targetIndex = latest.boards.findIndex((item) => item.id === activeBoardId);
    if (targetIndex < 0) return { changed: false, reason: "missing", boardId: activeBoardId };
    const current = latest.boards[targetIndex];
    let reason: ToggleResult["reason"];
    let next: CharacterBoard;

    if (current.outfitIds.includes(id)) {
      reason = "removed";
      next = { ...current, outfitIds: current.outfitIds.filter((item) => item !== id) };
    } else {
      if (current.outfitIds.length >= MAX_BOARD_OUTFITS) return { changed: false, reason: "limit", boardId: activeBoardId };
      reason = "added";
      const hasSavedFilters = Object.values(current.filters).some((value) => value !== "" && value !== null);
      const canSeedContext = !hasSavedFilters && !current.premise.trim() && !current.note.trim() && !current.brandSlugs.length && !current.outfitIds.length;
      next = {
        ...current,
        outfitIds: [...current.outfitIds, id],
        filters: filters && canSeedContext ? filters : current.filters,
        premise: premise?.trim() && canSeedContext ? premise.trim() : current.premise,
      };
    }

    const normalized = normalizeCharacterBoard({ ...next, id: activeBoardId, updatedAt: new Date().toISOString() }, stableCatalog).board;
    const boards = [...latest.boards];
    boards[targetIndex] = normalized;
    const saved = saveCharacterBoardLibrary({ ...latest, activeBoardId, boards }, stableCatalog);
    return saved
      ? { changed: true, reason, boardId: activeBoardId }
      : { changed: false, reason: "storage", boardId: activeBoardId };
  }, [activeBoardId, stableCatalog]);

  const setBrandReason = useCallback((slug: string, reason: string) => {
    return commit((current) => ({ ...current, brandReasons: { ...current.brandReasons, [slug]: reason } }));
  }, [commit]);

  const persistMutation = useCallback((result: BoardLibraryMutationResult): CharacterBoardLibraryActionResult => {
    if (!result.changed) return publicMutationResult(result);
    if (!saveCharacterBoardLibrary(result.library, stableCatalog)) {
      return { changed: false, reason: "storage", ...(result.boardId ? { boardId: result.boardId } : {}) };
    }
    return publicMutationResult(result);
  }, [stableCatalog]);

  const createBoard = useCallback(() => {
    const latest = readLatestLibrary(stableCatalog);
    const preferredActiveId = resolveActiveBoardId(latest, readSessionActiveId());
    return persistMutation(createCharacterBoardInLibrary({ ...latest, activeBoardId: preferredActiveId }));
  }, [persistMutation, stableCatalog]);

  const duplicateBoard = useCallback((boardId = activeBoardId) => {
    const latest = readLatestLibrary(stableCatalog);
    return persistMutation(duplicateCharacterBoardInLibrary({ ...latest, activeBoardId: boardId }, boardId));
  }, [activeBoardId, persistMutation, stableCatalog]);

  const deleteBoard = useCallback((boardId = activeBoardId) => {
    const latest = readLatestLibrary(stableCatalog);
    return persistMutation(deleteCharacterBoardFromLibrary({ ...latest, activeBoardId }, boardId));
  }, [activeBoardId, persistMutation, stableCatalog]);

  const selectBoard = useCallback((boardId: string) => {
    const latest = readLatestLibrary(stableCatalog);
    const currentActiveId = resolveActiveBoardId(latest, readSessionActiveId());
    return persistMutation(selectCharacterBoardInLibrary({ ...latest, activeBoardId: currentActiveId }, boardId));
  }, [persistMutation, stableCatalog]);

  const importBoard = useCallback((importedBoard: CharacterBoard) => {
    const latest = readLatestLibrary(stableCatalog);
    const preferredActiveId = resolveActiveBoardId(latest, readSessionActiveId());
    return persistMutation(importCharacterBoardIntoLibrary(
      { ...latest, activeBoardId: preferredActiveId },
      importedBoard,
      stableCatalog,
    ));
  }, [persistMutation, stableCatalog]);

  const resetActive = useCallback(() => {
    const latest = readLatestLibrary(stableCatalog);
    return persistMutation(resetCharacterBoardInLibrary({ ...latest, activeBoardId }, activeBoardId));
  }, [activeBoardId, persistMutation, stableCatalog]);

  const clear = useCallback(() => resetActive().changed, [resetActive]);

  return {
    collection,
    boards: collection.boards,
    activeBoardId,
    board,
    staleBrandSlugs: parsed.staleBrandSlugs,
    staleOutfitIds: parsed.staleOutfitIds,
    recovered: parsed.recovered,
    setFields,
    setBrandReason,
    toggleBrand,
    toggleOutfit,
    replaceBoard: commit,
    createBoard,
    duplicateBoard,
    deleteBoard,
    selectBoard,
    importBoard,
    resetActive,
    clear,
    reset() {
      return resetActive().changed;
    },
  };
}
