"use client";

import Link from "next/link";
import { Bell, CircleHelp, ClipboardList, GitCompareArrows, MapPinned, Moon, Search, Shirt, Sun } from "lucide-react";
import { usePathname } from "next/navigation";
import { useSyncExternalStore } from "react";
import {
  CHARACTER_BOARD_LIBRARY_STORAGE_KEY,
  CHARACTER_BOARD_CHANGE_EVENT,
  CHARACTER_BOARD_STORAGE_KEY,
  MAX_CHARACTER_BOARDS,
} from "@/lib/board-constants";

function systemTheme() {
  return window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
}

function subscribeTheme(callback: () => void) {
  function syncThemeFromStorage(event: StorageEvent) {
    if (event.key !== null && event.key !== "theme") return;
    const next = event.newValue === "dark" || event.newValue === "light" ? event.newValue : systemTheme();
    document.documentElement.dataset.theme = next;
    callback();
  }

  const media = window.matchMedia("(prefers-color-scheme: dark)");
  function syncSystemTheme() {
    let saved: string | null = null;
    try {
      saved = localStorage.getItem("theme");
    } catch {
      // 保存領域が利用できない場合はOS設定に追従します。
    }
    if (saved === "dark" || saved === "light") return;
    document.documentElement.dataset.theme = media.matches ? "dark" : "light";
    callback();
  }

  window.addEventListener("chara-theme-change", callback);
  window.addEventListener("storage", syncThemeFromStorage);
  media.addEventListener("change", syncSystemTheme);
  return () => {
    window.removeEventListener("chara-theme-change", callback);
    window.removeEventListener("storage", syncThemeFromStorage);
    media.removeEventListener("change", syncSystemTheme);
  };
}

function getThemeSnapshot() {
  return document.documentElement.dataset.theme === "dark" ? "dark" : "light";
}

function getServerThemeSnapshot() {
  return "light";
}

function subscribeBoard(callback: () => void) {
  function handleStorage(event: StorageEvent) {
    if (!event.key || event.key === CHARACTER_BOARD_STORAGE_KEY || event.key === CHARACTER_BOARD_LIBRARY_STORAGE_KEY) callback();
  }

  window.addEventListener("storage", handleStorage);
  window.addEventListener(CHARACTER_BOARD_CHANGE_EVENT, callback);
  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(CHARACTER_BOARD_CHANGE_EVENT, callback);
  };
}

function getBoardCountSnapshot() {
  try {
    const libraryRaw = localStorage.getItem(CHARACTER_BOARD_LIBRARY_STORAGE_KEY);
    if (libraryRaw !== null) {
      const value: unknown = JSON.parse(libraryRaw);
      if (!value || typeof value !== "object" || Array.isArray(value)) return 0;
      const boards = (value as { boards?: unknown }).boards;
      if (!Array.isArray(boards)) return 0;
      const ids = boards
        .map((item) => item && typeof item === "object" && !Array.isArray(item) ? (item as { id?: unknown }).id : null)
        .filter((id): id is string => typeof id === "string" && id.length > 0);
      return Math.min(new Set(ids).size, MAX_CHARACTER_BOARDS);
    }
    const legacy: unknown = JSON.parse(localStorage.getItem(CHARACTER_BOARD_STORAGE_KEY) ?? "null");
    return legacy && typeof legacy === "object" && !Array.isArray(legacy) ? 1 : 0;
  } catch {
    return 0;
  }
}

function getServerBoardCountSnapshot() {
  return 0;
}

export function SiteHeader() {
  const pathname = usePathname();
  const dark = useSyncExternalStore(subscribeTheme, getThemeSnapshot, getServerThemeSnapshot) === "dark";
  const boardCount = useSyncExternalStore(subscribeBoard, getBoardCountSnapshot, getServerBoardCountSnapshot);

  function currentPage(href: string) {
    return pathname === href || pathname.startsWith(`${href}/`) ? "page" as const : undefined;
  }

  function toggleTheme() {
    const next = document.documentElement.dataset.theme !== "dark";
    document.documentElement.dataset.theme = next ? "dark" : "light";
    try {
      localStorage.setItem("theme", next ? "dark" : "light");
    } catch {
      // 保存領域が利用できなくても、このタブ内ではテーマを切り替えます。
    } finally {
      window.dispatchEvent(new Event("chara-theme-change"));
    }
  }

  return (
    <header className="site-header">
      <div className="shell header-inner">
        <Link href="/" className="brand-lockup" aria-label="キャラ服資料館 ホーム" aria-current={pathname === "/" ? "page" : undefined}>
          <span className="brand-mark" aria-hidden="true">服</span>
          <span>
            <strong>キャラ服資料館</strong>
            <small>CHARACTER FASHION ARCHIVE</small>
          </span>
        </Link>
        <div className="header-actions" role="group" aria-label="サイトメニュー">
          <Link className="header-utility" href="/updates" aria-current={currentPage("/updates")}><Bell size={17} aria-hidden="true" /><span>更新情報</span></Link>
          <button className="header-utility header-theme-toggle" type="button" onClick={toggleTheme} aria-pressed={dark} aria-label={dark ? "ライトモードに切り替える" : "ダークモードに切り替える"}>
            <Moon className="theme-icon theme-icon-light" size={17} aria-hidden="true" />
            <Sun className="theme-icon theme-icon-dark" size={17} aria-hidden="true" />
            <span className="theme-icon-light">ダーク</span><span className="theme-icon-dark">ライト</span>
          </button>
          <Link className="header-utility" href="/help" aria-current={currentPage("/help")}><CircleHelp size={17} aria-hidden="true" /><span>Help</span></Link>
        </div>
      </div>
      <div className="header-nav-row">
        <nav className="shell main-nav" aria-label="メインナビゲーション">
          <Link href="/search" aria-current={currentPage("/search")}>キャラから探す</Link>
          <Link href="/outfits" aria-current={currentPage("/outfits")}>コーデ資料</Link>
          <Link href="/brand-map" aria-current={currentPage("/brand-map")}>ブランドマップ</Link>
          <Link href="/compare" aria-current={currentPage("/compare")}>ブランド比較</Link>
          <Link href="/board" aria-current={currentPage("/board")} aria-label={`保存キャラクター${boardCount}件`}>キャラ管理 ({boardCount})</Link>
        </nav>
      </div>
      <nav className="mobile-nav" aria-label="モバイルナビゲーション">
        <Link href="/search" aria-current={currentPage("/search")}><Search size={19} aria-hidden="true" /><span>探す</span></Link>
        <Link href="/outfits" aria-current={currentPage("/outfits")}><Shirt size={19} aria-hidden="true" /><span>コーデ</span></Link>
        <Link href="/brand-map" aria-current={currentPage("/brand-map")}><MapPinned size={19} aria-hidden="true" /><span>マップ</span></Link>
        <Link href="/compare" aria-current={currentPage("/compare")}><GitCompareArrows size={19} aria-hidden="true" /><span>比較</span></Link>
        <Link href="/board" aria-current={currentPage("/board")} aria-label={`保存キャラクター${boardCount}件`}><ClipboardList size={19} aria-hidden="true" /><span>キャラ {boardCount}</span></Link>
      </nav>
    </header>
  );
}
