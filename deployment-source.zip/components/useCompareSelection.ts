"use client";

import { useMemo, useSyncExternalStore } from "react";
import {
  COMPARE_CHANGE_EVENT,
  COMPARE_STORAGE_KEY,
  MAX_COMPARE_BRANDS,
  parseCompareStorage,
} from "@/lib/compare-storage";

type CompareChangeDetail = {
  message?: string;
};

function subscribe(onStoreChange: () => void) {
  function handleStorage(event: StorageEvent) {
    if (!event.key || event.key === COMPARE_STORAGE_KEY) onStoreChange();
  }

  window.addEventListener("storage", handleStorage);
  window.addEventListener(COMPARE_CHANGE_EVENT, onStoreChange);
  return () => {
    window.removeEventListener("storage", handleStorage);
    window.removeEventListener(COMPARE_CHANGE_EVENT, onStoreChange);
  };
}

function getSnapshot() {
  try {
    return localStorage.getItem(COMPARE_STORAGE_KEY) ?? "";
  } catch {
    return "";
  }
}

function getServerSnapshot() {
  return "";
}

export function saveCompareSelection(slugs: readonly string[], message?: string) {
  const unique = Array.from(new Set(slugs)).slice(0, MAX_COMPARE_BRANDS);
  try {
    if (unique.length) {
      localStorage.setItem(COMPARE_STORAGE_KEY, JSON.stringify(unique));
    } else {
      localStorage.removeItem(COMPARE_STORAGE_KEY);
    }
  } catch {
    // 保存できない環境でも、イベント通知と現在ページの操作は継続します。
  }
  window.dispatchEvent(new CustomEvent<CompareChangeDetail>(COMPARE_CHANGE_EVENT, { detail: { message } }));
}

export function useCompareSelection() {
  const rawValue = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
  const selectedSlugs = useMemo(() => parseCompareStorage(rawValue), [rawValue]);

  return {
    selectedSlugs,
    add(slug: string) {
      if (selectedSlugs.includes(slug)) return { changed: false, reason: "selected" as const };
      if (selectedSlugs.length >= MAX_COMPARE_BRANDS) return { changed: false, reason: "limit" as const };
      saveCompareSelection([...selectedSlugs, slug], "比較候補に追加しました");
      return { changed: true, reason: "added" as const };
    },
    remove(slug: string) {
      saveCompareSelection(selectedSlugs.filter((item) => item !== slug), "比較候補から外しました");
    },
    clear() {
      saveCompareSelection([], "比較候補をクリアしました");
    },
  };
}
