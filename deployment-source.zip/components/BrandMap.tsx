"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { ArrowUpRight, GitCompareArrows, Info, RotateCcw } from "lucide-react";
import type { Brand } from "@/lib/brands";
import { brandQuadrants, getQuadrantBrands } from "@/lib/brand-map";

const genderFilters = ["すべて", "女性", "男性", "ジェンダーレス"] as const;
export type BrandMapRecord = Pick<Brand, "slug" | "name" | "accent" | "gender" | "style" | "priceLevel" | "mapX" | "mapY" | "featured">;

export function BrandMap({ mapBrands, styleOptions }: { mapBrands: BrandMapRecord[]; styleOptions: readonly string[] }) {
  const [gender, setGender] = useState<(typeof genderFilters)[number]>("すべて");
  const [style, setStyle] = useState("");
  const [priceLevel, setPriceLevel] = useState(0);
  const visible = useMemo(() => mapBrands.filter((brand) =>
    (gender === "すべて" || brand.gender.includes(gender)) &&
    (!style || brand.style.includes(style)) &&
    (!priceLevel || brand.priceLevel === priceLevel),
  ), [gender, mapBrands, style, priceLevel]);
  const hasFilters = gender !== "すべて" || Boolean(style) || Boolean(priceLevel);

  function resetFilters() {
    setGender("すべて");
    setStyle("");
    setPriceLevel(0);
  }

  return (
    <div className="map-explorer">
      <div className="map-toolbar">
        <div className="map-filter-stack">
          <div className="segmented" role="group" aria-label="性別で絞り込む">
            {genderFilters.map((item) => (
              <button key={item} type="button" aria-pressed={gender === item} className={gender === item ? "active" : ""} onClick={() => setGender(item)}>{item}</button>
            ))}
          </div>
          <div className="map-select-filters">
            <label><span>テイスト</span><select value={style} onChange={(event) => setStyle(event.target.value)}><option value="">すべて</option>{styleOptions.map((item) => <option value={item} key={item}>{item}</option>)}</select></label>
            <label><span>価格</span><select value={priceLevel} onChange={(event) => setPriceLevel(Number(event.target.value))}><option value={0}>すべて</option>{[1, 2, 3, 4].map((level) => <option value={level} key={level}>{"¥".repeat(level)}</option>)}</select></label>
            {hasFilters && <button className="map-reset" type="button" onClick={resetFilters}><RotateCcw size={14} aria-hidden="true" />クリア</button>}
          </div>
        </div>
        <div className="map-toolbar-meta">
          <p><Info size={16} aria-hidden="true" />位置・価格は編集部による相対的な目安です</p>
          <Link className="map-compare-link" href="/compare"><GitCompareArrows size={16} aria-hidden="true" />ブランドを選んで比較</Link>
        </div>
      </div>

      <div className="map-legend" id="brand-map-legend">
        <span><i className="legend-arrow">↑</i>上ほど価格が高め</span>
        <span><i className="legend-arrow">→</i>右ほどカジュアル</span>
        <span><i className="legend-color" />色はブランドの識別用</span>
        <span><i className="legend-featured" />枠付きは注目ブランド</span>
      </div>
      <p className="map-live-count" role="status" aria-live="polite">現在 {visible.length} ブランドを表示しています</p>

      <section className="brand-map-canvas" aria-labelledby="brand-map-plot-title" aria-describedby="brand-map-legend">
        <h2 className="sr-only" id="brand-map-plot-title">価格帯とテイストのブランド座標図</h2>
        <div className="map-axis-y"><span>価格が高め</span><span>価格が手頃</span></div>
        <div className="map-axis-x"><span>きれいめ</span><span>カジュアル</span></div>
        <div className="map-plot">
          <i className="plot-line plot-line-v" /><i className="plot-line plot-line-h" />
          <span className="quadrant q1">きれいめ・投資型</span>
          <span className="quadrant q2">カジュアル・投資型</span>
          <span className="quadrant q3">きれいめ・手頃</span>
          <span className="quadrant q4">カジュアル・手頃</span>
          {visible.map((brand) => (
            <Link
              key={brand.slug}
              href={`/brands/${brand.slug}`}
              className={`map-point${brand.featured ? " featured" : ""}`}
              style={{ left: `${brand.mapX}%`, top: `${100 - brand.mapY}%`, "--brand-accent": brand.accent } as CSSProperties}
              aria-label={`${brand.name}、価格 ${"¥".repeat(brand.priceLevel)}、${brand.style.slice(0, 2).join("・")}、詳細を見る`}
            >
              <i /> <span>{brand.name}</span>
            </Link>
          ))}
        </div>
      </section>

      <div className="mobile-map-quadrants" aria-label="ポジション別ブランド一覧">
        {brandQuadrants.map((quadrant) => {
          const items = getQuadrantBrands(visible, quadrant.id);
          return (
            <section className="mobile-quadrant-card" key={quadrant.id}>
              <div><p className="eyebrow">{quadrant.id.replace("-", " / ").toUpperCase()}</p><h2>{quadrant.title}</h2><p>{quadrant.description}</p></div>
              {items.length ? <ul>{items.map((brand) => <li key={brand.slug}><Link href={`/brands/${brand.slug}`}><i style={{ background: brand.accent }} /><span><strong>{brand.name}</strong><small>{"¥".repeat(brand.priceLevel)}・{brand.style.slice(0, 2).join(" / ")}</small></span><ArrowUpRight size={16} aria-hidden="true" /></Link></li>)}</ul> : <p className="quadrant-empty">この条件の登録ブランドはありません</p>}
            </section>
          );
        })}
      </div>

      <section className="map-directory" aria-labelledby="map-directory-title">
        <div className="results-header">
          <div><p className="eyebrow">MAP DIRECTORY</p><h2 id="map-directory-title">表示中のブランド</h2></div>
          <span className="result-count"><strong>{visible.length}</strong> 件</span>
        </div>
        {visible.length ? <div className="directory-grid">
          {visible.map((brand) => (
            <Link href={`/brands/${brand.slug}`} key={brand.slug}>
              <i style={{ background: brand.accent }} /><span><strong>{brand.name}</strong><small>{"¥".repeat(brand.priceLevel)}・{brand.style.slice(0, 2).join(" / ")}</small></span><ArrowUpRight size={17} aria-hidden="true" />
            </Link>
          ))}
        </div> : <div className="map-empty"><p>この条件に合うブランドは資料未登録です。</p><button type="button" onClick={resetFilters}>条件をクリア</button></div>}
      </section>
    </div>
  );
}
