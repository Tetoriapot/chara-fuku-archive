"use client";

import { publicPath } from "@/lib/public-path";
import { useEffect, useMemo, useRef, useState } from "react";
import { RotateCcw, SlidersHorizontal, Sparkles, X } from "lucide-react";
import { OutfitCard } from "@/components/OutfitCard";
import { PrintButton } from "@/components/PrintButton";
import {
  emptyOutfitFilters,
  buildOutfitPath,
  filterOutfitRecipes,
  outfitFilterOptions,
  outfitRecipeCount,
  type OutfitFilters,
} from "@/lib/outfits";

function SelectField({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (value: string) => void;
}) {
  return (
    <label className="filter-field">
      <span>{label}</span>
      <select value={value} onChange={(event) => onChange(event.target.value)}>
        <option value="">指定しない</option>
        {options.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
      </select>
    </label>
  );
}

const toOptions = (values: string[]) => values.map((value) => ({ value, label: value }));
const PAGE_SIZE = 12;

export function OutfitExplorer({ initialFilters = emptyOutfitFilters }: { initialFilters?: OutfitFilters }) {
  const [filters, setFilters] = useState<OutfitFilters>({ ...initialFilters });
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const resultsHeadingRef = useRef<HTMLHeadingElement>(null);
  const results = useMemo(() => filterOutfitRecipes(filters), [filters]);
  const visibleResults = results.slice(0, visibleCount);

  useEffect(() => {
    function revealHashTarget() {
      if (!window.location.hash) return;

      let targetId = "";
      try {
        targetId = decodeURIComponent(window.location.hash.slice(1));
      } catch {
        return;
      }

      const targetIndex = results.findIndex((outfit) => outfit.id === targetId);
      if (targetIndex < 0) return;

      const requiredCount = Math.min(
        results.length,
        Math.ceil((targetIndex + 1) / PAGE_SIZE) * PAGE_SIZE,
      );
      setVisibleCount((current) => Math.max(current, requiredCount));

      // Reactが追加カードを反映した後に、旧 /outfits#id リンクの位置へ移動します。
      window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => {
          const target = document.getElementById(targetId);
          target?.scrollIntoView({ block: "start" });
          target?.focus({ preventScroll: true });
        });
      });
    }

    revealHashTarget();
    window.addEventListener("hashchange", revealHashTarget);
    return () => window.removeEventListener("hashchange", revealHashTarget);
  }, [results]);

  function updateFilter(key: keyof OutfitFilters, value: string) {
    const next = { ...filters, [key]: value };
    setFilters(next);
    setVisibleCount(PAGE_SIZE);
    window.history.replaceState(null, "", publicPath(buildOutfitPath(next)));
  }

  function reset() {
    setFilters({ ...emptyOutfitFilters });
    setVisibleCount(PAGE_SIZE);
    window.history.replaceState(null, "", publicPath("/outfits"));
    window.requestAnimationFrame(() => resultsHeadingRef.current?.focus());
  }

  function removeFilter(key: keyof OutfitFilters) {
    updateFilter(key, "");
    window.requestAnimationFrame(() => {
      const nextFilter = document.querySelector<HTMLElement>(".outfit-library-results .active-filters button");
      if (nextFilter) nextFilter.focus();
      else resultsHeadingRef.current?.focus();
    });
  }

  function showMore() {
    const firstNewId = results[visibleResults.length]?.id;
    setVisibleCount((current) => Math.min(current + PAGE_SIZE, results.length));
    window.requestAnimationFrame(() => {
      window.requestAnimationFrame(() => {
        if (firstNewId) document.getElementById(firstNewId)?.focus();
        else resultsHeadingRef.current?.focus();
      });
    });
  }

  const activeFilters = [
    { key: "season", label: filters.season },
    { key: "scene", label: filters.scene },
    { key: "ageGroup", label: filters.ageGroup },
    { key: "lifeStage", label: filters.lifeStage },
    { key: "gender", label: filters.gender },
    { key: "occupation", label: filters.occupation },
    { key: "style", label: filters.style },
    {
      key: "brandSlug",
      label: outfitFilterOptions.brands.find((brand) => brand.slug === filters.brandSlug)?.name ?? "",
    },
  ].filter((filter): filter is { key: keyof OutfitFilters; label: string } => Boolean(filter.label));

  return (
    <div className="outfit-explorer">
      <div className="outfit-library-layout">
        <aside className="filters-panel outfit-filters-panel" aria-label="コーデ資料の絞り込み">
          <div className="filters-title">
            <span><SlidersHorizontal size={18} aria-hidden="true" /> 絞り込み</span>
            <button onClick={reset} type="button"><RotateCcw size={15} aria-hidden="true" />リセット</button>
          </div>
          <SelectField label="季節" value={filters.season} options={toOptions(outfitFilterOptions.seasons)} onChange={(value) => updateFilter("season", value)} />
          <SelectField label="シーン" value={filters.scene} options={toOptions(outfitFilterOptions.scenes)} onChange={(value) => updateFilter("scene", value)} />
          <SelectField label="年代" value={filters.ageGroup} options={toOptions(outfitFilterOptions.ageGroups)} onChange={(value) => updateFilter("ageGroup", value)} />
          <SelectField label="学齢・ライフステージ" value={filters.lifeStage} options={toOptions(outfitFilterOptions.lifeStages)} onChange={(value) => updateFilter("lifeStage", value)} />
          <SelectField label="性別" value={filters.gender} options={toOptions(outfitFilterOptions.genders)} onChange={(value) => updateFilter("gender", value)} />
          <label className="filter-field">
            <span>職業</span>
            <input
              type="search"
              list="outfit-occupation-options"
              value={filters.occupation}
              onChange={(event) => updateFilter("occupation", event.target.value)}
              placeholder="例：保育士、会社員"
            />
            <datalist id="outfit-occupation-options">
              {outfitFilterOptions.occupations.map((occupation) => <option key={occupation} value={occupation} />)}
            </datalist>
          </label>
          <SelectField label="テイスト" value={filters.style} options={toOptions(outfitFilterOptions.styles)} onChange={(value) => updateFilter("style", value)} />
          <SelectField
            label="ブランド"
            value={filters.brandSlug}
            options={outfitFilterOptions.brands.map((brand) => ({ value: brand.slug, label: brand.name }))}
            onChange={(value) => updateFilter("brandSlug", value)}
          />
          <div className="filter-note">
            <Sparkles size={17} aria-hidden="true" />
            <p><strong>資料の使い方</strong>服の組み合わせ、配色、素材、輪郭を土台に、キャラクターらしい着崩しや使い込みを足してください。</p>
          </div>
        </aside>

        <section className="outfit-library-results">
          <div className="results-header">
            <div>
              <p className="eyebrow">OUTFIT RECIPE FILES</p>
              <h2 ref={resultsHeadingRef} tabIndex={-1}>
                {activeFilters.length ? activeFilters.map((filter) => filter.label).join("・") : "すべてのコーデ資料"}
              </h2>
            </div>
            <div className="results-header-actions">
              <PrintButton className="outfit-print-button" label="表示中の資料を印刷" />
              <span className="result-count" role="status" aria-live="polite">
                該当 <strong>{results.length}</strong>件中 {visibleResults.length}件を表示 / 全{outfitRecipeCount}件
              </span>
            </div>
          </div>
          {activeFilters.length > 0 && (
            <div className="active-filters" aria-label="選択中の条件">
              {activeFilters.map((filter) => (
                <button type="button" key={filter.key} onClick={() => removeFilter(filter.key)} aria-label={`${filter.label}の条件を解除`}>
                  {filter.label}<X size={13} aria-hidden="true" />
                </button>
              ))}
            </div>
          )}

          {results.length > 0 ? (
            <>
              <div className="outfit-library-grid">
                {visibleResults.map((outfit) => <OutfitCard key={outfit.id} outfit={outfit} />)}
              </div>
              {visibleResults.length < results.length && (
                <div className="outfit-load-more">
                  <button
                    type="button"
                    onClick={showMore}
                  >
                    もっと見る（次の{Math.min(PAGE_SIZE, results.length - visibleResults.length)}件）
                  </button>
                  <span>{visibleResults.length} / {results.length}件を表示中</span>
                </div>
              )}
            </>
          ) : (
            <div className="empty-state outfit-empty-state">
              <SlidersHorizontal size={36} aria-hidden="true" />
              <h3>この組み合わせの資料はまだ未登録です</h3>
              <p>該当する服装が不自然という意味ではありません。条件をひとつ減らすか、近いテイストで探してみてください。</p>
              <button type="button" onClick={reset}>全{outfitRecipeCount}件の資料を見る</button>
            </div>
          )}

          <p className="outfit-library-note">
            コーデ資料は創作の出発点として編集した例です。年代・性別による服装を固定するものではなく、ブランドの商品展開も時期により変わります。
          </p>
        </section>
      </div>
    </div>
  );
}
