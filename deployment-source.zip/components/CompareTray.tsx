"use client";

import Link from "next/link";
import { GitCompareArrows, Trash2, X } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { saveCompareSelection, useCompareSelection } from "@/components/useCompareSelection";

type CompareCatalogItem = {
  slug: string;
  name: string;
};

export function CompareTray({ catalog }: { catalog: CompareCatalogItem[] }) {
  const { selectedSlugs, remove, clear } = useCompareSelection();
  const [status, setStatus] = useState("");
  const brandNames = useMemo(() => new Map(catalog.map((brand) => [brand.slug, brand.name])), [catalog]);
  const validSlugs = useMemo(() => selectedSlugs.filter((slug) => brandNames.has(slug)), [brandNames, selectedSlugs]);

  useEffect(() => {
    if (validSlugs.length !== selectedSlugs.length) saveCompareSelection(validSlugs);
  }, [selectedSlugs, validSlugs]);

  function focusNextCompareControl() {
    window.setTimeout(() => {
      const candidates = Array.from(document.querySelectorAll<HTMLElement>(
        ".compare-tray-brands button, .compare-tray-actions a, .main-nav a[href$='/compare/'], .mobile-nav a[href$='/compare/'], .main-nav a[href='/compare'], .mobile-nav a[href='/compare']",
      ));
      candidates.find((candidate) => candidate.getClientRects().length > 0)?.focus();
    }, 0);
  }

  function removeFromTray(slug: string) {
    setStatus(`${brandNames.get(slug)}を比較候補から外しました`);
    remove(slug);
    focusNextCompareControl();
  }

  function clearTray() {
    setStatus("比較候補をすべてクリアしました");
    clear();
    focusNextCompareControl();
  }

  const statusRegion = <span className="sr-only" role="status" aria-live="polite">{status}</span>;
  if (!validSlugs.length) return statusRegion;

  const href = `/compare?brands=${encodeURIComponent(validSlugs.join(","))}`;
  return (
    <>
      {statusRegion}
      <div className="compare-tray-spacer" aria-hidden="true" />
      <aside className="compare-tray" aria-label="ブランド比較候補">
        <div className="compare-tray-inner">
          <div className="compare-tray-title">
            <GitCompareArrows size={18} aria-hidden="true" />
            <strong>比較候補</strong>
            <span>{validSlugs.length}/4</span>
          </div>
          <div className="compare-tray-brands">
            {validSlugs.map((slug) => (
              <span key={slug}>
                {brandNames.get(slug)}
                <button type="button" onClick={() => removeFromTray(slug)} aria-label={`${brandNames.get(slug)}を比較候補から外す`}>
                  <X size={13} aria-hidden="true" />
                </button>
              </span>
            ))}
          </div>
          <div className="compare-tray-actions">
            <button type="button" className="compare-tray-clear" onClick={clearTray} aria-label="比較候補をすべてクリア">
              <Trash2 size={15} aria-hidden="true" />
              <span>クリア</span>
            </button>
            <Link href={href}>比較表を開く <GitCompareArrows size={16} aria-hidden="true" /></Link>
          </div>
        </div>
      </aside>
    </>
  );
}
