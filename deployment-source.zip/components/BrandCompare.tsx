"use client";

import { publicPath } from "@/lib/public-path";
import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { BookmarkPlus, Check, Copy, ExternalLink, RotateCcw, Sparkles, X } from "lucide-react";
import { PrintButton } from "@/components/PrintButton";
import { useCharacterBoard } from "@/components/useCharacterBoard";
import { brands, type Brand } from "@/lib/brands";
import { copyText } from "@/lib/copy-client";
import {
  buildCompareHref,
  comparePresets,
  COMPARE_CHANGE_EVENT,
  COMPARE_STORAGE_KEY,
  getCompareBrands,
  getRegisteredOutfitSeasons,
  MAX_COMPARE_BRANDS,
  normalizeCompareSlugs,
  parseStoredCompareSlugs,
} from "@/lib/compare";

type CopyStatus = "idle" | "copied" | "error";

function InlineList({ values, empty = "登録なし" }: { values: readonly string[]; empty?: string }) {
  if (!values.length) return <span className="compare-empty">{empty}</span>;
  return (
    <span className="compare-chip-list">
      {values.map((value) => <span className="compare-chip" key={value}>{value}</span>)}
    </span>
  );
}

function CompareCell({ brand, children }: { brand: Brand; children: React.ReactNode }) {
  return (
    <td>
      <span className="compare-cell-brand" aria-hidden="true">{brand.name}</span>
      {children}
    </td>
  );
}

function escapeMarkdown(value: string) {
  return value.replaceAll("|", "\\|").replaceAll("\n", " ");
}

function buildComparisonMarkdown(selectedBrands: Brand[]) {
  const fields: [string, (brand: Brand) => string][] = [
    ["価格帯", (brand) => `${"¥".repeat(brand.priceLevel)} ${brand.priceLabel}`],
    ["主な年代", (brand) => brand.ageRange.join("・")],
    ["性別", (brand) => `${brand.gender.join("・")}（${brand.genderNote}）`],
    ["テイスト", (brand) => brand.style.join("・")],
    ["シーン", (brand) => brand.scenes.join("・")],
    ["職業・立場", (brand) => brand.occupations.join("・")],
    ["似合う人物像", (brand) => brand.recommendedFor.join("・")],
    ["代表アイテム", (brand) => brand.popularItems.join("・")],
    ["登録コーデ季節", (brand) => getRegisteredOutfitSeasons(brand.slug).join("・") || "未登録"],
    ["公式サイト", (brand) => `[${brand.name}](${brand.officialUrl})`],
  ];
  return [
    "# ブランド比較",
    "",
    `| 比較項目 | ${selectedBrands.map((brand) => escapeMarkdown(brand.name)).join(" | ")} |`,
    `| --- | ${selectedBrands.map(() => "---").join(" | ")} |`,
    ...fields.map(([label, value]) => `| ${label} | ${selectedBrands.map((brand) => escapeMarkdown(value(brand))).join(" | ")} |`),
    "",
    "年代・価格帯・人物像などは、公式サイトの掲載内容を参考に資料館編集部が整理した創作向けの目安です。",
  ].join("\n");
}

export function BrandCompare({ initialSlugs, restoreStoredSelection = true }: { initialSlugs: string[]; restoreStoredSelection?: boolean }) {
  const normalizedInitialSlugs = useMemo(() => normalizeCompareSlugs(initialSlugs), [initialSlugs]);
  const [selectedSlugs, setSelectedSlugs] = useState(normalizedInitialSlugs);
  const [storageReady, setStorageReady] = useState(false);
  const [copyStatus, setCopyStatus] = useState<CopyStatus>("idle");
  const [selectionStatus, setSelectionStatus] = useState("");
  const selectedBrands = useMemo(() => getCompareBrands(selectedSlugs), [selectedSlugs]);
  const { board, setFields } = useCharacterBoard();

  useEffect(() => {
    const restoreTimer = window.setTimeout(() => {
      if (restoreStoredSelection && !normalizedInitialSlugs.length) {
        try {
          const stored = parseStoredCompareSlugs(localStorage.getItem(COMPARE_STORAGE_KEY));
          if (stored.length) setSelectedSlugs(stored);
        } catch {
          // 保存領域が無効な環境でも、比較ページ自体は通常どおり利用できます。
        }
      }
      setStorageReady(true);
    }, 0);
    return () => window.clearTimeout(restoreTimer);
  }, [normalizedInitialSlugs, restoreStoredSelection]);

  useEffect(() => {
    function syncStoredSelection(event?: Event) {
      if (event instanceof StorageEvent && event.key && event.key !== COMPARE_STORAGE_KEY) return;
      let stored: string[] = [];
      try {
        stored = parseStoredCompareSlugs(localStorage.getItem(COMPARE_STORAGE_KEY));
      } catch {
        return;
      }
      setSelectedSlugs((current) => current.length === stored.length && current.every((slug, index) => slug === stored[index]) ? current : stored);
    }
    window.addEventListener("storage", syncStoredSelection);
    window.addEventListener(COMPARE_CHANGE_EVENT, syncStoredSelection);
    return () => {
      window.removeEventListener("storage", syncStoredSelection);
      window.removeEventListener(COMPARE_CHANGE_EVENT, syncStoredSelection);
    };
  }, []);

  useEffect(() => {
    if (!storageReady) return;
    const href = buildCompareHref(selectedSlugs);
    window.history.replaceState(null, "", publicPath(href));
    try {
      if (selectedSlugs.length) {
        localStorage.setItem(COMPARE_STORAGE_KEY, JSON.stringify(selectedSlugs));
      } else {
        localStorage.removeItem(COMPARE_STORAGE_KEY);
      }
    } catch {
      // URLが比較状態の正本なので、端末保存に失敗しても操作を継続します。
    }
    window.dispatchEvent(new CustomEvent(COMPARE_CHANGE_EVENT));
  }, [selectedSlugs, storageReady]);

  function changeSlot(index: number, slug: string) {
    const next = [...selectedSlugs];
    if (!slug) {
      next.splice(index, 1);
    } else {
      next[index] = slug;
    }
    setSelectedSlugs(normalizeCompareSlugs(next));
    setCopyStatus("idle");
  }

  function removeBrand(slug: string, name: string) {
    setSelectedSlugs((current) => current.filter((item) => item !== slug));
    setCopyStatus("idle");
    setSelectionStatus(`${name}を比較から外しました`);
    window.setTimeout(() => {
      const candidates = Array.from(document.querySelectorAll<HTMLElement>(".compare-table thead button, .compare-select-field select"));
      candidates.find((candidate) => candidate.getClientRects().length > 0 && !(candidate instanceof HTMLSelectElement && candidate.disabled))?.focus();
    }, 0);
  }

  async function copyShareUrl() {
    const shareUrl = new URL(publicPath(buildCompareHref(selectedSlugs)), window.location.origin).toString();
    try {
      await copyText(shareUrl);
      setCopyStatus("copied");
    } catch {
      setCopyStatus("error");
    }
  }

  async function copyComparison() {
    try {
      await copyText(buildComparisonMarkdown(selectedBrands));
      setSelectionStatus("比較表をMarkdownでコピーしました");
    } catch {
      setSelectionStatus("比較表をコピーできませんでした");
    }
  }

  function addComparisonToBoard() {
    const characterName = board.name.trim() || "名称未設定のキャラクター";
    const missing = selectedSlugs.filter((slug) => !board.brandSlugs.includes(slug));
    const additions = missing.slice(0, Math.max(0, MAX_COMPARE_BRANDS - board.brandSlugs.length));
    if (!missing.length) {
      setSelectionStatus(`選択中のブランドはすでに「${characterName}」に入っています`);
      return;
    }
    if (!additions.length) {
      setSelectionStatus(`「${characterName}」のブランド候補は4件までです`);
      return;
    }
    const saved = setFields({ brandSlugs: [...board.brandSlugs, ...additions] });
    setSelectionStatus(!saved
      ? "このブラウザではボードを保存できませんでした"
      : missing.length > additions.length
        ? `${additions.length}ブランドを「${characterName}」に追加しました。上限4件に達しています`
        : `${additions.length}ブランドを「${characterName}」に追加しました`);
  }

  return (
    <div className="brand-compare">
      <section className="compare-controls" aria-labelledby="compare-select-heading">
        <div className="compare-controls-heading">
          <div>
            <p className="eyebrow">SELECT UP TO FOUR</p>
            <h2 id="compare-select-heading">比較するブランド</h2>
            <p>最大4件。同じ項目を横に並べて、キャラクター像との相性を見比べられます。</p>
          </div>
          <div className="compare-actions">
            <button className="compare-share-button" type="button" onClick={copyShareUrl} disabled={!selectedSlugs.length}>
              {copyStatus === "copied" ? <Check size={17} aria-hidden="true" /> : <Copy size={17} aria-hidden="true" />}
              {copyStatus === "copied" ? "URLをコピーしました" : "比較URLをコピー"}
            </button>
            <button className="compare-reset-button" type="button" onClick={() => setSelectedSlugs([])} disabled={!selectedSlugs.length}>
              <RotateCcw size={16} aria-hidden="true" />リセット
            </button>
          </div>
        </div>
        <p className={`compare-copy-status ${copyStatus}`} role="status" aria-live="polite">
          {copyStatus === "copied" ? "比較URLをコピーしました。" : copyStatus === "error" ? "コピーできませんでした。ブラウザのアドレス欄からURLをコピーしてください。" : ""}
        </p>
        <span className="sr-only" role="status" aria-live="polite">{selectionStatus}</span>

        <div className="compare-select-grid">
          {Array.from({ length: MAX_COMPARE_BRANDS }, (_, index) => (
            <label className="compare-select-field" key={index}>
              <span>ブランド {index + 1}</span>
              <select
                value={selectedSlugs[index] ?? ""}
                onChange={(event) => changeSlot(index, event.target.value)}
                aria-label={`比較するブランド ${index + 1}`}
              >
                <option value="">選択してください</option>
                {brands.map((brand) => (
                  <option key={brand.slug} value={brand.slug} disabled={selectedSlugs.includes(brand.slug) && selectedSlugs[index] !== brand.slug}>
                    {brand.name}
                  </option>
                ))}
              </select>
            </label>
          ))}
        </div>

        <div className="compare-presets" aria-labelledby="compare-preset-heading">
          <div className="compare-presets-title"><Sparkles size={17} aria-hidden="true" /><h3 id="compare-preset-heading">比較プリセット</h3></div>
          <div className="compare-preset-grid">
            {comparePresets.map((preset) => (
              <button type="button" key={preset.id} onClick={() => { setSelectedSlugs(preset.slugs); setCopyStatus("idle"); }}>
                <strong>{preset.label}</strong>
                <span>{preset.description}</span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {selectedBrands.length ? (
        <section className="compare-results" aria-labelledby="compare-results-heading">
          <div className="compare-results-heading">
            <div>
              <p className="eyebrow">SIDE-BY-SIDE</p>
              <h2 id="compare-results-heading">{selectedBrands.length}ブランドを比較</h2>
            </div>
            <div className="compare-results-tools print-hidden">
              <button className="compare-print-button" type="button" onClick={copyComparison}><Copy size={16} aria-hidden="true" />比較表をコピー</button>
              <button className="compare-print-button" type="button" onClick={addComparisonToBoard}><BookmarkPlus size={16} aria-hidden="true" />ボードに追加</button>
              <PrintButton className="compare-print-button" label="現在の比較を印刷" />
            </div>
          </div>
          <div className="compare-table-scroll" tabIndex={0} role="region" aria-label="ブランド比較表。左右にスクロールできます">
            <table className="compare-table">
              <caption className="sr-only">選択したブランドの価格、対象年代、テイスト、利用シーンなどの比較</caption>
              <thead>
                <tr>
                  <th scope="col">比較項目</th>
                  {selectedBrands.map((brand) => (
                    <th scope="col" key={brand.slug} style={{ borderTopColor: brand.accent }}>
                      <span className="compare-brand-number">BRAND {String(selectedBrands.indexOf(brand) + 1).padStart(2, "0")}</span>
                      <Link href={`/brands/${brand.slug}`}>{brand.name}</Link>
                      <button type="button" onClick={() => removeBrand(brand.slug, brand.name)} aria-label={`${brand.name}を比較から外す`}><X size={15} aria-hidden="true" /></button>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">価格帯</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><strong className="compare-price">{"¥".repeat(brand.priceLevel)}</strong><span>{brand.priceLabel}</span></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">主な年代</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.ageRange} /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">性別</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.gender} /><small>{brand.genderNote}</small></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">テイスト</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.style} /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">シーン</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.scenes} /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">職業・立場</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.occupations} /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">似合う人物像</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.recommendedFor} /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">代表アイテム</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={brand.popularItems} /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">登録コーデ季節</th>
                  {selectedBrands.map((brand) => <CompareCell brand={brand} key={brand.slug}><InlineList values={getRegisteredOutfitSeasons(brand.slug)} empty="コーデ未登録" /></CompareCell>)}
                </tr>
                <tr>
                  <th scope="row">公式サイト</th>
                  {selectedBrands.map((brand) => (
                    <CompareCell brand={brand} key={brand.slug}>
                      <a className="compare-official-link" href={brand.officialUrl} target="_blank" rel="noreferrer">公式サイトを見る <ExternalLink size={15} aria-hidden="true" /></a>
                    </CompareCell>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
          <p className="compare-editorial-note">年代・価格帯・人物像などは、公式サイトの掲載内容を参考に資料館編集部が整理した創作向けの目安です。</p>
        </section>
      ) : (
        <section className="compare-empty-state" aria-live="polite">
          <span aria-hidden="true">服</span>
          <h2>比べたいブランドを選んでください</h2>
          <p>迷ったときは、上のプリセットから始められます。</p>
        </section>
      )}
    </div>
  );
}
