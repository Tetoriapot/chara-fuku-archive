"use client";

import { Printer } from "lucide-react";

export function PrintButton({
  label,
  className = "print-button",
}: {
  label: string;
  className?: string;
}) {
  return (
    <button className={`${className} print-hidden`} type="button" onClick={() => window.print()}>
      <Printer size={16} aria-hidden="true" />
      {label}
    </button>
  );
}
