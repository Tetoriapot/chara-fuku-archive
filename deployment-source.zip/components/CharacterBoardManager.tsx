"use client";

import { publicPath } from "@/lib/public-path";
import Link from "next/link";
import {
  Check,
  Clipboard,
  Copy,
  ExternalLink,
  FileText,
  Link as LinkIcon,
  Plus,
  Printer,
  RotateCcw,
  Share2,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useCharacterBoard } from "@/components/useCharacterBoard";
import {
  MAX_BOARD_BRANDS,
  MAX_BOARD_OUTFITS,
  MAX_CHARACTER_BOARDS,
  decodeCharacterBoardFragment,
  encodeCharacterBoardFragment,
  type BoardCatalog,
  type CharacterBoard,
} from "@/lib/board-storage";
import { copyText } from "@/lib/copy-client";
import { buildFilterSummary } from "@/lib/search";
import { buildSearchPath } from "@/lib/search-state";

export type BoardBrandDTO = {
  slug: string;
  name: string;
  officialUrl: string;
  priceLabel: string;
  ageRange: string[];
  styles: string[];
};

export type BoardOutfitDTO = {
  id: string;
  title: string;
  season: string;
  scene: string;
  brandSlugs: string[];
  parts: {
    outer?: string;
    top: string;
    bottom: string;
    shoes: string;
    bag: string;
    accessory?: string;
  };
  prose: string;
};

function displayCharacterName(board: CharacterBoard) {
  return board.name.trim() || "名称未設定のキャラクター";
}

function buildRosterMeta(board: CharacterBoard) {
  return board.premise.trim() || `${board.brandSlugs.length}ブランド・${board.outfitIds.length}コーデ`;
}

function buildMarkdown(
  name: string,
  premise: string,
  filterLabels: string[],
  brands: BoardBrandDTO[],
  outfits: BoardOutfitDTO[],
  reasons: Record<string, string>,
  note: string,
  updatedAt: string,
) {
  const lines = [
    `# ${name || "名称未設定のキャラクター"}`,
    "",
    premise || "（一文設定は未入力）",
    "",
    "## 検索条件",
    "",
    filterLabels.length ? filterLabels.map((label) => `- ${label}`).join("\n") : "- 条件未設定",
    "",
    "## ブランド候補",
    "",
  ];
  if (brands.length) {
    brands.forEach((brand) => {
      lines.push(`### [${brand.name}](${brand.officialUrl})`, "", reasons[brand.slug] || "（選んだ理由は未入力）", "");
    });
  } else {
    lines.push("- 未選択", "");
  }
  lines.push("## コーデ候補", "");
  if (outfits.length) {
    outfits.forEach((outfit) => {
      const parts = [outfit.parts.outer, outfit.parts.top, outfit.parts.bottom, outfit.parts.shoes, outfit.parts.bag, outfit.parts.accessory].filter(Boolean);
      lines.push(`### ${outfit.title}`, "", `- 季節・シーン: ${outfit.season} / ${outfit.scene}`, `- 構成: ${parts.join(" / ")}`, `- 描写メモ: ${outfit.prose}`, "");
    });
  } else {
    lines.push("- 未選択", "");
  }
  lines.push(
    "## 自由メモ",
    "",
    note || "（メモは未入力）",
    "",
    "---",
    `更新: ${Date.parse(updatedAt) > 0 ? new Intl.DateTimeFormat("ja-JP", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Tokyo" }).format(new Date(updatedAt)) : "未保存"}`,
    "出典: キャラ服資料館（ブランド・価格帯・人物像は創作向けの編集目安です）",
  );
  return lines.join("\n");
}

export function CharacterBoardManager({ brands, outfits }: { brands: BoardBrandDTO[]; outfits: BoardOutfitDTO[] }) {
  const catalog = useMemo<BoardCatalog>(() => ({
    brandSlugs: brands.map((brand) => brand.slug),
    outfitIds: outfits.map((outfit) => outfit.id),
  }), [brands, outfits]);
  const {
    boards,
    activeBoardId,
    board,
    staleBrandSlugs,
    staleOutfitIds,
    recovered,
    setFields,
    setBrandReason,
    toggleBrand,
    toggleOutfit,
    replaceBoard,
    createBoard,
    duplicateBoard,
    deleteBoard,
    selectBoard,
    importBoard,
    resetActive,
  } = useCharacterBoard(catalog);
  const [status, setStatus] = useState("");
  const [pendingDeleteId, setPendingDeleteId] = useState<string | null>(null);
  const importedRef = useRef(false);
  const deleteDialogRef = useRef<HTMLDialogElement>(null);
  const pendingDeleteBoard = boards.find((item) => item.id === pendingDeleteId);

  const selectedBrands = board.brandSlugs
    .map((slug) => brands.find((brand) => brand.slug === slug))
    .filter((brand): brand is BoardBrandDTO => Boolean(brand));
  const selectedOutfits = board.outfitIds
    .map((id) => outfits.find((outfit) => outfit.id === id))
    .filter((outfit): outfit is BoardOutfitDTO => Boolean(outfit));
  const filterLabels = buildFilterSummary(board.filters).map((item) => item.label);
  const updatedLabel = Date.parse(board.updatedAt) > 0
    ? new Intl.DateTimeFormat("ja-JP", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Tokyo" }).format(new Date(board.updatedAt))
    : "まだ内容は保存されていません";
  const staleCount = staleBrandSlugs.length + staleOutfitIds.length;
  const recoveryStatus = recovered
    ? staleCount
      ? `保存データに含まれる現在未登録の候補${staleCount}件を除外しました`
      : "保存データの壊れた項目を安全な初期値に戻しました"
    : "";

  useEffect(() => {
    if (importedRef.current || !window.location.hash.includes("board=")) return undefined;
    const timer = window.setTimeout(() => {
      importedRef.current = true;
      const decoded = decodeCharacterBoardFragment(window.location.hash, catalog);
      if (decoded.error) {
        setStatus(decoded.error === "too-large" ? "共有データが大きすぎるため読み込めませんでした" : "共有URLのボードデータを読み込めませんでした");
        return;
      }
      const result = importBoard(decoded.board);
      if (result.reason === "limit") {
        importedRef.current = false;
        setStatus(`共有キャラクターを追加できません。保存上限${MAX_CHARACTER_BOARDS}件に達しています。不要なキャラクターを削除すると再試行できます`);
        return;
      }
      if (result.reason === "storage") {
        importedRef.current = false;
        setStatus("このブラウザでは共有キャラクターを保存できませんでした。URLはそのまま残しています");
        return;
      }
      if (result.reason === "existing" && result.boardId) {
        selectBoard(result.boardId);
        history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
        setStatus("同じ共有キャラクターは保存済みです。該当キャラクターを開きました");
        return;
      }
      if (!result.changed) {
        setStatus("共有キャラクターを読み込めませんでした。URLはそのまま残しています");
        return;
      }
      history.replaceState(null, "", `${window.location.pathname}${window.location.search}`);
      const importedStaleCount = decoded.staleBrandSlugs.length + decoded.staleOutfitIds.length;
      setStatus(importedStaleCount ? `共有キャラクターを新規追加し、現在未登録の候補${importedStaleCount}件を除外しました` : "共有キャラクターを新しいキャラクターとして追加しました");
    }, 0);
    return () => window.clearTimeout(timer);
  }, [catalog, importBoard, selectBoard]);

  useEffect(() => {
    if (!recovered && !staleBrandSlugs.length && !staleOutfitIds.length) return undefined;
    const timer = window.setTimeout(() => {
      if (!importedRef.current) {
        if (replaceBoard(board)) {
          if (recoveryStatus) setStatus(recoveryStatus);
        } else {
          setStatus("保存データを修復できませんでした。ブラウザの保存設定をご確認ください");
        }
      }
    }, 0);
    return () => window.clearTimeout(timer);
  }, [board, recovered, recoveryStatus, replaceBoard, staleBrandSlugs, staleOutfitIds]);

  async function copyMarkdown() {
    try {
      await copyText(buildMarkdown(board.name, board.premise, filterLabels, selectedBrands, selectedOutfits, board.brandReasons, board.note, board.updatedAt));
      setStatus("キャラクターボードをMarkdownでコピーしました");
    } catch {
      setStatus("コピーできませんでした。ブラウザの権限をご確認ください");
    }
  }

  function boardUrl() {
    const url = new URL(publicPath("/board"), window.location.href);
    url.hash = encodeCharacterBoardFragment(board).slice(1);
    return url.toString();
  }

  async function shareBoard() {
    const url = boardUrl();
    if (navigator.share) {
      try {
        await navigator.share({ title: board.name || "キャラクターボード", text: board.premise || "キャラ服資料館で作成したキャラクターボード", url });
        setStatus("共有メニューを開きました");
        return;
      } catch (error) {
        if (error instanceof DOMException && error.name === "AbortError") return;
      }
    }
    try {
      await copyText(url);
      setStatus("共有URLをコピーしました");
    } catch {
      setStatus("共有URLをコピーできませんでした");
    }
  }

  async function copyUrl() {
    try {
      await copyText(boardUrl());
      setStatus("共有URLをコピーしました");
    } catch {
      setStatus("共有URLをコピーできませんでした");
    }
  }

  function updateBoardFields(fields: Partial<Pick<CharacterBoard, "name" | "premise" | "note">>) {
    setStatus(setFields(fields) ? "" : "このブラウザでは変更を保存できませんでした");
  }

  function updateBrandReason(slug: string, reason: string) {
    setStatus(setBrandReason(slug, reason) ? "" : "このブラウザでは選んだ理由を保存できませんでした");
  }

  function removeBoardBrand(slug: string, name: string) {
    const result = toggleBrand(slug);
    if (!result.changed) {
      setStatus("このブラウザではブランド候補を更新できませんでした");
      return;
    }
    setStatus(`${name}をキャラクターボードから外しました`);
    window.setTimeout(() => {
      const nextButton = document.querySelector<HTMLElement>(".board-brand-item button");
      if (nextButton) nextButton.focus();
      else document.getElementById("board-brands-heading")?.focus();
    }, 0);
  }

  function removeBoardOutfit(id: string, title: string) {
    const result = toggleOutfit(id);
    if (!result.changed) {
      setStatus("このブラウザではコーデ候補を更新できませんでした");
      return;
    }
    setStatus(`${title}をキャラクターボードから外しました`);
    window.setTimeout(() => {
      const nextButton = document.querySelector<HTMLElement>(".board-outfit-item button");
      if (nextButton) nextButton.focus();
      else document.getElementById("board-outfits-heading")?.focus();
    }, 0);
  }

  function focusRosterBoard(boardId?: string) {
    if (!boardId) return;
    window.setTimeout(() => document.getElementById(`board-roster-${boardId}`)?.focus(), 0);
  }

  function selectCharacter(boardId: string) {
    const target = boards.find((item) => item.id === boardId);
    const result = selectBoard(boardId);
    if (result.reason === "missing") {
      setStatus("このキャラクターは別のタブで削除されたため開けませんでした");
      return;
    }
    if (result.reason === "storage") {
      setStatus("このブラウザでは選択状態を保存できませんでした");
      return;
    }
    if (result.changed) setStatus(`「${target ? displayCharacterName(target) : "キャラクター"}」を開きました`);
  }

  function createCharacter() {
    const result = createBoard();
    if (result.reason === "limit") {
      setStatus(`キャラクターは${MAX_CHARACTER_BOARDS}件まで保存できます`);
      return;
    }
    if (!result.changed) {
      setStatus(result.reason === "storage" ? "このブラウザでは新しいキャラクターを保存できませんでした" : "新しいキャラクターを作成できませんでした");
      return;
    }
    setStatus("新しいキャラクターを作成しました。名前と設定を入力してください");
    focusRosterBoard(result.boardId);
  }

  function duplicateCharacter() {
    const sourceName = displayCharacterName(board);
    const result = duplicateBoard(activeBoardId);
    if (result.reason === "limit") {
      setStatus(`複製できません。キャラクターは${MAX_CHARACTER_BOARDS}件まで保存できます`);
      return;
    }
    if (!result.changed) {
      setStatus(result.reason === "missing" ? "このキャラクターは別のタブで削除されています" : "このブラウザではキャラクターを複製できませんでした");
      return;
    }
    setStatus(`「${sourceName}」を複製しました`);
    focusRosterBoard(result.boardId);
  }

  function requestDeleteCharacter() {
    setPendingDeleteId(activeBoardId);
    const dialog = deleteDialogRef.current;
    if (dialog?.showModal) {
      dialog.showModal();
      return;
    }
    if (window.confirm(`「${displayCharacterName(board)}」を削除しますか？ この操作は元に戻せません。`)) {
      confirmDeleteCharacter(activeBoardId);
    }
  }

  function closeDeleteDialog() {
    deleteDialogRef.current?.close();
    setPendingDeleteId(null);
  }

  function confirmDeleteCharacter(requestedBoardId = pendingDeleteId) {
    if (!requestedBoardId) {
      closeDeleteDialog();
      return;
    }
    const target = boards.find((item) => item.id === requestedBoardId);
    const deletedName = target ? displayCharacterName(target) : "キャラクター";
    const result = deleteBoard(requestedBoardId);
    closeDeleteDialog();
    if (!result.changed) {
      setStatus(result.reason === "missing" ? "このキャラクターはすでに削除されています" : "このブラウザではキャラクターを削除できませんでした");
      return;
    }
    setStatus(result.reason === "last-reset" ? "最後のキャラクターを削除し、新しい空のキャラクターを用意しました" : `「${deletedName}」を削除しました`);
    focusRosterBoard(result.boardId);
  }

  function clearBoard() {
    const characterName = displayCharacterName(board);
    if (!window.confirm(`「${characterName}」の設定・候補・メモを空にしますか？ キャラクター自体は一覧に残ります。`)) return;
    const result = resetActive();
    if (!result.changed) {
      setStatus(result.reason === "missing" ? "このキャラクターは別のタブで削除されています" : "このブラウザではキャラクターの内容を空にできませんでした");
      return;
    }
    history.replaceState(null, "", publicPath("/board"));
    setStatus(`「${characterName}」の内容を空にしました`);
  }

  return (
    <div className="character-board-manager">
      <section className="board-editor-card board-roster-card" aria-labelledby="board-roster-heading">
        <div className="board-roster-heading">
          <div><p className="eyebrow">CHARACTERS</p><h2 id="board-roster-heading"><Users size={22} aria-hidden="true" /> 保存したキャラクター</h2></div>
          <span className="board-roster-count">{boards.length} / {MAX_CHARACTER_BOARDS}</span>
        </div>
        <ul className="board-roster-list" aria-label="保存したキャラクターを選択">
          {boards.map((item) => {
            const active = item.id === activeBoardId;
            const name = displayCharacterName(item);
            return (
              <li className="board-roster-entry" key={item.id}>
                <button
                  id={`board-roster-${item.id}`}
                  className="board-roster-option"
                  type="button"
                  aria-pressed={active}
                  aria-current={active ? "true" : undefined}
                  aria-label={`${name}${active ? "、編集中" : "を開く"}`}
                  onClick={() => selectCharacter(item.id)}
                >
                  <span className="board-roster-name">{name}</span>
                  <span className="board-roster-meta">{buildRosterMeta(item)}</span>
                  {active ? <span className="board-roster-current"><Check size={13} aria-hidden="true" />編集中</span> : null}
                </button>
              </li>
            );
          })}
        </ul>
        <span id="board-roster-limit" className="sr-only">このブラウザには最大{MAX_CHARACTER_BOARDS}件まで保存できます。</span>
        <div className="board-roster-actions">
          <button className="board-roster-primary-action" type="button" onClick={createCharacter} disabled={boards.length >= MAX_CHARACTER_BOARDS} aria-describedby="board-roster-limit"><Plus size={17} aria-hidden="true" /> 新しいキャラクター</button>
          <button className="board-roster-secondary-action" type="button" onClick={duplicateCharacter} disabled={boards.length >= MAX_CHARACTER_BOARDS} aria-describedby="board-roster-limit"><Copy size={16} aria-hidden="true" /> このキャラを複製</button>
          <button className="board-roster-danger-action" type="button" onClick={requestDeleteCharacter}><Trash2 size={16} aria-hidden="true" /> このキャラを削除</button>
        </div>
      </section>

      <section className="board-editor-card board-character-card" aria-labelledby="board-character-heading">
        <div className="board-section-heading">
          <div><p className="eyebrow">CHARACTER</p><h2 id="board-character-heading">キャラクター設定</h2></div>
          <span className="board-save-indicator"><Check size={15} aria-hidden="true" /><span>この端末に自動保存<small>更新: {updatedLabel}</small></span></span>
        </div>
        <div className="board-character-fields">
          <label><span>キャラクター名</span><input value={board.name} maxLength={80} placeholder="例：佐倉みのり" onChange={(event) => updateBoardFields({ name: event.target.value })} /></label>
          <label><span>一文設定</span><input value={board.premise} maxLength={400} placeholder="例：書店でアルバイトをする、物静かな大学2年生" onChange={(event) => updateBoardFields({ premise: event.target.value })} /></label>
        </div>
        <div className="board-filter-summary">
          <div className="board-filter-heading"><strong>検索条件</strong><Link href={buildSearchPath(board.premise, board.filters)}>条件を検索で開く</Link></div>
          {filterLabels.length ? <ul>{filterLabels.map((label) => <li key={label}>{label}</li>)}</ul> : <p>まだ条件がありません。検索結果から候補を追加すると、そのときの条件も保存できます。</p>}
        </div>
      </section>

      <section className="board-editor-card board-brands-card" aria-labelledby="board-brands-heading">
        <div className="board-section-heading"><div><p className="eyebrow">BRANDS</p><h2 id="board-brands-heading" tabIndex={-1}>ブランド候補</h2></div><span>{selectedBrands.length} / {MAX_BOARD_BRANDS}</span></div>
        {selectedBrands.length ? (
          <div className="board-brand-list">
            {selectedBrands.map((brand) => (
              <article className="board-brand-item" key={brand.slug}>
                <div className="board-item-heading">
                  <div><h3><Link href={`/brands/${brand.slug}`}>{brand.name}</Link></h3><p>{brand.priceLabel} ・ {brand.ageRange.join("・")} ・ {brand.styles.join("・")}</p></div>
                  <div className="board-item-actions">
                    <a href={brand.officialUrl} target="_blank" rel="noreferrer">公式サイト <ExternalLink size={14} aria-hidden="true" /></a>
                    <button type="button" onClick={() => removeBoardBrand(brand.slug, brand.name)} aria-label={`${brand.name}をボードから外す`}><X size={17} aria-hidden="true" /></button>
                  </div>
                </div>
                <label><span>このキャラクターに合う理由</span><textarea rows={2} maxLength={600} value={board.brandReasons[brand.slug] ?? ""} placeholder="例：気負わない服装でも清潔感を保ちたい人物像に合う" onChange={(event) => updateBrandReason(brand.slug, event.target.value)} /></label>
              </article>
            ))}
          </div>
        ) : <div className="board-empty-state"><p>ブランド候補はまだありません。</p><Link href="/search">キャラクター条件から探す</Link></div>}
      </section>

      <section className="board-editor-card" aria-labelledby="board-outfits-heading">
        <div className="board-section-heading"><div><p className="eyebrow">OUTFITS</p><h2 id="board-outfits-heading" tabIndex={-1}>コーデ候補</h2></div><span>{selectedOutfits.length} / {MAX_BOARD_OUTFITS}</span></div>
        {selectedOutfits.length ? (
          <div className="board-outfit-list">
            {selectedOutfits.map((outfit) => (
              <article className="board-outfit-item" key={outfit.id}>
                <div className="board-item-heading">
                  <div><p className="board-item-meta">{outfit.season} ・ {outfit.scene}</p><h3><Link href={`/outfits#${outfit.id}`}>{outfit.title}</Link></h3></div>
                  <button type="button" onClick={() => removeBoardOutfit(outfit.id, outfit.title)} aria-label={`${outfit.title}をボードから外す`}><X size={17} aria-hidden="true" /></button>
                </div>
                <dl className="board-outfit-parts">
                  {outfit.parts.outer ? <div><dt>アウター</dt><dd>{outfit.parts.outer}</dd></div> : null}
                  <div><dt>トップス</dt><dd>{outfit.parts.top}</dd></div>
                  <div><dt>ボトムス</dt><dd>{outfit.parts.bottom}</dd></div>
                  <div><dt>靴</dt><dd>{outfit.parts.shoes}</dd></div>
                  <div><dt>バッグ</dt><dd>{outfit.parts.bag}</dd></div>
                  {outfit.parts.accessory ? <div><dt>小物</dt><dd>{outfit.parts.accessory}</dd></div> : null}
                </dl>
                <p>{outfit.prose}</p>
              </article>
            ))}
          </div>
        ) : <div className="board-empty-state"><p>コーデ候補はまだありません。</p><Link href="/outfits">コーデ資料集から探す</Link></div>}
      </section>

      <section className="board-editor-card" aria-labelledby="board-note-heading">
        <div className="board-section-heading"><div><p className="eyebrow">MEMO</p><h2 id="board-note-heading">自由メモ</h2></div><FileText size={22} aria-hidden="true" /></div>
        <label className="board-note-field"><span className="sr-only">自由メモ</span><textarea rows={8} maxLength={8000} value={board.note} placeholder="服の着崩し方、持ち物、場面による変化などを自由に記録できます。" onChange={(event) => updateBoardFields({ note: event.target.value })} /></label>
      </section>

      <section className="board-actions-card" aria-labelledby="board-output-heading">
        <div><p className="eyebrow">OUTPUT</p><h2 id="board-output-heading">ボードを書き出す</h2><p>文章資料としてコピーするか、URLで他の端末へ共有できます。</p></div>
        <div className="board-output-actions">
          <button type="button" onClick={copyMarkdown}><Clipboard size={17} aria-hidden="true" /> Markdownをコピー</button>
          <button type="button" onClick={shareBoard}><Share2 size={17} aria-hidden="true" /> 共有</button>
          <button type="button" onClick={copyUrl}><LinkIcon size={17} aria-hidden="true" /> URLをコピー</button>
          <button type="button" onClick={() => window.print()}><Printer size={17} aria-hidden="true" /> 印刷</button>
        </div>
      </section>

      <aside className="board-local-notice">
        <strong>保存について</strong>
        <p>最大{MAX_CHARACTER_BOARDS}件のキャラクターを、ログインなしでこのブラウザのlocalStorageに保存します。閲覧データを消すと失われるため、残したい設定はキャラクターごとにMarkdown・共有URL・印刷でも保管してください。共有URLのデータは「#」以降に入り、サーバーへ検索条件として送信されません。</p>
      </aside>

      <div className="board-danger-zone">
        <button type="button" onClick={clearBoard}><Trash2 size={16} aria-hidden="true" /> このキャラの内容を空にする</button>
        <Link href="/search"><RotateCcw size={16} aria-hidden="true" /> 別の条件から探す</Link>
      </div>
      <p className="board-status" role="status" aria-live="polite">{status || recoveryStatus}</p>

      <dialog ref={deleteDialogRef} className="board-delete-dialog" aria-labelledby="board-delete-heading" aria-describedby="board-delete-description" onClose={() => setPendingDeleteId(null)}>
        <div className="board-delete-dialog-card">
          <p className="eyebrow">DELETE CHARACTER</p>
          <h2 id="board-delete-heading">「{pendingDeleteBoard ? displayCharacterName(pendingDeleteBoard) : "キャラクター"}」を削除しますか？</h2>
          <p id="board-delete-description">このキャラクターの設定、ブランド候補、コーデ候補、メモがこの端末から削除されます。この操作は元に戻せません。</p>
          <div className="board-dialog-actions">
            <button type="button" onClick={closeDeleteDialog}>キャンセル</button>
            <button className="board-roster-danger-action" type="button" onClick={() => confirmDeleteCharacter()}><Trash2 size={16} aria-hidden="true" /> 削除する</button>
          </div>
        </div>
      </dialog>
    </div>
  );
}
