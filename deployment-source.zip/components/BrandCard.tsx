import Link from "next/link";
import { ArrowUpRight, Banknote, Users } from "lucide-react";
import type { CSSProperties } from "react";
import type { Brand } from "@/lib/brands";
import { getContrastText, getInitials } from "@/lib/brands";

export function BrandCard({ brand, compact = false }: { brand: Brand; compact?: boolean }) {
  return (
    <Link
      href={`/brands/${brand.slug}`}
      className={`brand-card${compact ? " compact" : ""}`}
      style={{ "--brand-accent": brand.accent, "--brand-on-accent": getContrastText(brand.accent) } as CSSProperties}
    >
      <div className="brand-card-top">
        <span className="brand-avatar" aria-hidden="true">{getInitials(brand.name)}</span>
        <ArrowUpRight size={19} aria-hidden="true" />
      </div>
      <div>
        <p className="eyebrow">BRAND FILE</p>
        <h3>{brand.name}</h3>
        {!compact && <p className="brand-description">{brand.description}</p>}
      </div>
      <div className="brand-meta">
        <span><Banknote size={15} aria-hidden="true" /> 価格 {"¥".repeat(brand.priceLevel)}</span>
        <span><Users size={15} aria-hidden="true" /> {brand.ageRange.slice(0, 2).join("・")}</span>
      </div>
      <div className="tag-row">
        {brand.style.slice(0, compact ? 2 : 3).map((style) => <span key={style}>{style}</span>)}
      </div>
    </Link>
  );
}
