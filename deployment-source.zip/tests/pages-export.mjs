import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";

const repository = process.env.GITHUB_REPOSITORY || "Tetoriapot/chara-fuku-archive";
const [owner, name] = repository.split("/");
const base = process.env.NEXT_PUBLIC_BASE_PATH ?? (name.toLowerCase() === `${owner.toLowerCase()}.github.io` ? "" : `/${name}`);
const site = process.env.NEXT_PUBLIC_SITE_URL || `https://${owner.toLowerCase()}.github.io${base}`;
const output = new URL("../out/", import.meta.url);

test("exports every page and referenced local asset under the Pages base path", async () => {
  const brands = JSON.parse(await readFile(new URL("../data/brands.json", import.meta.url), "utf8"));
  const routes = ["", "search", "outfits", "compare", "board", "brand-map", "updates", "help", ...brands.map(({ slug }) => `brands/${slug}`)];
  for (const route of routes) {
    const html = await readFile(new URL(`${route ? `${route}/` : ""}index.html`, output), "utf8");
    assert.match(html, /id="main-content"/);
    assert.match(html, /lang="ja"/);
    for (const [, value] of html.matchAll(/(?:href|src|action)="(\/[^\"]*)"/g)) {
      assert.ok(value.startsWith(`${base}/`), `${route}: ${value} must include the base path`);
      if (value.includes("/_next/")) await access(new URL(value.slice(base.length + 1).split("?")[0], output));
    }
  }
  await access(new URL("404.html", output));
  await access(new URL(".nojekyll", output));
  const html = await readFile(new URL("brands/uniqlo/index.html", output), "utf8");
  assert.ok(html.includes(`${site}/brands/uniqlo`));
  assert.ok(html.includes(`${site}/og-p0.png`));
  const sitemap = await readFile(new URL("sitemap.xml", output), "utf8");
  assert.ok(sitemap.includes(`${site}/brands/uniqlo`));
  assert.ok(!sitemap.includes("chatgpt.site"));
});
