import assert from "node:assert/strict";
import { access, readFile } from "node:fs/promises";
import test from "node:test";
import { listOutfitSourceNames } from "../scripts/outfit-source-files.mjs";

async function render(pathname = "/") {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}-${pathname}`);
  const { default: worker } = await import(workerUrl.href);

  return worker.fetch(
    new Request(`http://localhost${pathname}`, { headers: { accept: "text/html" } }),
    { ASSETS: { fetch: async () => new Response("Not found", { status: 404 }) } },
    { waitUntil() {}, passThroughOnException() {} },
  );
}

function assertHasAccessibleMain(html) {
  const skipLink = html.indexOf('<a class="skip-link" href="#main-content">本文へ移動</a>');
  const mainLandmark = html.search(/<main\b[^>]*\bid="main-content"/);

  assert.ok(skipLink >= 0, "the skip link is server-rendered");
  assert.ok(mainLandmark >= 0, "the skip link target exists on the page");
  assert.ok(skipLink < mainLandmark, "the skip link precedes the main content");
}

function extractJsonLd(html) {
  return [...html.matchAll(/<script\b[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/g)]
    .map((match) => JSON.parse(match[1]));
}

function withoutReactTextBoundaries(html) {
  return html.replaceAll("<!-- -->", "");
}

test("server-renders the finished character fashion archive", async () => {
  const response = await render();
  assert.equal(response.status, 200);
  assert.match(response.headers.get("content-type") ?? "", /^text\/html\b/i);

  const html = await response.text();
  assertHasAccessibleMain(html);
  assert.match(html, /<html lang="ja">/i);
  assert.match(html, /<title>キャラ服資料館｜このキャラなら何を着る？<\/title>/);
  assert.match(html, /そのキャラ、/);
  assert.match(html, /キャラクターから服を探す/);
  assert.doesNotMatch(html, /<(?:img|picture|canvas|video)\b/);
  assert.match(html, /aria-label="収録資料から探す"/);
  assert.match(html, /THE ARCHIVE/);
  assert.match(html, /href="\/updates"/);
  assert.match(html, /href="\/help"/);
  assert.match(html, /aria-label="ダークモードに切り替える"/);
  assert.doesNotMatch(html, /href="\/outfits\/visual/);
  assert.match(html, /ブランドマップ/);
  assert.match(html, /キャラクターを管理/);
  assert.match(html, /LOWRYS FARM/);
  assert.match(html, /og:image/);
  assert.doesNotMatch(html, /codex-preview|Your site is taking shape|react-loading-skeleton/i);
});

test("keeps brand content data-driven and removes starter preview assets", async () => {
  const dataDirectory = new URL("../data/", import.meta.url);
  const outfitSourceNames = await listOutfitSourceNames(dataDirectory);
  const [brandSource, generatedOutfitSource, catalogIndexSource, packageJson, outfitCollections] = await Promise.all([
    readFile(new URL("../data/brands.json", import.meta.url), "utf8"),
    readFile(new URL("../data/outfits.generated.json", import.meta.url), "utf8"),
    readFile(new URL("../data/catalog-index.json", import.meta.url), "utf8"),
    readFile(new URL("../package.json", import.meta.url), "utf8"),
    Promise.all(outfitSourceNames.map((name) => readFile(new URL(name, dataDirectory), "utf8").then(JSON.parse))),
  ]);
  const brands = JSON.parse(brandSource);
  const outfits = outfitCollections.flat();
  const generatedOutfits = JSON.parse(generatedOutfitSource);
  const catalogIndex = JSON.parse(catalogIndexSource);
  const knownSlugs = new Set(brands.map((brand) => brand.slug));
  const allowedGenders = new Set(["女性", "男性", "ジェンダーレス"]);
  const allowedSeasons = new Set(["春", "夏", "秋", "冬"]);
  const allowedScenes = new Set(["普段着", "通勤", "通学", "デート", "フォーマル", "部屋着", "買い物", "冠婚葬祭"]);
  const allowedAgeGroups = new Set(["10代以下", "10代", "20代", "30代", "40代", "50代", "60代以上"]);
  const allowedLifeStages = new Set(["幼児", "小学生", "中学生", "高校生", "大学生", "新社会人", "社会人", "子育て中", "シニア"]);
  const allowedBrandStyles = new Set(["カジュアル", "ナチュラル", "ストリート", "韓国系", "量産型", "地雷系", "シンプル", "オフィスカジュアル"]);
  const allowedOutfitStyles = new Set([...allowedBrandStyles, "きれいめ", "スポーティ", "モード", "アウトドア", "フェミニン", "フォーマル"]);

  assert.ok(brands.length >= 30, "at least 30 sample brands are available");
  assert.equal(knownSlugs.size, brands.length, "brand slugs are unique");
  assert.ok(outfitSourceNames.length >= 4, "the catalog is split into a base file and expansion files");
  assert.deepEqual(generatedOutfits, outfits, "the generated outfit catalog stays synchronized with every source collection");
  assert.deepEqual(catalogIndex.brandSlugs, brands.map((brand) => brand.slug), "the lightweight board brand index stays synchronized");
  assert.deepEqual(catalogIndex.outfitIds, outfits.map((outfit) => outfit.id), "the lightweight board outfit index stays synchronized");
  for (const brand of brands) {
    assert.equal(typeof brand.slug, "string");
    assert.match(brand.slug, /^[a-z0-9]+(?:-[a-z0-9]+)*$/, `invalid brand slug: ${brand.slug}`);
    assert.match(brand.officialUrl, /^https:\/\//);
    assert.match(brand.accent, /^#[0-9a-f]{6}$/i, `invalid accent: ${brand.slug}`);
    assert.ok(Number.isInteger(brand.priceLevel) && brand.priceLevel >= 1 && brand.priceLevel <= 4, `invalid priceLevel: ${brand.slug}`);
    assert.ok(Number.isFinite(brand.mapX) && brand.mapX >= 0 && brand.mapX <= 100, `invalid mapX: ${brand.slug}`);
    assert.ok(Number.isFinite(brand.mapY) && brand.mapY >= 0 && brand.mapY <= 100, `invalid mapY: ${brand.slug}`);
    assert.ok(Array.isArray(brand.ageRange));
    assert.ok(Array.isArray(brand.style));
    assert.ok(brand.gender.length > 0 && brand.gender.every((value) => allowedGenders.has(value)), `invalid gender taxonomy: ${brand.slug}`);
    assert.ok(brand.style.length > 0 && brand.style.every((value) => allowedBrandStyles.has(value)), `invalid style taxonomy: ${brand.slug}`);
    assert.ok(brand.scenes.every((value) => allowedScenes.has(value)), `invalid scene taxonomy: ${brand.slug}`);
    assert.ok(brand.related.every((slug) => knownSlugs.has(slug) && slug !== brand.slug), `invalid related slug: ${brand.slug}`);
    assert.ok(Array.isArray(brand.recommendedFor));
    assert.ok(Array.isArray(brand.popularItems));
    assert.match(brand.updatedAt, /^\d{4}-\d{2}-\d{2}$/);
    assert.match(brand.officialUrlCheckedAt, /^\d{4}-\d{2}-\d{2}$/);
    assert.ok(["high", "medium", "low"].includes(brand.confidence));
    assert.ok(brand.editorialNote.length > 20);
    assert.ok(brand.sources.some((source) => source.kind === "official" && source.url === brand.officialUrl));
  }

  assert.ok(outfits.length >= 108, "the expanded catalog includes at least 108 outfit recipes");
  assert.equal(new Set(outfits.map((outfit) => outfit.id)).size, outfits.length, "outfit ids are unique");
  for (const season of allowedSeasons) {
    assert.ok(outfits.filter((outfit) => outfit.season === season).length >= 24, `${season} has broad outfit coverage`);
  }
  for (const ageGroup of allowedAgeGroups) {
    assert.ok(outfits.filter((outfit) => outfit.ageGroups.includes(ageGroup)).length >= 4, `${ageGroup} has outfit coverage`);
  }
  for (const lifeStage of allowedLifeStages) {
    assert.ok(outfits.some((outfit) => outfit.lifeStages.includes(lifeStage)), `${lifeStage} has outfit coverage`);
  }
  for (const scene of allowedScenes) {
    assert.ok(outfits.filter((outfit) => outfit.scene === scene).length >= 2, `${scene} has outfit coverage`);
  }
  const usedSlugs = new Set();
  for (const outfit of outfits) {
    assert.ok(Array.isArray(outfit.ageGroups) && outfit.ageGroups.length > 0);
    assert.ok(Array.isArray(outfit.lifeStages));
    assert.ok(allowedSeasons.has(outfit.season), `invalid outfit season: ${outfit.id}`);
    assert.ok(outfit.ageGroups.every((value) => allowedAgeGroups.has(value)), `invalid outfit age group: ${outfit.id}`);
    assert.ok(outfit.lifeStages.every((value) => allowedLifeStages.has(value)), `invalid outfit life stage: ${outfit.id}`);
    assert.ok(outfit.genders.length > 0 && outfit.genders.every((value) => allowedGenders.has(value)), `invalid outfit gender: ${outfit.id}`);
    assert.ok(outfit.styles.length > 0 && outfit.styles.every((value) => allowedOutfitStyles.has(value)), `invalid outfit style: ${outfit.id}`);
    assert.ok(!outfit.lifeStages.includes("20代"), "age groups do not leak into life-stage tags");
    assert.ok(outfit.parts.top && outfit.parts.bottom && outfit.parts.shoes && outfit.parts.bag);
    assert.ok(outfit.palette.length >= 3 && outfit.palette.every((color) => color.name && /^#[0-9a-f]{6}$/i.test(color.hex)));
    assert.ok(outfit.materials.length && outfit.drawingTips.length && outfit.silhouette && outfit.prose);
    for (const slug of outfit.brandSlugs) {
      assert.ok(knownSlugs.has(slug), `unknown outfit brand slug: ${slug}`);
      usedSlugs.add(slug);
    }
  }
  assert.equal(usedSlugs.size, brands.length, "all brands have at least one outfit recipe");
  for (const season of ["春", "夏", "秋", "冬"]) {
    const seasonalBrands = new Set(outfits.filter((outfit) => outfit.season === season).flatMap((outfit) => outfit.brandSlugs));
    assert.ok(seasonalBrands.size > 0 && seasonalBrands.size < brands.length, `${season} narrows the brand list`);
  }

  assert.doesNotMatch(packageJson, /react-loading-skeleton/);
  await assert.rejects(access(new URL("../app/_sites-preview/SkeletonPreview.tsx", import.meta.url)));
});


test("keeps exact age, life stage, and occupation as separate search conditions", async () => {
  const response = await render("/search?q=22%E6%AD%B3%20%E5%A5%B3%E6%80%A7%20%E5%A4%A7%E5%AD%A6%E7%94%9F%20%E3%82%A4%E3%83%B3%E3%83%89%E3%82%A2%20%E5%A4%8F");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assert.match(html, /22歳（20代データで判定）・大学生・女性・夏・キーワード：インドア/);
  assert.doesNotMatch(html, /大学生・大学生/);
  assert.match(html, /登録データ一致度 \d+%・\d+\/\d+項目/);
  assert.match(html, /判定に使った条件/);
  assert.match(html, /すべての判定項目に登録根拠がある候補だけ/);
  assert.match(html, /人気順位・実際の着用率・ブランド公式の推奨ではありません/);
  assert.doesNotMatch(html, /全指定条件の同時一致コーデあり/);
  assert.match(html, /編集データ更新：2026年7月20日/);
  assert.match(html, /確度：中（編集部推定を含む）/);
  assert.match(html, /根拠と出典を見る/);
  assert.doesNotMatch(html, /おすすめ \d+|設定一致/);

  const exactOutfitResponse = await render(`/search?q=${encodeURIComponent("10代 春 普段着 ストリート")}`);
  const exactOutfitHtml = withoutReactTextBoundaries(await exactOutfitResponse.text());
  assert.match(exactOutfitHtml, /REGISTERED OUTFIT MATCHES/);
  assert.match(exactOutfitHtml, /この設定のコーデ候補/);
  assert.match(exactOutfitHtml, /登録条件 4\/4一致/);
  assert.match(exactOutfitHtml, /春の高校生・放課後ストリート/);
  assert.match(exactOutfitHtml, /href="\/outfits#hs-spring-casual"/);
  assert.match(exactOutfitHtml, /ボードに追加/);
  assert.match(exactOutfitHtml, /年代・性別・季節などの構造条件を同時に満たす登録コーデあり/);
  assert.match(exactOutfitHtml, /春の同時一致コーデあり/);
  assert.match(exactOutfitHtml, /編集部作成の資料コーデ/);

  const mixedRole = await render("/search?q=%E5%A4%A7%E5%AD%A6%E7%94%9F%20%E4%BF%9D%E8%82%B2%E5%A3%AB");
  const mixedRoleHtml = await mixedRole.text();
  assert.match(mixedRoleHtml, /大学生・保育士/);
  assert.doesNotMatch(mixedRoleHtml, /大学生・大学生/);
  assert.match(mixedRoleHtml, /この条件を同時に満たす登録コーデはまだありません/);
  assert.match(mixedRoleHtml, /条件を自動では緩めていません/);
});

test("uses registered outfit evidence to narrow a season-only search", async () => {
  const unfiltered = await render("/search");
  const unfilteredHtml = withoutReactTextBoundaries(await unfiltered.text());
  assert.match(unfilteredHtml, /<span>掲載 01<\/span>/);
  assert.doesNotMatch(unfilteredHtml, /設定一致/);

  const response = await render("/search?q=%E5%A4%8F");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());
  const count = html.match(/class="result-count"[^>]*><strong>(\d+)<\/strong> 件/);

  assert.ok(count, "season result count is rendered");
  assert.ok(Number(count[1]) > 0 && Number(count[1]) < 36, "season does not match every brand");
  assert.match(html, /夏の同時一致コーデあり/);

  const invalidAge = await render("/search?q=122%E6%AD%B3");
  const invalidAgeHtml = withoutReactTextBoundaries(await invalidAge.text());
  assert.match(invalidAgeHtml, /class="result-count"[^>]*><strong>0<\/strong> 件/);
  assert.match(invalidAgeHtml, /年齢として解釈できません。0〜99歳で入力してください。/);
  assert.match(invalidAgeHtml, /検索条件を修正してください/);

  const unknownKeyword = await render("/search?q=%E5%AE%87%E5%AE%99%E9%A3%9B%E8%A1%8C%E5%A3%AB%20%E5%A4%8F");
  const unknownKeywordHtml = withoutReactTextBoundaries(await unknownKeyword.text());
  assert.match(unknownKeywordHtml, /「宇宙飛行士」は当館の登録語に直接一致しません。/);
  assert.match(unknownKeywordHtml, /登録済みブランド内に、基準を満たす資料候補がありませんでした/);
});

test("serves the expanded age, life-stage, and scene combinations", async () => {
  const outfits = JSON.parse(
    await readFile(new URL("../data/outfits.generated.json", import.meta.url), "utf8"),
  );
  const preschoolSearch = await render("/search?q=%E5%B9%BC%E5%85%90");
  assert.equal(preschoolSearch.status, 200);
  const preschoolHtml = withoutReactTextBoundaries(await preschoolSearch.text());
  assert.match(preschoolHtml, /幼児/);
  assert.match(preschoolHtml, /登録データ一致度/);
  assert.match(preschoolHtml, /class="result-count"[^>]*><strong>[1-9]\d*<\/strong> 件/);

  const seniorRoom = await render("/outfits?scene=%E9%83%A8%E5%B1%8B%E7%9D%80&ageGroup=60%E4%BB%A3%E4%BB%A5%E4%B8%8A");
  assert.equal(seniorRoom.status, 200);
  const seniorRoomHtml = withoutReactTextBoundaries(await seniorRoom.text());
  assert.match(seniorRoomHtml, /<h2[^>]*>部屋着・60代以上<\/h2>/);
  assert.match(seniorRoomHtml, /該当 <strong>[1-9]\d*<\/strong>件中/);

  const ceremonial = await render("/outfits?scene=%E5%86%A0%E5%A9%9A%E8%91%AC%E7%A5%AD");
  assert.equal(ceremonial.status, 200);
  const ceremonialHtml = withoutReactTextBoundaries(await ceremonial.text());
  const ceremonialCount = outfits.filter((outfit) => outfit.scene === "冠婚葬祭").length;
  assert.match(ceremonialHtml, /<h2[^>]*>冠婚葬祭<\/h2>/);
  assert.match(ceremonialHtml, new RegExp(`該当 <strong>${ceremonialCount}<\\/strong>件中`));

  const outfitOnlyOccupation = await render("/search?q=%E4%BB%8B%E8%AD%B7%E8%81%B7");
  assert.equal(outfitOnlyOccupation.status, 200);
  const outfitOnlyOccupationHtml = withoutReactTextBoundaries(await outfitOnlyOccupation.text());
  assert.match(outfitOnlyOccupationHtml, /介護職/);
  assert.match(outfitOnlyOccupationHtml, /登録データ一致度/);
  assert.match(outfitOnlyOccupationHtml, /class="result-count"[^>]*><strong>[1-9]\d*<\/strong> 件/);
});

test("renders outfit recipes and editorial provenance on brand details", async () => {
  const response = await render("/brands/lowrys-farm");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assert.match(html, /季節・シーン別コーデ処方箋/);
  assert.match(html, /作画ポイント/);
  assert.match(html, /情報の見方と出典/);
  assert.match(html, /id="sources"/);
  assert.match(html, /公式情報を確認し、編集部が資料向けに整理/);
  assert.match(html, /2026年7月20日/);
  assert.match(html, /中（編集部推定を含む）/);
  assert.match(html, /LOWRYS FARM 公式サイト/);
  assert.match(html, /ブランド資料を印刷/);
  assert.match(html, /ボードに追加/);

  assert.equal((await render("/brand-map")).status, 200);
  assert.equal((await render("/brands/not-a-real-brand")).status, 404);
});

test("server-renders a lightweight first outfit batch and preserves URL filters", async () => {
  const outfitCount = JSON.parse(
    await readFile(new URL("../data/outfits.generated.json", import.meta.url), "utf8"),
  ).length;
  const response = await render("/outfits");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assertHasAccessibleMain(html);
  assert.match(html, /<h1>コーデ資料集<\/h1>/);
  assert.match(html, new RegExp(`該当 <strong>${outfitCount}<\\/strong>件中 12件を表示 \\/ 全${outfitCount}件`));
  assert.equal(
    (html.match(/class="outfit-recipe-card outfit-library-card"/g) ?? []).length,
    12,
    "the first 12 outfit recipes are server-rendered without hydrating every card",
  );
  assert.ok(Buffer.byteLength(html) < 120_000, "the initial outfit HTML stays below 120 KB");
  assert.ok((html.match(/<[a-z][^>]*>/gi) ?? []).length < 2_000, "the initial outfit DOM stays below 2,000 elements");
  assert.match(html, /もっと見る（次の12件）/);
  assert.match(html, /表示中の資料を印刷/);
  assert.match(html, /コーデ一式をコピー/);
  assert.match(html, /作画メモ/);
  assert.match(html, /描写メモ/);

  const filteredResponse = await render("/outfits?season=%E5%A4%8F&brand=uniqlo");
  assert.equal(filteredResponse.status, 200);
  const filteredHtml = withoutReactTextBoundaries(await filteredResponse.text());
  assert.match(filteredHtml, /<h2[^>]*>夏・UNIQLO<\/h2>/);
  const filteredCount = filteredHtml.match(new RegExp(`class="result-count"[^>]*>\\s*該当 <strong>(\\d+)<\\/strong>件中 (\\d+)件を表示 \\/ 全${outfitCount}件`));
  assert.ok(filteredCount, "the filtered recipe count is rendered");
  assert.ok(Number(filteredCount[1]) > 0 && Number(filteredCount[1]) < outfitCount);
  assert.equal(Number(filteredCount[2]), Math.min(12, Number(filteredCount[1])));

  const outfits = JSON.parse(
    await readFile(new URL("../data/outfits.generated.json", import.meta.url), "utf8"),
  );
  const occupation = "介護職";
  const occupationCount = outfits.filter((outfit) => outfit.occupations.includes(occupation)).length;
  const occupationResponse = await render(`/outfits?occupation=${encodeURIComponent(occupation)}`);
  assert.equal(occupationResponse.status, 200);
  const occupationHtml = withoutReactTextBoundaries(await occupationResponse.text());
  assert.match(occupationHtml, new RegExp(`<h2[^>]*>${occupation}<\\/h2>`));
  assert.match(
    occupationHtml,
    new RegExp(`該当 <strong>${occupationCount}<\\/strong>件中 ${Math.min(12, occupationCount)}件を表示 \\/ 全${outfitCount}件`),
  );
  assert.match(occupationHtml, new RegExp(`aria-label="${occupation}の条件を解除"`));

  const invalidOccupationHtml = withoutReactTextBoundaries(
    await (await render("/outfits?occupation=not-a-registered-occupation")).text(),
  );
  assert.match(invalidOccupationHtml, /<h2[^>]*>not-a-registered-occupation<\/h2>/);
  assert.match(invalidOccupationHtml, /該当 <strong>0<\/strong>件中 0件を表示/);
  assert.match(invalidOccupationHtml, /この組み合わせの資料はまだ未登録です/);
});

test("provides Help and update pages and removes the visual library route", async () => {
  for (const path of ["/help", "/updates"]) {
    const response = await render(path);
    assert.equal(response.status, 200);
    const html = await response.text();
    assertHasAccessibleMain(html);
    assert.match(html, new RegExp('<a[^>]*href="' + path + '"[^>]*aria-current="page"'));
    assert.doesNotMatch(html, /href="\/outfits\/visual/);
  }
  const helpHtml = await (await render("/help")).text();
  assert.match(helpHtml, /<details>/);
  assert.match(helpHtml, /別の端末へ自動同期はされません/);
  assert.match(helpHtml, /ライトモードとダークモード/);
  const updatesHtml = await (await render("/updates")).text();
  assert.match(updatesHtml, /dateTime="2026-09-26"|datetime="2026-09-26"/);
  assert.match(updatesHtml, /トップページとサイトメニューをリニューアル/);
  const removed = await render("/outfits/visual");
  assert.equal(removed.status, 404);
});

test("server-renders local character management as a private creator workspace", async () => {
  const response = await render("/board");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assertHasAccessibleMain(html);
  assert.match(html, /<meta name="robots" content="noindex, follow"/);
  assert.match(html, /キャラごとに、似合う服を一枚ずつ。/);
  assert.match(html, /保存したキャラクター/);
  assert.match(html, /1 \/ 12/);
  assert.match(html, /新しいキャラクター/);
  assert.match(html, /このキャラを複製/);
  assert.match(html, /このキャラを削除/);
  assert.match(html, /編集中/);
  assert.match(html, /aria-pressed="true"/);
  assert.match(html, /キャラクター名/);
  assert.match(html, /ブランド候補/);
  assert.match(html, /コーデ候補/);
  assert.match(html, /Markdownをコピー/);
  assert.match(html, /共有URLのデータは「#」以降/);
  assert.doesNotMatch(html, /localStorageに1件だけ保存/);
  assert.match(html, /href="\/board" aria-current="page"/);
  const canonicalTag = html.match(/<link\b[^>]*rel="canonical"[^>]*>/)?.[0] ?? "";
  assert.match(canonicalTag, /href="https:\/\/chara-fuku-archive\.tetoriapot\.chatgpt\.site\/board"/);
});

test("marks the current section in desktop and mobile navigation", async () => {
  for (const path of ["/search", "/outfits", "/brand-map", "/compare", "/board"]) {
    const response = await render(path);
    assert.equal(response.status, 200);
    const html = await response.text();
    const siteHeader = html.match(/<header class="site-header">[\s\S]*?<\/header>/)?.[0] ?? "";
    assert.equal((siteHeader.match(/aria-current="page"/g) ?? []).length, 2, `${path} marks one desktop and one mobile link`);
  }
});

test("normalizes comparison URLs to four unique registered brands", async () => {
  const response = await render("/compare?brands=UNIQLO,gu,not-a-brand,uniqlo,beams,ships,vis");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assertHasAccessibleMain(html);
  assert.match(html, /<h2 id="compare-results-heading">4ブランドを比較<\/h2>/);
  const tableHead = html.match(/<thead>([\s\S]*?)<\/thead>/)?.[1] ?? "";
  assert.equal((tableHead.match(/class="compare-brand-number"/g) ?? []).length, 4);
  for (const slug of ["uniqlo", "gu", "beams", "ships"]) {
    assert.match(tableHead, new RegExp(`href="/brands/${slug}"`));
  }
  assert.doesNotMatch(tableHead, /href="\/brands\/vis"/);
  assert.doesNotMatch(tableHead, /not-a-brand/);
  assert.match(html, /比較表をコピー/);
  assert.match(html, /現在の比較を印刷/);
});

test("renders the brand map as four readable mobile quadrants", async () => {
  const response = await render("/brand-map");
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assertHasAccessibleMain(html);
  assert.match(html, /<meta property="og:site_name" content="キャラ服資料館"/);
  assert.match(html, /<meta property="og:locale" content="ja_JP"/);
  assert.match(html, /<meta property="og:type" content="website"/);
  assert.match(html, /<meta name="twitter:title" content="ブランドマップ \| キャラ服資料館"/);
  const mobileQuadrants = html.match(/<div class="mobile-map-quadrants"[\s\S]*?<section class="map-directory"/)?.[0] ?? "";
  assert.equal((mobileQuadrants.match(/class="mobile-quadrant-card"/g) ?? []).length, 4);
  for (const title of [
    "きれいめ × 高価格",
    "カジュアル × 高価格",
    "きれいめ × 手頃",
    "カジュアル × 手頃",
  ]) {
    assert.match(mobileQuadrants, new RegExp(`<h2>${title}</h2>`));
  }
  assert.match(html, /aria-label="ポジション別ブランド一覧"/);
  assert.match(html, /role="status" aria-live="polite">現在 \d+ ブランドを表示しています/);
});

test("publishes crawl directives and every indexable route in the sitemap", async () => {
  const robotsResponse = await render("/robots.txt");
  assert.equal(robotsResponse.status, 200);
  assert.match(robotsResponse.headers.get("content-type") ?? "", /^text\/plain\b/i);
  const robots = await robotsResponse.text();
  assert.match(robots, /User-Agent: \*/i);
  assert.match(robots, /Allow: \//i);
  assert.match(robots, /Sitemap: https:\/\/chara-fuku-archive\.tetoriapot\.chatgpt\.site\/sitemap\.xml/i);
  assert.match(robots, /Host: https:\/\/chara-fuku-archive\.tetoriapot\.chatgpt\.site/i);

  const sitemapResponse = await render("/sitemap.xml");
  assert.equal(sitemapResponse.status, 200);
  assert.match(sitemapResponse.headers.get("content-type") ?? "", /^(application|text)\/xml\b/i);
  const sitemap = await sitemapResponse.text();
  const brands = JSON.parse(await readFile(new URL("../data/brands.json", import.meta.url), "utf8"));
  const locations = [...sitemap.matchAll(/<loc>(.*?)<\/loc>/g)].map((match) => match[1]);

  assert.equal(locations.length, brands.length + 6);
  assert.equal(new Set(locations).size, locations.length, "sitemap URLs are unique");
  for (const path of ["", "/outfits", "/brand-map", "/compare", "/updates", "/help"]) {
    assert.ok(locations.includes(`https://chara-fuku-archive.tetoriapot.chatgpt.site${path}`));
  }
  for (const brand of brands) {
    assert.ok(locations.includes(`https://chara-fuku-archive.tetoriapot.chatgpt.site/brands/${brand.slug}`));
  }
  assert.ok(!locations.some((location) => location.includes("/search")), "parameterized search pages stay out of the sitemap");
  assert.ok(!locations.some((location) => location.includes("/board")), "private local boards stay out of the sitemap");
});

test("emits canonical and structured data on brand details", async () => {
  const response = await render("/brands/lowrys-farm");
  assert.equal(response.status, 200);
  const html = await response.text();

  assertHasAccessibleMain(html);
  const canonicalTag = html.match(/<link\b[^>]*rel="canonical"[^>]*>/)?.[0] ?? "";
  assert.match(canonicalTag, /href="https:\/\/chara-fuku-archive\.tetoriapot\.chatgpt\.site\/brands\/lowrys-farm"/);

  const jsonLd = extractJsonLd(html).flatMap((value) => Array.isArray(value) ? value : [value]);
  const webPage = jsonLd.find((value) => value["@type"] === "WebPage");
  const breadcrumbs = jsonLd.find((value) => value["@type"] === "BreadcrumbList");
  assert.equal(webPage?.url, "https://chara-fuku-archive.tetoriapot.chatgpt.site/brands/lowrys-farm");
  assert.equal(webPage?.isPartOf?.name, "キャラ服資料館");
  assert.ok(Array.isArray(webPage?.citation) && webPage.citation.length > 0);
  assert.deepEqual(
    breadcrumbs?.itemListElement?.map((item) => item.position),
    [1, 2, 3],
  );
  assert.equal(breadcrumbs?.itemListElement?.at(-1)?.name, "LOWRYS FARM");
});

test("keeps structured search URLs shareable while preventing indexing", async () => {
  const params = new URLSearchParams({
    exactAge: "22",
    lifeStage: "大学生",
    gender: "女性",
    occupation: "保育士",
    style: "カジュアル",
    season: "夏",
  });
  const response = await render(`/search?${params}`);
  assert.equal(response.status, 200);
  const html = withoutReactTextBoundaries(await response.text());

  assertHasAccessibleMain(html);
  assert.match(html, /<meta name="robots" content="noindex, follow"/);
  assert.match(html, /<h2[^>]*>22歳（20代データで判定）・大学生・女性・保育士・カジュアル・夏<\/h2>/);
  assert.match(html, /<input[^>]*id="character-query"[^>]*value=""/);
  assert.match(html, /<input[^>]*type="number"[^>]*value="22"/);
  const canonicalTag = html.match(/<link\b[^>]*rel="canonical"[^>]*>/)?.[0] ?? "";
  assert.match(canonicalTag, /href="https:\/\/chara-fuku-archive\.tetoriapot\.chatgpt\.site\/search"/);
  assert.doesNotMatch(canonicalTag, /exactAge|lifeStage|gender|occupation|style|season/);

  const hybrid = new URLSearchParams({ q: "22歳 女性 大学生", season: "夏" });
  const hybridHtml = withoutReactTextBoundaries(await (await render(`/search?${hybrid}`)).text());
  assert.match(hybridHtml, /<h2[^>]*>22歳（20代データで判定）・大学生・女性・夏<\/h2>/, "structured parameters augment parsed query conditions");

  const contradictory = new URLSearchParams({ exactAge: "22", ageGroup: "30代" });
  const contradictoryHtml = withoutReactTextBoundaries(await (await render(`/search?${contradictory}`)).text());
  assert.match(contradictoryHtml, /<h2[^>]*>22歳（20代データで判定）<\/h2>/, "exact age remains the source of truth for its age group");
  assert.doesNotMatch(contradictoryHtml, /<h2[^>]*>30代<\/h2>/);
});
