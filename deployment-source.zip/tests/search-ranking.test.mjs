import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { fileURLToPath } from "node:url";
import { createServer } from "vite";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));

let vite;
let search;
let catalog;

before(async () => {
  vite = await createServer({
    root: projectRoot,
    configFile: false,
    logLevel: "silent",
    appType: "custom",
    server: { middlewareMode: true },
    resolve: { alias: { "@": projectRoot } },
  });
  search = await vite.ssrLoadModule("/lib/search.ts");
  catalog = await vite.ssrLoadModule("/lib/brands.ts");
});

after(async () => {
  await vite?.close();
});

function parsed(query) {
  return search.parseCharacterQuery(query);
}

function scoreAll(query) {
  const filters = parsed(query);
  return {
    filters,
    scores: catalog.brands.map((brand) => ({
      brand,
      ...search.scoreBrand(brand, query, filters),
    })),
  };
}

function outfitSupports(outfit, filters) {
  if (filters.ageGroup && !outfit.ageGroups.includes(filters.ageGroup)) return false;
  if (filters.lifeStage && !outfit.lifeStages.includes(filters.lifeStage)) return false;
  if (filters.season && outfit.season !== filters.season) return false;
  if (filters.scene && outfit.scene !== filters.scene) return false;
  if (filters.style && !outfit.styles.includes(filters.style)) return false;
  if (filters.gender) {
    const genderMatch = outfit.genders.includes(filters.gender) ||
      outfit.genders.includes("ジェンダーレス") ||
      (filters.gender === "ジェンダーレス" && outfit.genders.includes("女性") && outfit.genders.includes("男性"));
    if (!genderMatch) return false;
  }
  if (filters.occupation && !outfit.occupations.some((occupation) =>
    occupation.includes(filters.occupation) || filters.occupation.includes(occupation))) return false;
  return true;
}

test("parses life stage and season terms without matching place or proper-name substrings", () => {
  assert.equal(parsed("大学病院勤務の看護師").lifeStage, "");
  assert.equal(parsed("秋田県出身").season, "");
  assert.equal(parsed("夏目という名字").season, "");

  assert.equal(parsed("大学生").lifeStage, "大学生");
  assert.equal(parsed("秋 コーデ").season, "秋");
  assert.equal(parsed("夏服").season, "夏");
});

test("keeps 18- and 19-year-old university students inside the supported age boundary", () => {
  for (const age of [18, 19]) {
    const query = `${age}歳 大学生`;
    const filters = parsed(query);
    assert.equal(filters.exactAge, age);
    assert.equal(filters.ageGroup, "10代");
    assert.equal(filters.lifeStage, "大学生");
    assert.deepEqual(search.getSearchDiagnostics(query, filters), []);

    const suitSelect = search.rankBrands(query, filters).find(({ brand }) => brand.slug === "suit-select");
    assert.ok(suitSelect, `${age}歳の大学生としてSUIT SELECTを年代候補にできる`);
    assert.ok(
      suitSelect.reasons.some((reason) => reason.condition === "age" && reason.source === "brand"),
      `${age}歳は大学生のブランド年代情報で直接支持される`,
    );
  }
});

test("blocks contradictory or invalid ages before ranking", () => {
  const contradictoryQuery = "13歳 大学生";
  const contradictoryFilters = parsed(contradictoryQuery);
  assert.ok(
    search.getSearchDiagnostics(contradictoryQuery, contradictoryFilters)
      .some(({ code }) => code === "age-life-stage-conflict"),
  );
  assert.deepEqual(search.rankBrands(contradictoryQuery, contradictoryFilters), []);

  const invalidQuery = "122歳";
  const invalidFilters = parsed(invalidQuery);
  assert.ok(
    search.getSearchDiagnostics(invalidQuery, invalidFilters)
      .some(({ code }) => code === "invalid-age"),
  );
  assert.deepEqual(search.rankBrands(invalidQuery, invalidFilters), []);
});

test("retains an explicit unknown caution for an unregistered term mixed with a known season", () => {
  const query = "宇宙飛行士 夏";
  const { filters, scores } = scoreAll(query);
  assert.deepEqual(search.extractSearchKeywords(query, filters), ["宇宙飛行士"]);

  for (const item of scores) {
    assert.ok(
      item.cautions.some(({ code, status, label }) =>
        code === "keyword-0" && status === "unknown" && label.includes("宇宙飛行士")),
      `${item.brand.name}の評価データにも未知語の注意が残る`,
    );
  }
});

test("flags an unregistered occupation entered through the structured field", () => {
  const filters = { ...search.emptySearchFilters, occupation: "宇宙飛行士" };
  assert.ok(
    search.getSearchDiagnostics("", filters)
      .some(({ code, severity }) => code === "unknown-occupation" && severity === "warning"),
  );
  assert.deepEqual(search.rankBrands("", filters), []);
});

test("keeps scores bounded and never labels a mismatch as 100 percent", () => {
  const queries = [
    "",
    "10代 春 普段着 ストリート",
    "22歳 女性 大学生 夏 普段着 カジュアル",
    "30代 男性 通勤 冬 オフィスカジュアル",
    "女子高生 デート 冬 地雷系",
    "介護職 夏 通勤",
    "宇宙飛行士 夏",
  ];

  for (const query of queries) {
    for (const item of scoreAll(query).scores) {
      assert.ok(item.score >= 0 && item.score <= item.maxScore, `${query || "条件なし"}: ${item.brand.name}のscore範囲`);
      assert.ok(item.matchPercent >= 0 && item.matchPercent <= 100, `${query || "条件なし"}: ${item.brand.name}の%範囲`);
      assert.equal(
        item.reasons.reduce((sum, reason) => sum + reason.points, 0),
        item.score,
        `${query || "条件なし"}: 根拠点の合計とscoreが一致する`,
      );
      if (item.matchPercent === 100) {
        assert.ok(
          !item.cautions.some(({ status }) => status === "mismatch"),
          `${query || "条件なし"}: 100%の${item.brand.name}に明示的不一致がない`,
        );
      }
    }
  }
});

test("backs every exact outfit match with one recipe satisfying all structured conditions", () => {
  const queries = [
    "10代 春 普段着 ストリート",
    "22歳 女性 大学生 夏 普段着 カジュアル",
    "30代 男性 通勤 冬 オフィスカジュアル",
    "女子高生 デート 冬 地雷系",
    "介護職 夏 通勤",
  ];
  let exactMatchCount = 0;

  for (const query of queries) {
    const { filters, scores } = scoreAll(query);
    for (const item of scores.filter(({ exactOutfitMatch }) => exactOutfitMatch)) {
      exactMatchCount += 1;
      assert.ok(item.bestOutfit, `${query}: ${item.brand.name}に代表コーデがある`);
      assert.ok(outfitSupports(item.bestOutfit, filters), `${query}: ${item.brand.name}の代表コーデが全構造条件を満たす`);
      assert.ok(item.bestOutfit.brandSlugs.includes(item.brand.slug), `${query}: 代表コーデが対象ブランドに紐づく`);
    }
  }

  assert.ok(exactMatchCount > 0, "同時一致コーデを持つ代表ケースを検証できた");
});

test("excludes candidates with explicit gender or style mismatches from ranked results", () => {
  for (const { query, cautionCode } of [
    { query: "男性", cautionCode: "gender" },
    { query: "地雷系", cautionCode: "style" },
  ]) {
    const { filters, scores } = scoreAll(query);
    const mismatchedSlugs = scores
      .filter(({ cautions }) => cautions.some(({ code, status }) => code === cautionCode && status === "mismatch"))
      .map(({ brand }) => brand.slug);
    assert.ok(mismatchedSlugs.length > 0, `${query}に明示的不一致となる検証候補がある`);

    const rankedSlugs = new Set(search.rankBrands(query, filters).map(({ brand }) => brand.slug));
    for (const slug of mismatchedSlugs) assert.ok(!rankedSlugs.has(slug), `${slug}を${cautionCode}不一致で除外する`);
  }
});

test("ranks a directly supported youth street brand above GU for a representative outfit query", () => {
  const query = "10代 春 普段着 ストリート";
  const filters = parsed(query);
  const ranked = search.rankBrands(query, filters);
  const guIndex = ranked.findIndex(({ brand }) => brand.slug === "gu");
  const specialistIndexes = ["wego", "spinns"]
    .map((slug) => ranked.findIndex(({ brand }) => brand.slug === slug))
    .filter((index) => index >= 0);

  assert.ok(guIndex >= 0, "比較対象のGUが候補に残る");
  assert.ok(specialistIndexes.length > 0, "WEGOまたはSPINNSが候補に残る");
  assert.ok(Math.min(...specialistIndexes) < guIndex, "WEGOまたはSPINNSをGUより上位にする");
  assert.ok(ranked.length > 0 && ranked.length < catalog.brands.length, "複数条件で全ブランドを返さない");
});

test("uses slug as the stable final tie-break instead of catalog input order", () => {
  const ranked = search.rankBrands("", { ...search.emptySearchFilters });
  for (const featured of [true, false]) {
    const actual = ranked.filter(({ brand }) => brand.featured === featured).map(({ brand }) => brand.slug);
    const expected = [...actual].sort((first, second) => first.localeCompare(second));
    assert.deepEqual(actual, expected, `${featured ? "注目" : "通常"}ブランドの完全同点をslug順にする`);
  }
});

test("parses the expanded neat style vocabulary", () => {
  assert.equal(parsed("20代女性 きれいめ 通勤").style, "きれいめ");
});

test("treats generic fashion suffixes as syntax instead of required unknown keywords", () => {
  for (const { query, season } of [
    { query: "夏コーデ", season: "夏" },
    { query: "秋 コーデ", season: "秋" },
    { query: "春の服", season: "春" },
    { query: "冬向け", season: "冬" },
    { query: "夏のファッション", season: "夏" },
  ]) {
    const filters = parsed(query);
    assert.equal(filters.season, season, `${query}の季節を解釈する`);
    assert.deepEqual(search.extractSearchKeywords(query, filters), [], `${query}の一般接尾語を未知語にしない`);
    assert.ok(search.rankBrands(query, filters).length > 0, `${query}で登録候補を返す`);
  }
});

test("disambiguates formal as a scene by default and as a style when stated explicitly", () => {
  for (const query of ["フォーマル", "フォーマルコーデ", "フォーマルな場"]) {
    const filters = parsed(query);
    assert.equal(filters.scene, "フォーマル", `${query}をシーンとして扱う`);
    assert.equal(filters.style, "", `${query}を同じテイスト条件へ重複させない`);
    assert.deepEqual(search.extractSearchKeywords(query, filters), []);
    assert.ok(search.rankBrands(query, filters).length > 0);
  }

  const formalStyle = parsed("通勤 フォーマルテイスト");
  assert.equal(formalStyle.scene, "通勤");
  assert.equal(formalStyle.style, "フォーマル");
  assert.deepEqual(search.extractSearchKeywords("通勤 フォーマルテイスト", formalStyle), []);

  const mixed = parsed("フォーマルシーン モード");
  assert.equal(mixed.scene, "フォーマル");
  assert.equal(mixed.style, "モード");
  assert.deepEqual(search.extractSearchKeywords("フォーマルシーン モード", mixed), []);
});

test("normalizes senior decade aliases without leaving them as unknown keywords", () => {
  for (const query of ["60代", "60代以上", "70代", "80代", "90代以上", "７０代 女性"]) {
    const filters = parsed(query);
    assert.equal(filters.ageGroup, "60代以上", `${query}を60代以上として扱う`);
    assert.deepEqual(search.extractSearchKeywords(query, filters), [], `${query}を残余キーワードに残さない`);
    assert.ok(
      !search.getSearchDiagnostics(query, filters).some(({ code }) => code === "unknown-keyword"),
      `${query}を未知語として警告しない`,
    );
  }
});

test("keeps the ranked candidate set monotone when one structured condition is added", () => {
  const representativeConditions = [
    ["ageGroup", "20代"],
    ["lifeStage", "社会人"],
    ["gender", "女性"],
    ["season", "春"],
    ["scene", "通勤"],
    ["style", "オフィスカジュアル"],
    ["occupation", "会社員"],
  ];
  const masks = 2 ** representativeConditions.length;

  for (let mask = 0; mask < masks; mask += 1) {
    const baseFilters = { ...search.emptySearchFilters };
    representativeConditions.forEach(([key, value], index) => {
      if (mask & (2 ** index)) baseFilters[key] = value;
    });
    const baseSlugs = new Set(search.rankBrands("", baseFilters).map(({ brand }) => brand.slug));

    representativeConditions.forEach(([key, value], index) => {
      if (mask & (2 ** index)) return;
      const narrowerFilters = { ...baseFilters, [key]: value };
      const narrowerSlugs = search.rankBrands("", narrowerFilters).map(({ brand }) => brand.slug);
      for (const slug of narrowerSlugs) {
        assert.ok(
          baseSlugs.has(slug),
          `${JSON.stringify(baseFilters)}へ${key}=${value}を加えても${slug}を新規追加しない`,
        );
      }
    });
  }
});

test("uses outfit-only evidence for every expanded style without overstating separate evidence", () => {
  const expandedStyles = ["きれいめ", "スポーティ", "モード", "アウトドア", "フェミニン", "フォーマル"];

  for (const style of expandedStyles) {
    const styleFilters = { ...search.emptySearchFilters, style };
    const styleResults = search.rankBrands("", styleFilters);
    assert.ok(styleResults.length > 0, `${style}を登録コーデから検索できる`);
    assert.ok(
      styleResults.some(({ reasons }) => reasons.some((reason) =>
        reason.condition === "style" && reason.source === "outfit")),
      `${style}にコーデ由来のスタイル根拠がある`,
    );

    let separateEvidenceCase;
    for (const brand of catalog.brands) {
      const brandOutfits = catalog.getOutfitsForBrand(brand.slug);
      if (!brandOutfits.some((outfit) => outfit.styles.includes(style))) continue;
      for (const season of catalog.filterOptions.seasons) {
        const hasSeasonEvidence = brandOutfits.some((outfit) => outfit.season === season);
        const hasJointEvidence = brandOutfits.some((outfit) =>
          outfit.season === season && outfit.styles.includes(style));
        if (hasSeasonEvidence && !hasJointEvidence) {
          separateEvidenceCase = { brand, season };
          break;
        }
      }
      if (separateEvidenceCase) break;
    }

    assert.ok(separateEvidenceCase, `${style}に別々のコーデ根拠となる検証ケースがある`);
    const filters = {
      ...search.emptySearchFilters,
      style,
      season: separateEvidenceCase.season,
    };
    const score = search.scoreBrand(separateEvidenceCase.brand, "", filters);
    assert.ok(
      score.reasons.some(({ code, condition, source }) =>
        code === "style-outfit-separate" && condition === "style" && source === "outfit"),
      `${style}の単独コーデ根拠を保持する`,
    );
    assert.equal(score.exactOutfitMatch, false, `${style}と${separateEvidenceCase.season}を同時一致扱いしない`);
    assert.ok(score.matchPercent < 100, `${style}の別々の根拠を100%扱いしない`);
    assert.ok(
      score.cautions.some(({ code, status }) => code === "style-cooccurrence" && status === "unknown"),
      `${style}に同時一致コーデ未登録の注意を付ける`,
    );
  }
});

test("defines exactOutfitMatch as structural-condition agreement even when an unknown keyword remains", () => {
  const query = "宇宙飛行士 10代 春 普段着 ストリート";
  const { filters, scores } = scoreAll(query);
  const exactScores = scores.filter(({ exactOutfitMatch }) => exactOutfitMatch);

  assert.deepEqual(search.extractSearchKeywords(query, filters), ["宇宙飛行士"]);
  assert.ok(exactScores.length > 0, "未知語が混在しても構造条件に同時一致するコーデは判定できる");
  for (const item of exactScores) {
    assert.ok(item.bestOutfit && outfitSupports(item.bestOutfit, filters), `${item.brand.name}の構造条件が同時一致する`);
    assert.ok(
      item.cautions.some(({ code, status }) => code === "keyword-0" && status === "unknown"),
      `${item.brand.name}に未知語の注意を残す`,
    );
    assert.ok(
      item.matchedConditionCount < item.totalConditionCount,
      `${item.brand.name}のexactOutfitMatchをクエリ全体の完全一致とは数えない`,
    );
  }
});

test("returns only exact all-catalog outfit matches with structural condition counts", () => {
  const query = "22歳 女性 大学生 夏 普段着 ストリート 宇宙飛行士";
  const filters = parsed(query);
  const matches = search.getExactOutfitMatches(filters);

  assert.ok(matches.length > 0, "全コーデから完全一致候補を返す");
  for (const match of matches) {
    assert.deepEqual(
      Object.keys(match).sort(),
      ["matchedConditionCount", "outfit", "totalConditionCount"],
      "公開結果をコーデと条件数だけで構成する",
    );
    assert.equal(match.totalConditionCount, 6, "個別年齢は年代条件として1件に数える");
    assert.equal(match.matchedConditionCount, match.totalConditionCount);
    assert.ok(outfitSupports(match.outfit, filters), `${match.outfit.id}が全構造条件を満たす`);
  }

  const withoutResidualKeyword = search.getExactOutfitMatches(
    parsed("22歳 女性 大学生 夏 普段着 ストリート"),
  );
  assert.deepEqual(
    matches.map(({ outfit }) => outfit.id),
    withoutResidualKeyword.map(({ outfit }) => outfit.id),
    "残余キーワードをコーデ完全一致判定に使わない",
  );
});

test("shares exact outfit AND semantics between all-catalog and per-brand matching", () => {
  const filters = parsed("22歳 女性 大学生 夏 普段着 ストリート");
  const allMatches = search.getExactOutfitMatches(filters);

  for (const brand of catalog.brands) {
    const expected = allMatches
      .filter(({ outfit }) => outfit.brandSlugs.includes(brand.slug))
      .map(({ outfit }) => outfit.id);
    const actual = search.getMatchingOutfits(brand, filters).map((outfit) => outfit.id);
    assert.deepEqual(actual, expected, `${brand.name}で全コーデ検索と同じAND条件を使う`);
  }
});

test("does not return outfit candidates without a structural condition", () => {
  assert.deepEqual(search.getExactOutfitMatches(search.emptySearchFilters), []);

  const residualOnly = parsed("インドア派");
  assert.deepEqual(search.getExactOutfitMatches(residualOnly), []);
});
