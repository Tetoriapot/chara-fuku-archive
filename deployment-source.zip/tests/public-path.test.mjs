import assert from "node:assert/strict";
import { after, test } from "node:test";
import { publicPath } from "../lib/public-path.ts";

const original = { base: process.env.NEXT_PUBLIC_BASE_PATH, static: process.env.NEXT_PUBLIC_STATIC_EXPORT };
after(() => {
  for (const [key, value] of [["NEXT_PUBLIC_BASE_PATH", original.base], ["NEXT_PUBLIC_STATIC_EXPORT", original.static]]) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
});

test("preserves existing root URLs outside static export", () => {
  delete process.env.NEXT_PUBLIC_BASE_PATH;
  delete process.env.NEXT_PUBLIC_STATIC_EXPORT;
  assert.equal(publicPath("/search?q=大学生"), "/search?q=大学生");
});

test("keeps queries and share fragments inside the Pages subdirectory", () => {
  process.env.NEXT_PUBLIC_BASE_PATH = "/chara-fuku-archive";
  process.env.NEXT_PUBLIC_STATIC_EXPORT = "true";
  assert.equal(publicPath("/search?q=大学生"), "/chara-fuku-archive/search/?q=大学生");
  assert.equal(publicPath("/board#board=abc"), "/chara-fuku-archive/board/#board=abc");
  assert.equal(publicPath("/compare?brands=gu%2Cuniqlo"), "/chara-fuku-archive/compare/?brands=gu%2Cuniqlo");
  assert.equal(publicPath("/outfits/"), "/chara-fuku-archive/outfits/");
  assert.equal(publicPath("/"), "/chara-fuku-archive/");
});
