import assert from "node:assert/strict";
import { after, before, test } from "node:test";
import { fileURLToPath } from "node:url";
import { createServer } from "vite";

const projectRoot = fileURLToPath(new URL("../", import.meta.url));
const NOW = "2026-07-22T01:00:00.000Z";
const LATER = "2026-07-22T02:00:00.000Z";
const catalog = {
  brandSlugs: ["uniqlo", "gu", "beams", "ships", "vis"],
  outfitIds: ["look-1", "look-2", "look-3", "look-4", "look-5", "look-6", "look-7"],
};

let vite;
let storage;

before(async () => {
  vite = await createServer({
    root: projectRoot,
    configFile: false,
    logLevel: "silent",
    appType: "custom",
    server: { middlewareMode: true },
    resolve: { alias: { "@": projectRoot } },
  });
  storage = await vite.ssrLoadModule("/lib/board-storage.ts");
});

after(async () => {
  await vite?.close();
});

function makeBoard(id, name = "", overrides = {}) {
  const empty = storage.createEmptyCharacterBoard(id);
  return {
    ...empty,
    ...overrides,
    id,
    name,
    filters: { ...empty.filters, ...(overrides.filters ?? {}) },
    brandSlugs: [...(overrides.brandSlugs ?? empty.brandSlugs)],
    outfitIds: [...(overrides.outfitIds ?? empty.outfitIds)],
    brandReasons: { ...(overrides.brandReasons ?? empty.brandReasons) },
    updatedAt: overrides.updatedAt ?? NOW,
  };
}

function makeLibrary(boards, activeBoardId = boards[0]?.id ?? "") {
  return {
    version: storage.CHARACTER_BOARD_LIBRARY_VERSION,
    activeBoardId,
    boards,
  };
}

test("wraps a normalized v1 board in a v2 library without losing its content", () => {
  const legacyBoard = makeBoard("legacy-board", "葵", {
    premise: "書店で働く22歳の大学生",
    filters: {
      exactAge: 22,
      ageGroup: "20代",
      lifeStage: "大学生",
      gender: "女性",
      season: "夏",
      scene: "普段着",
      style: "ナチュラル",
      occupation: "書店員",
    },
    brandSlugs: ["uniqlo", "gu"],
    outfitIds: ["look-1"],
    brandReasons: { uniqlo: "実用性が人物像に合う" },
    note: "雨の日はローファーを避ける。",
  });

  const parsedLegacy = storage.parseCharacterBoard(JSON.stringify(legacyBoard), catalog);
  assert.equal(parsedLegacy.recovered, false);
  assert.deepEqual(parsedLegacy.board, legacyBoard);

  const wrapped = makeLibrary([parsedLegacy.board], parsedLegacy.board.id);
  const normalized = storage.normalizeCharacterBoardLibrary(wrapped, catalog);
  assert.equal(normalized.recovered, false);
  assert.deepEqual(normalized.library, wrapped);

  const preferredV2 = makeLibrary([makeBoard("v2-board", "新形式のキャラ")]);
  const parsedV2 = storage.parseCharacterBoardLibrary(JSON.stringify(preferredV2), catalog);
  assert.equal(parsedV2.library.activeBoardId, "v2-board");
  assert.deepEqual(parsedV2.library.boards.map((board) => board.name), ["新形式のキャラ"]);
  assert.ok(!parsedV2.library.boards.some((board) => board.id === legacyBoard.id), "a supplied v2 library is not merged with legacy data by the parser");
});

test("recovers broken JSON, an invalid active id, and an empty board list", () => {
  const broken = storage.parseCharacterBoardLibrary("{not-json", catalog);
  assert.equal(broken.recovered, true);
  assert.equal(broken.library.boards.length, 1);
  assert.equal(broken.library.activeBoardId, broken.library.boards[0].id);

  const invalidActive = storage.normalizeCharacterBoardLibrary(
    makeLibrary([makeBoard("board-a", "A"), makeBoard("board-b", "B")], "missing-board"),
    catalog,
  );
  assert.equal(invalidActive.recovered, true);
  assert.equal(invalidActive.library.activeBoardId, "board-a");

  const empty = storage.normalizeCharacterBoardLibrary({
    version: storage.CHARACTER_BOARD_LIBRARY_VERSION,
    activeBoardId: "missing-board",
    boards: [],
  }, catalog);
  assert.equal(empty.recovered, true);
  assert.equal(empty.library.boards.length, 1);
  assert.equal(empty.library.activeBoardId, empty.library.boards[0].id);
});

test("repairs duplicate board ids and enforces collection and per-board limits", () => {
  const boards = Array.from({ length: storage.MAX_CHARACTER_BOARDS + 2 }, (_, index) => (
    makeBoard(index < 2 ? "duplicate" : `board-${index}`, `キャラ${index + 1}`)
  ));
  boards[0] = makeBoard("duplicate", "上限確認", {
    brandSlugs: ["uniqlo", "uniqlo", "ghost-brand", "gu", "beams", "ships", "vis"],
    outfitIds: ["look-1", "look-1", "ghost-look", "look-2", "look-3", "look-4", "look-5", "look-6", "look-7"],
    brandReasons: {
      uniqlo: "理由",
      "ghost-brand": "除外対象",
      vis: "上限外のため理由も除外",
    },
  });

  const normalized = storage.normalizeCharacterBoardLibrary(
    makeLibrary(boards, `board-${storage.MAX_CHARACTER_BOARDS + 1}`),
    catalog,
  );

  assert.equal(normalized.recovered, true);
  assert.equal(normalized.library.boards.length, storage.MAX_CHARACTER_BOARDS);
  assert.equal(new Set(normalized.library.boards.map((board) => board.id)).size, storage.MAX_CHARACTER_BOARDS);
  assert.deepEqual(normalized.library.boards.slice(0, 2).map((board) => board.id), ["duplicate", "duplicate-2"]);
  assert.equal(normalized.library.activeBoardId, "duplicate");
  assert.deepEqual(normalized.library.boards[0].brandSlugs, ["uniqlo", "gu", "beams", "ships"]);
  assert.deepEqual(normalized.library.boards[0].outfitIds, ["look-1", "look-2", "look-3", "look-4", "look-5", "look-6"]);
  assert.deepEqual(normalized.library.boards[0].brandReasons, { uniqlo: "理由" });
  assert.deepEqual(normalized.staleBrandSlugs, ["ghost-brand"]);
  assert.deepEqual(normalized.staleOutfitIds, ["ghost-look"]);
});

test("creates and deeply duplicates boards with fresh ids and treats the maximum as a no-op", () => {
  const source = makeBoard("board-a", "葵", {
    filters: { exactAge: 22, ageGroup: "20代", gender: "女性" },
    brandSlugs: ["uniqlo"],
    outfitIds: ["look-1"],
    brandReasons: { uniqlo: "人物像に合う" },
    note: "複製するメモ",
  });
  const initial = makeLibrary([source]);

  const created = storage.createCharacterBoardInLibrary(initial, {
    idFactory: () => "board-created",
    now: LATER,
  });
  assert.equal(created.changed, true);
  assert.equal(created.reason, "created");
  assert.equal(created.library.activeBoardId, "board-created");
  assert.deepEqual(created.library.boards.map((board) => board.id), ["board-a", "board-created"]);

  const duplicated = storage.duplicateCharacterBoardInLibrary(initial, "board-a", {
    idFactory: () => "board-copy",
    now: LATER,
  });
  assert.equal(duplicated.changed, true);
  assert.equal(duplicated.reason, "duplicated");
  assert.equal(duplicated.library.activeBoardId, "board-copy");
  const copy = duplicated.library.boards[1];
  assert.equal(copy.id, "board-copy");
  assert.equal(copy.name, "葵のコピー");
  assert.equal(copy.note, source.note);
  assert.deepEqual(copy.filters, source.filters);
  assert.deepEqual(copy.brandSlugs, source.brandSlugs);
  assert.deepEqual(copy.outfitIds, source.outfitIds);
  assert.deepEqual(copy.brandReasons, source.brandReasons);
  assert.notStrictEqual(copy.filters, source.filters);
  assert.notStrictEqual(copy.brandSlugs, source.brandSlugs);
  assert.notStrictEqual(copy.outfitIds, source.outfitIds);
  assert.notStrictEqual(copy.brandReasons, source.brandReasons);

  const full = makeLibrary(
    Array.from({ length: storage.MAX_CHARACTER_BOARDS }, (_, index) => makeBoard(`full-${index + 1}`, `満員${index + 1}`)),
    "full-1",
  );
  const createAtLimit = storage.createCharacterBoardInLibrary(full, { idFactory: () => "overflow", now: LATER });
  const duplicateAtLimit = storage.duplicateCharacterBoardInLibrary(full, "full-1", { idFactory: () => "overflow", now: LATER });
  assert.equal(createAtLimit.changed, false);
  assert.equal(createAtLimit.reason, "limit");
  assert.deepEqual(createAtLimit.library, full);
  assert.equal(duplicateAtLimit.changed, false);
  assert.equal(duplicateAtLimit.reason, "limit");
  assert.deepEqual(duplicateAtLimit.library, full);
});

test("selects the next, previous, or a fresh empty board after deletion", () => {
  const boards = [makeBoard("board-a", "A"), makeBoard("board-b", "B"), makeBoard("board-c", "C")];

  const middle = storage.deleteCharacterBoardFromLibrary(makeLibrary(boards, "board-b"), "board-b");
  assert.deepEqual(middle.library.boards.map((board) => board.id), ["board-a", "board-c"]);
  assert.equal(middle.library.activeBoardId, "board-c");

  const tail = storage.deleteCharacterBoardFromLibrary(makeLibrary(boards, "board-c"), "board-c");
  assert.deepEqual(tail.library.boards.map((board) => board.id), ["board-a", "board-b"]);
  assert.equal(tail.library.activeBoardId, "board-b");

  const nonActive = storage.deleteCharacterBoardFromLibrary(makeLibrary(boards, "board-b"), "board-a");
  assert.equal(nonActive.library.activeBoardId, "board-b");

  const last = storage.deleteCharacterBoardFromLibrary(makeLibrary([boards[0]], "board-a"), "board-a", {
    idFactory: () => "board-replacement",
    now: LATER,
  });
  assert.equal(last.reason, "last-reset");
  assert.equal(last.library.activeBoardId, "board-replacement");
  assert.equal(last.library.boards.length, 1);
  assert.equal(last.library.boards[0].id, "board-replacement");
  assert.equal(last.library.boards[0].name, "");
  assert.deepEqual(last.library.boards[0].brandSlugs, []);
  assert.deepEqual(last.library.boards[0].outfitIds, []);
});

test("does not resurrect a missing mutation target", () => {
  const library = makeLibrary([makeBoard("board-a", "A")]);
  const results = [
    storage.duplicateCharacterBoardInLibrary(library, "deleted-board", { idFactory: () => "unexpected" }),
    storage.deleteCharacterBoardFromLibrary(library, "deleted-board", { idFactory: () => "unexpected" }),
    storage.selectCharacterBoardInLibrary(library, "deleted-board"),
    storage.resetCharacterBoardInLibrary(library, "deleted-board", { now: LATER }),
  ];

  for (const result of results) {
    assert.equal(result.changed, false);
    assert.equal(result.reason, "missing");
    assert.deepEqual(result.library.boards.map((board) => board.id), ["board-a"]);
    assert.equal(result.library.activeBoardId, "board-a");
  }
});

test("round-trips a Unicode character board through a URL-safe share fragment", () => {
  const board = makeBoard("share-board", "桜井ミナ 🌸", {
    premise: "雨の東京で働く編集者。☂️",
    filters: { ageGroup: "30代", gender: "女性", season: "春", scene: "通勤", style: "シンプル", occupation: "編集者" },
    brandSlugs: ["beams"],
    outfitIds: ["look-2"],
    brandReasons: { beams: "仕事と休日の両方になじむ。" },
    note: "青緑の傘／祖母から譲られた腕時計⌚",
  });

  const fragment = storage.encodeCharacterBoardFragment(board);
  assert.match(fragment, /^#board=[A-Za-z0-9_-]+$/);
  const decoded = storage.decodeCharacterBoardFragment(fragment, catalog);
  assert.equal(decoded.error, "");
  assert.deepEqual(decoded.board, board);
});

test("imports with a fresh id and recognizes a repeated import as existing", () => {
  const local = makeBoard("board-a", "ローカル");
  const importedValue = makeBoard("board-a", "共有キャラクター", {
    premise: "同じIDでも内容は別",
    brandSlugs: ["vis"],
    outfitIds: ["look-3"],
    brandReasons: { vis: "共有された理由" },
  });

  const imported = storage.importCharacterBoardIntoLibrary(
    makeLibrary([local]),
    importedValue,
    catalog,
    { idFactory: () => "board-imported", now: LATER },
  );
  assert.equal(imported.changed, true);
  assert.equal(imported.reason, "imported");
  assert.equal(imported.boardId, "board-imported");
  assert.equal(imported.library.activeBoardId, "board-imported");
  assert.deepEqual(imported.library.boards.map((board) => board.id), ["board-a", "board-imported"]);
  assert.equal(imported.library.boards[0].name, "ローカル");
  assert.equal(imported.library.boards[1].name, "共有キャラクター");

  const repeated = storage.importCharacterBoardIntoLibrary(
    imported.library,
    importedValue,
    catalog,
    { idFactory: () => "should-not-be-used", now: LATER },
  );
  assert.equal(repeated.changed, false);
  assert.equal(repeated.reason, "existing");
  assert.equal(repeated.boardId, "board-imported");
  assert.deepEqual(repeated.library, imported.library);
});
