import type { Metadata } from "next";
import { Suspense } from "react";
import { StaticSearchExplorer } from "@/components/StaticQueryPages";
import { SearchExplorer } from "@/components/SearchExplorer";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { buildPageSocialMetadata } from "@/lib/metadata";
import { readSearchState } from "@/lib/search-state";

const description = "年齢、性別、職業、季節、シーン、テイストから、キャラクターが着ていそうな登録コーデとファッションブランドを根拠付きで探せます。";
export const metadata: Metadata = {
  title: "キャラクターから服を探す | キャラ服資料館",
  description,
  alternates: { canonical: "/search" },
  robots: { index: false, follow: true },
  ...buildPageSocialMetadata({ title: "キャラクターから服を探す | キャラ服資料館", description, path: "/search" }),
};

export default async function SearchPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const isStatic = process.env.NEXT_PUBLIC_STATIC_EXPORT === "true";
  const params = isStatic ? {} : await searchParams;
  const { query, filters } = readSearchState(params);
  return (
    <>
      <SiteHeader />
      <main className="subpage-main" id="main-content">
        <section className="subpage-hero search-hero">
          <div className="shell">
            <p className="eyebrow">CHARACTER SEARCH</p>
            <h1>キャラクターから探す</h1>
            <p>設定を手がかりに、条件を同時に満たす登録コーデと、その人物が自然に選びそうなブランドを探します。</p>
          </div>
        </section>
        <div className="shell">{isStatic
          ? <Suspense fallback={<p role="status">検索条件を読み込んでいます。</p>}><StaticSearchExplorer /></Suspense>
          : <SearchExplorer initialQuery={query} initialFilters={filters} />}</div>
      </main>
      <SiteFooter />
    </>
  );
}
