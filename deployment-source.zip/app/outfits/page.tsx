import type { Metadata } from "next";
import { Suspense } from "react";
import { StaticOutfitExplorer } from "@/components/StaticQueryPages";
import { OutfitExplorer } from "@/components/OutfitExplorer";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { buildPageSocialMetadata } from "@/lib/metadata";
import { outfitRecipeCount, readOutfitFilters } from "@/lib/outfits";

const description = `幼児からシニアまで、季節、シーン、年代、学齢、性別、職業、テイスト、ブランドから探せる創作者向けコーデ処方箋${outfitRecipeCount}件。`;
export const metadata: Metadata = {
  title: "コーデ資料集 | キャラ服資料館",
  description,
  alternates: { canonical: "/outfits" },
  ...buildPageSocialMetadata({ title: "コーデ資料集 | キャラ服資料館", description, path: "/outfits" }),
};

export default async function OutfitsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const isStatic = process.env.NEXT_PUBLIC_STATIC_EXPORT === "true";
  const initialFilters = readOutfitFilters(isStatic ? {} : await searchParams);
  return (
    <>
      <SiteHeader />
      <main id="main-content" className="subpage-main outfits-page-main">
        <section className="subpage-hero outfit-library-hero">
          <div className="shell">
            <p className="eyebrow">OUTFIT RECIPE LIBRARY</p>
            <h1>コーデ資料集</h1>
            <p>幼児からシニアまで。普段着・通学・仕事・冠婚葬祭を、アイテム・配色・素材・シルエットから組み立てる{outfitRecipeCount}件の処方箋です。</p>
          </div>
        </section>
        <div className="shell">
          {isStatic
            ? <Suspense fallback={<p role="status">コーデの条件を読み込んでいます。</p>}><StaticOutfitExplorer /></Suspense>
            : <OutfitExplorer initialFilters={initialFilters} />}
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
