import type { MetadataRoute } from "next";
import { brands } from "@/lib/brands";
import { SITE_URL } from "@/lib/site";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const updatedAt = new Date("2026-09-26T00:00:00+09:00");
  const coreRoutes = ["", "/outfits", "/brand-map", "/compare", "/updates", "/help"];
  return [
    ...coreRoutes.map((path) => ({
      url: `${SITE_URL}${path}`,
      lastModified: updatedAt,
      changeFrequency: path === "" ? "weekly" as const : "monthly" as const,
      priority: path === "" ? 1 : 0.8,
    })),
    ...brands.map((brand) => ({
      url: `${SITE_URL}/brands/${brand.slug}`,
      lastModified: new Date(`${brand.updatedAt}T00:00:00+09:00`),
      changeFrequency: "monthly" as const,
      priority: 0.7,
    })),
  ];
}
