import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { buildPageSocialMetadata } from "@/lib/metadata";

const title = "Help・使い方 | キャラ服資料館";
const description = "人物像からの検索、ブランド比較、キャラクターへの保存、テーマ切替の使い方。";
export const metadata: Metadata = {
  title, description, alternates: { canonical: "/help" },
  ...buildPageSocialMetadata({ title, description, path: "/help" }),
};
const questions = [
  { question: "何を入力すると、探しやすいですか？", answer: "「22歳 女性 大学生 秋」「30代 会社員 通勤」のように、年齢・立場・性別・職業・季節・シーン・テイストを組み合わせてください。思いつく2〜3項目から始め、結果画面の絞り込みで調整できます。" },
  { question: "検索結果の一致度は、人気や着用率ですか？", answer: "一致度は、この資料館に登録した情報と指定条件の一致を表します。人気や実際の着用率、ブランド公式の推奨ではありません。コーデ候補は年代・性別・季節などを同時に満たす登録例です。性格などの自由なキーワードは、ブランド側の編集情報を参照します。" },
  { question: "候補が見つからないときは？", answer: "まずは季節やテイストなど、条件を1つ減らして試してください。資料が未登録であることは、その人物に似合わないという意味ではありません。年齢と学齢が矛盾する場合や、登録語に当てはまらない言葉は検索画面に案内が出ます。" },
  { question: "複数のキャラクターを保存できますか？", answer: "「キャラ管理」で最大12人まで作成・切替・複製できます。各キャラクターにはブランドを4件、コーデを6件まで保存できます。検索結果の「ボードに追加」は、現在選択しているキャラクターに保存します。" },
  { question: "保存した資料を別の端末でも使えますか？", answer: "保存先は利用中のブラウザです。別の端末へ自動同期はされません。「キャラ管理」の共有URLをコピーして別の端末で開くと、1人分を取り込めます。Markdownコピーや印刷も利用できます。共有URLを知る人はそのキャラクターの内容を読めるため、公開したくない設定の共有先にご注意ください。" },
  { question: "ライトモードとダークモードの切り替え方は？", answer: "右上の太陽・月のボタンで切り替えます。ボタンには切り替え先の「ライト」「ダーク」が表示されます。初回は端末の表示設定に合わせ、切り替え後はこのブラウザに設定を保存します。" },
  { question: "ここで服を購入できますか？", answer: "このサイトは創作のための資料館です。購入機能はありません。ブランド詳細の「公式サイトを見る」から、各ブランドの現在の商品や価格を確認できます。" },
  { question: "資料図はどこにありますか？", answer: "資料図機能は終了しました。コーデ資料集では、アイテムの組み合わせ・配色・素材・シルエットと、作画メモ・描写メモを引き続き確認できます。" },
];

export default function HelpPage() {
  return (
    <>
      <SiteHeader />
      <main id="main-content" className="shell info-page">
        <header className="info-page-heading">
          <p className="editorial-kicker">HELP & GUIDE</p>
          <h1>はじめての方へ</h1>
          <p>人物像を手がかりに服を探し、キャラクターの資料にまとめるまで。</p>
        </header>
        <ol className="help-steps">
          <li><span>01 / SEARCH</span><h2>人物像を入力する</h2><p>年代・職業・季節などから、ブランドとコーデの候補を探します。</p><Link href="/search">キャラクターから探す</Link></li>
          <li><span>02 / COMPARE</span><h2>違いを見比べる</h2><p>価格帯・テイスト・人物像の解説を、最大4ブランドまで比較できます。</p><Link href="/compare">ブランドを比較する</Link></li>
          <li><span>03 / SAVE</span><h2>キャラクターに保存する</h2><p>「ボードに追加」で候補を保存。人物設定や選んだ理由も一緒に残せます。</p><Link href="/board">キャラクターを管理</Link></li>
        </ol>
        <section className="help-faq" aria-labelledby="faq-title">
          <h2 id="faq-title">よくある質問</h2>
          {questions.map(({ question, answer }) => <details key={question}><summary>{question}</summary><p>{answer}</p></details>)}
        </section>
        <aside className="help-note">
          <h2>大切な設定は、控えを残してください。</h2>
          <p>ブラウザのデータ削除や端末の故障で、保存したキャラクターを失う場合があります。長く使う資料は、Markdown・共有URL・印刷でも保存してください。</p>
        </aside>
        <Link className="info-return-link" href="/"><ArrowLeft size={17} aria-hidden="true" />トップへ戻る</Link>
      </main>
      <SiteFooter />
    </>
  );
}
