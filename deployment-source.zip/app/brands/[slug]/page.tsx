import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowRight, ArrowUpRight, Banknote, CalendarDays, Check, ExternalLink, MapPin, Palette, ShieldCheck, Shirt, Sparkles, Users } from "lucide-react";
import type { CSSProperties } from "react";
import { BrandCard } from "@/components/BrandCard";
import { BoardToggle } from "@/components/BoardToggle";
import { CompareToggle } from "@/components/CompareToggle";
import { PrintButton } from "@/components/PrintButton";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { brands, getBrand, getContrastText, getInitials, getOutfitsForBrand, getRelatedBrands } from "@/lib/brands";
import { SITE_NAME, SITE_URL } from "@/lib/site";

function formatJapaneseDate(value: string) {
  const [year, month, day] = value.split("-").map(Number);
  return `${year}年${month}月${day}日`;
}

export function generateStaticParams() {
  return brands.map((brand) => ({ slug: brand.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }): Promise<Metadata> {
  const { slug } = await params;
  const brand = getBrand(slug);
  if (!brand) return {};
  return {
    title: `${brand.name}｜価格帯・年齢層・着ていそうなキャラ | キャラ服資料館`,
    description: `${brand.name}の価格帯、主な年齢層、テイスト、代表アイテム、着ていそうなキャラクター像を創作者向けに解説。`,
    alternates: { canonical: `/brands/${brand.slug}` },
    openGraph: {
      title: `${brand.name}｜創作者向けブランド資料`,
      description: `${brand.name}の価格帯・年代・人物像・コーデ処方箋を確認できます。`,
      url: `/brands/${brand.slug}`,
      siteName: SITE_NAME,
      locale: "ja_JP",
      type: "article",
      modifiedTime: `${brand.updatedAt}T00:00:00+09:00`,
      images: [{ url: "/og-p0.png", width: 1728, height: 910, alt: `${SITE_NAME} — このキャラなら何を着る？` }],
    },
    twitter: { card: "summary_large_image", title: `${brand.name}｜創作者向けブランド資料`, description: `${brand.name}の価格帯・年代・人物像・コーデ処方箋を確認できます。`, images: ["/og-p0.png"] },
  };
}

export default async function BrandDetailPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const brand = getBrand(slug);
  if (!brand) notFound();
  const related = getRelatedBrands(brand);
  const outfitRecipes = getOutfitsForBrand(brand.slug);
  const confidenceLabel = {
    high: "高（公式確認項目が多い）",
    medium: "中（編集部推定を含む）",
    low: "参考（人物像のヒント）",
  }[brand.confidence];
  const structuredData = [
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      name: `${brand.name}｜創作者向けブランド資料`,
      description: brand.description,
      url: `${SITE_URL}/brands/${brand.slug}`,
      dateModified: brand.updatedAt,
      isPartOf: { "@type": "WebSite", name: SITE_NAME, url: SITE_URL },
      citation: brand.sources.map((source) => source.url),
    },
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "ホーム", item: SITE_URL },
        { "@type": "ListItem", position: 2, name: "ブランド一覧", item: `${SITE_URL}/search` },
        { "@type": "ListItem", position: 3, name: brand.name, item: `${SITE_URL}/brands/${brand.slug}` },
      ],
    },
  ];

  return (
    <>
      <SiteHeader />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData).replaceAll("<", "\\u003c") }} />
      <main id="main-content" className="brand-detail-main" style={{ "--brand-accent": brand.accent, "--brand-on-accent": getContrastText(brand.accent) } as CSSProperties}>
        <section className="brand-detail-hero">
          <div className="shell">
            <div className="breadcrumbs"><Link href="/">ホーム</Link><span>/</span><Link href="/search">ブランド一覧</Link><span>/</span><strong>{brand.name}</strong></div>
            <div className="brand-detail-heading">
              <div className="brand-detail-avatar" aria-hidden="true">{getInitials(brand.name)}</div>
              <div>
                <p className="eyebrow">BRAND FILE / {String(brands.indexOf(brand) + 1).padStart(3, "0")}</p>
                <h1>{brand.name}</h1>
                <div className="detail-tag-row">{brand.tags.slice(0, 4).map((tag) => <span key={tag}>#{tag}</span>)}</div>
              </div>
              <div className="detail-hero-actions">
                <CompareToggle className="compare-button" slug={brand.slug} name={brand.name} />
                <BoardToggle className="board-toggle detail-board-button" type="brand" itemId={brand.slug} itemName={brand.name} />
                <PrintButton className="brand-print-button" label="ブランド資料を印刷" />
                <a className="official-button" href={brand.officialUrl} target="_blank" rel="noreferrer">公式サイトを見る <ExternalLink size={18} aria-hidden="true" /></a>
              </div>
            </div>
          </div>
        </section>

        <div className="shell brand-detail-layout">
          <article className="brand-detail-content">
            <section className="detail-section overview-section">
              <p className="eyebrow">OVERVIEW</p>
              <h2>どんなブランド？</h2>
              <p className="detail-lead">{brand.description}</p>
              <div className="detail-source-summary" role="note">
                <ShieldCheck size={19} aria-hidden="true" />
                <div>
                  <strong>公式情報を確認し、編集部が資料向けに整理</strong>
                  <span>年代・人物像・テイストは目安です。編集データ更新：<time dateTime={brand.updatedAt}>{formatJapaneseDate(brand.updatedAt)}</time></span>
                </div>
                <Link href="#sources">根拠と出典を見る <ArrowRight size={15} aria-hidden="true" /></Link>
              </div>
              <div className="brand-facts">
                <div><Banknote aria-hidden="true" /><small>価格帯</small><strong>{brand.priceLabel}</strong><span className="yen-level">{"¥".repeat(brand.priceLevel)}<i>{"¥".repeat(4 - brand.priceLevel)}</i></span></div>
                <div><Users aria-hidden="true" /><small>主な年齢層</small><strong>{brand.ageRange.join("・")}</strong><span>{brand.genderNote}</span></div>
                <div><Shirt aria-hidden="true" /><small>得意なテイスト</small><strong>{brand.style.join("・")}</strong><span>{brand.scenes.slice(0, 3).join(" / ")}</span></div>
              </div>
            </section>

            <section className="detail-section creator-comment">
              <span className="comment-icon"><Sparkles aria-hidden="true" /></span>
              <div><p className="eyebrow">CREATOR&apos;S NOTE</p><h2>創作者向けコメント</h2><blockquote>「{brand.creatorNote}」</blockquote></div>
            </section>

            <section className="detail-section outfit-recipes-section">
              <div className="detail-section-heading">
                <div><p className="eyebrow">OUTFIT RECIPES / {outfitRecipes.length}</p><h2>季節・シーン別コーデ処方箋</h2></div>
                <div className="outfit-heading-side"><p>アイテム名だけでなく、配色・素材・シルエット・作画の要点までひとまとまりで確認できます。</p><Link href={`/outfits?brand=${brand.slug}`}>コーデ資料で絞り込む <ArrowRight size={15} aria-hidden="true" /></Link></div>
              </div>
              {outfitRecipes.length ? (
                <div className="outfit-recipes-grid">
                  {outfitRecipes.map((outfit) => (
                    <article className="outfit-recipe-card" key={outfit.id}>
                      <div className="outfit-recipe-meta"><span>{outfit.season}</span><span>{outfit.scene}</span></div>
                      <h3>{outfit.title}</h3>
                      <dl className="outfit-parts">
                        {outfit.parts.outer && <div><dt>アウター</dt><dd>{outfit.parts.outer}</dd></div>}
                        <div><dt>トップス</dt><dd>{outfit.parts.top}</dd></div>
                        <div><dt>ボトムス</dt><dd>{outfit.parts.bottom}</dd></div>
                        <div><dt>靴</dt><dd>{outfit.parts.shoes}</dd></div>
                        <div><dt>バッグ</dt><dd>{outfit.parts.bag}</dd></div>
                        {outfit.parts.accessory && <div><dt>小物</dt><dd>{outfit.parts.accessory}</dd></div>}
                      </dl>
                      <div className="outfit-palette">
                        <span><Palette size={15} aria-hidden="true" />配色</span>
                        <div>{outfit.palette.map((color) => <i key={`${outfit.id}-${color.name}`} style={{ background: color.hex }} title={color.name} aria-label={color.name} />)}</div>
                        <small>{outfit.palette.map((color) => color.name).join("・")}</small>
                      </div>
                      <div className="outfit-materials"><strong>素材</strong><span>{outfit.materials.join(" / ")}</span></div>
                      <div className="outfit-silhouette"><strong>シルエット</strong><p>{outfit.silhouette}</p></div>
                      <div className="drawing-tips"><strong>作画ポイント</strong><ul>{outfit.drawingTips.map((tip) => <li key={tip}>{tip}</li>)}</ul></div>
                      <p className="outfit-prose">{outfit.prose}</p>
                      <BoardToggle className="board-toggle outfit-board-toggle print-hidden" type="outfit" itemId={outfit.id} itemName={outfit.title} />
                    </article>
                  ))}
                </div>
              ) : (
                <p className="outfit-empty">このブランドのコーデ処方箋は準備中です。代表アイテムと公式サイトを資料としてご利用ください。</p>
              )}
            </section>

            <section className="detail-section two-column-detail">
              <div>
                <p className="eyebrow">CHARACTER TYPE</p>
                <h2>着ていそうなキャラクター</h2>
                <ul className="check-list">
                  {brand.recommendedFor.map((item) => <li key={item}><Check size={18} aria-hidden="true" />{item}</li>)}
                </ul>
              </div>
              <div>
                <p className="eyebrow">ICONIC ITEMS</p>
                <h2>代表的なアイテム</h2>
                <div className="item-list">
                  {brand.popularItems.map((item, index) => <div key={item}><span>{String(index + 1).padStart(2, "0")}</span><strong>{item}</strong></div>)}
                </div>
              </div>
            </section>

            <section className="detail-section editorial-panel" id="sources">
              <div className="editorial-panel-heading">
                <span><ShieldCheck aria-hidden="true" /></span>
                <div><p className="eyebrow">EDITORIAL POLICY</p><h2>情報の見方と出典</h2></div>
              </div>
              <div className="editorial-facts">
                <div><CalendarDays size={18} aria-hidden="true" /><span>情報更新日</span><strong>{formatJapaneseDate(brand.updatedAt)}</strong></div>
                <div><ExternalLink size={18} aria-hidden="true" /><span>公式リンク確認日</span><strong>{formatJapaneseDate(brand.officialUrlCheckedAt ?? brand.updatedAt)}</strong></div>
                <div><ShieldCheck size={18} aria-hidden="true" /><span>情報の確度</span><strong>{confidenceLabel}</strong></div>
              </div>
              <p className="editorial-note">{brand.editorialNote}</p>
              <div className="source-list">
                <strong>参照先</strong>
                <ul>{brand.sources.map((source) => <li key={`${source.kind}-${source.url}`}><a href={source.url} target="_blank" rel="noreferrer">{source.label}<ArrowUpRight size={15} aria-hidden="true" /></a><span>{source.kind === "official" ? "公式" : "編集資料"}</span></li>)}</ul>
              </div>
              <p className="editorial-disclaimer">ブランド名・商品展開・公式リンクは、ブランド公式サイトまたは公式オンラインストアを{formatJapaneseDate(brand.officialUrlCheckedAt ?? brand.updatedAt)}に確認しています。年代、テイスト、価格帯、人物像などは、掲載商品や公式スタイリングを参考に資料館編集部が独自に整理した目安であり、ブランド公式の見解ではありません。商品・価格・展開内容は時期や店舗により変わります。</p>
            </section>

            <section className="detail-section official-panel">
              <div><p className="eyebrow">SEE WHAT&apos;S IN STORE NOW</p><h2>現在の服を、公式サイトで見る。</h2><p>色・素材・シルエットは毎シーズン変わります。仕上げの資料確認には、公式の最新ラインナップがおすすめです。</p></div>
              <a href={brand.officialUrl} target="_blank" rel="noreferrer">{brand.name} 公式サイト <ArrowUpRight size={20} aria-hidden="true" /></a>
            </section>
          </article>

          <aside className="brand-detail-sidebar">
            <div className="sidebar-card">
              <p className="eyebrow">QUICK PROFILE</p>
              <dl>
                <div><dt>価格</dt><dd>{"¥".repeat(brand.priceLevel)}</dd></div>
                <div><dt>性別</dt><dd>{brand.gender.join("・")}</dd></div>
                <div><dt>シーン</dt><dd>{brand.scenes.slice(0, 4).join("・")}</dd></div>
              </dl>
            </div>
            <div className="sidebar-card map-position-card">
              <p className="eyebrow">MAP POSITION</p>
              <div className="tiny-position-map"><i className="tiny-v" /><i className="tiny-h" /><b style={{ left: `${brand.mapX}%`, top: `${100 - brand.mapY}%`, background: brand.accent }} /></div>
              <div className="tiny-map-labels"><span>きれいめ</span><span>カジュアル</span></div>
              <Link href="/brand-map"><MapPin size={16} aria-hidden="true" />マップで比較する <ArrowRight size={15} aria-hidden="true" /></Link>
            </div>
          </aside>
        </div>

        <section className="related-section">
          <div className="shell">
            <div className="section-heading inline-heading"><div><p className="eyebrow">RELATED BRAND FILES</p><h2>似ているブランド</h2></div><Link href="/search" className="text-link">すべて見る <ArrowRight size={17} aria-hidden="true" /></Link></div>
            <div className="related-grid">{related.map((item) => <BrandCard key={item.slug} brand={item} compact />)}</div>
            <Link href="/search" className="back-link"><ArrowLeft size={17} aria-hidden="true" /> ブランド一覧に戻る</Link>
          </div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
