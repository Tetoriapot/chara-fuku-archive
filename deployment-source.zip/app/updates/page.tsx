import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { SiteHeader } from "@/components/SiteHeader";
import { SiteFooter } from "@/components/SiteFooter";
import { buildPageSocialMetadata } from "@/lib/metadata";
import updates from "@/data/updates.json";

const title = "更新情報 | キャラ服資料館";
const description = "キャラ服資料館の機能追加、改善、変更のお知らせ。";
export const metadata: Metadata = {
  title, description, alternates: { canonical: "/updates" },
  ...buildPageSocialMetadata({ title, description, path: "/updates" }),
};

export default function UpdatesPage() {
  return (
    <>
      <SiteHeader />
      <main id="main-content" className="shell info-page">
        <header className="info-page-heading">
          <p className="editorial-kicker">NEWS & UPDATES</p>
          <h1>更新情報</h1>
          <p>新しい機能や、資料館の使い方に関わる変更をお知らせします。</p>
        </header>
        <ol className="updates-list">
          {[...updates].sort((a, b) => b.date.localeCompare(a.date)).map((update) => (
            <li key={update.id}>
              <article className="update-entry" id={update.id}>
                <time dateTime={update.date}>{update.date.replaceAll("-", ".")}</time>
                <div><h2>{update.title}</h2><ul>{update.changes.map((change) => <li key={change}>{change}</li>)}</ul></div>
              </article>
            </li>
          ))}
        </ol>
        <Link className="info-return-link" href="/"><ArrowLeft size={17} aria-hidden="true" />トップへ戻る</Link>
      </main>
      <SiteFooter />
    </>
  );
}
