import { publicPath } from "@/lib/public-path";
import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight, ArrowUpRight, Search } from "lucide-react";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { brands } from "@/lib/brands";
import { buildPageSocialMetadata } from "@/lib/metadata";
import { outfitRecipeCount } from "@/lib/outfits";
import { SITE_DESCRIPTION, SITE_NAME, SITE_URL } from "@/lib/site";

export const metadata: Metadata = {
  alternates: { canonical: "/" },
  ...buildPageSocialMetadata({ title: "キャラ服資料館｜そのキャラ、何を着る？", description: SITE_DESCRIPTION, path: "/" }),
};

const popularSearches = [
  ["20代女性", "20代 女性 普段着"], ["20代男性", "20代 男性 普段着"],
  ["高校生", "高校生 普段着"], ["大学生", "大学生 普段着"], ["新社会人", "20代 新社会人 通勤"],
];
const styleEdits = [
  { number: "01", title: "CASUAL", label: "気負わない、いつもの服。", query: "カジュアル 普段着", tags: "T-SHIRT / DENIM / SNEAKERS" },
  { number: "02", title: "CLEAN", label: "その人らしい、きちんと感。", query: "きれいめ 通勤", tags: "SHIRT / TROUSERS / LOAFERS" },
  { number: "03", title: "STREET", label: "シルエットで、個性を。", query: "ストリート 普段着", tags: "OVERSIZED / CARGO / CAP" },
];
const featured = brands.filter((brand) => brand.featured).slice(0, 8);
const websiteStructuredData = {
  "@context": "https://schema.org", "@type": "WebSite", name: SITE_NAME, url: SITE_URL, description: SITE_DESCRIPTION,
  potentialAction: { "@type": "SearchAction", target: SITE_URL + "/search?q={search_term_string}", "query-input": "required name=search_term_string" },
};

export default function Home() {
  return (
    <>
      <SiteHeader />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteStructuredData).replaceAll("<", "\\u003c") }} />
      <main id="main-content" className="fashion-home">
        <div className="store-announcement">CHARACTER FASHION ARCHIVE <span>創作者のための、服のリファレンス。</span></div>
        <section className="shell editorial-hero" aria-labelledby="home-title">
          <div className="editorial-copy">
            <p className="editorial-kicker">FIND THEIR EVERYDAY.</p>
            <h1 id="home-title">そのキャラ、<br /><span>何を着る？</span></h1>
            <p className="editorial-lead">年齢も、暮らしも、好きなものも。<br />人物像から見つける、その人らしい服。</p>
            <form action={publicPath("/search")} className="editorial-search">
              <Search size={21} aria-hidden="true" />
              <label className="sr-only" htmlFor="hero-query">キャラクター設定を入力</label>
              <input id="hero-query" name="q" placeholder="例：22歳 女性 大学生 秋" />
              <button type="submit" aria-label="キャラクターから服を探す"><ArrowRight size={21} aria-hidden="true" /></button>
            </form>
            <div className="editorial-shortcuts" aria-label="人物像から探す">
              {popularSearches.map(([label, query]) => <Link key={label} href={`/search?q=${encodeURIComponent(query)}`}>{label}</Link>)}
            </div>
            <Link className="editorial-all-link" href="/outfits">コーデ資料から探す <ArrowUpRight size={17} aria-hidden="true" /></Link>
          </div>
          <nav className="editorial-index" aria-label="収録資料から探す">
            <p className="editorial-index-label">THE ARCHIVE <span>資料をひらく</span></p>
            <Link href="/search" className="editorial-index-entry">
              <span className="editorial-index-number">{String(brands.length).padStart(2, "0")}</span>
              <span className="editorial-index-description"><strong>BRANDS</strong><span>ブランドを探す</span></span>
              <ArrowUpRight size={22} aria-hidden="true" />
            </Link>
            <Link href="/outfits" className="editorial-index-entry">
              <span className="editorial-index-number">{outfitRecipeCount}</span>
              <span className="editorial-index-description"><strong>OUTFITS</strong><span>コーデを探す</span></span>
              <ArrowUpRight size={22} aria-hidden="true" />
            </Link>
            <p className="editorial-index-footer">PERSONALITY. LIFE. STYLE.</p>
          </nav>
        </section>

        <section className="shell style-selection" aria-labelledby="style-title">
          <div className="editorial-section-heading"><div><p className="editorial-kicker">THE STYLE EDIT</p><h2 id="style-title">雰囲気から、選ぶ。</h2></div><Link href="/search">条件を指定して探す <ArrowUpRight size={17} aria-hidden="true" /></Link></div>
          <div className="style-edit-grid">
            {styleEdits.map((style) => <Link className={`style-edit style-edit-${style.number}`} key={style.number} href={`/search?q=${encodeURIComponent(style.query)}`}><div className="style-edit-top"><span>{style.number}</span><ArrowUpRight size={22} aria-hidden="true" /></div><h3>{style.title}</h3><p>{style.label}</p><small>{style.tags}</small></Link>)}
          </div>
        </section>

        <section className="brand-directory-band" aria-labelledby="brand-title">
          <div className="shell">
            <div className="editorial-section-heading"><div><p className="editorial-kicker">BRAND DIRECTORY</p><h2 id="brand-title">ブランドから、広げる。</h2></div><Link href="/search">{brands.length}ブランドをすべて見る <ArrowUpRight size={17} aria-hidden="true" /></Link></div>
            <div className="editorial-brand-grid">{featured.map((brand) => <Link key={brand.slug} href={`/brands/${brand.slug}`}><strong>{brand.name}</strong><span>{brand.style.slice(0, 2).join(" / ")}</span><ArrowUpRight size={18} aria-hidden="true" /></Link>)}</div>
            <div className="editorial-brand-tools"><Link href="/brand-map">価格とテイストで見るブランドマップ <ArrowRight size={17} aria-hidden="true" /></Link><Link href="/compare">ブランドを比較する <ArrowRight size={17} aria-hidden="true" /></Link></div>
          </div>
        </section>

        <section className="shell editorial-about" id="about" aria-labelledby="about-title">
          <div><p className="editorial-kicker">FOR YOUR CHARACTERS</p><h2 id="about-title">服から、<br />人物が見えてくる。</h2></div>
          <div><p>好きな色、服の価格、いつものシルエット。服装の小さな選択が、キャラクターの暮らしを伝えます。</p><p>キャラ服資料館は、創作者のためのリファレンスサイト。{outfitRecipeCount}件のコーデとブランドの解説を、衣装設定の出発点にしてください。</p><div className="editorial-about-links"><Link href="/board">キャラクターを管理 <ArrowUpRight size={18} aria-hidden="true" /></Link><Link href="/help">使い方を見る <ArrowUpRight size={18} aria-hidden="true" /></Link></div></div>
        </section>
      </main>
      <SiteFooter />
    </>
  );
}
