import type { Metadata } from "next";
import { BookmarkCheck } from "lucide-react";
import { CharacterBoardManager, type BoardBrandDTO, type BoardOutfitDTO } from "@/components/CharacterBoardManager";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { brands, outfits } from "@/lib/brands";
import { buildPageSocialMetadata } from "@/lib/metadata";

const title = "キャラクター管理 | キャラ服資料館";
const description = "複数キャラクターの設定、ブランド候補、コーデ候補と選んだ理由を、キャラごとの創作資料にまとめられる端末保存型ボードです。";

export const metadata: Metadata = {
  title,
  description,
  robots: { index: false, follow: true },
  alternates: { canonical: "/board" },
  ...buildPageSocialMetadata({ title, description, path: "/board" }),
};

export default function BoardPage() {
  const brandCatalog: BoardBrandDTO[] = brands.map((brand) => ({
    slug: brand.slug,
    name: brand.name,
    officialUrl: brand.officialUrl,
    priceLabel: brand.priceLabel,
    ageRange: brand.ageRange,
    styles: brand.style,
  }));
  const outfitCatalog: BoardOutfitDTO[] = outfits.map((outfit) => ({
    id: outfit.id,
    title: outfit.title,
    season: outfit.season,
    scene: outfit.scene,
    brandSlugs: outfit.brandSlugs,
    parts: outfit.parts,
    prose: outfit.prose,
  }));

  return (
    <>
      <SiteHeader />
      <main id="main-content" className="subpage-main board-page-main">
        <section className="subpage-hero board-page-hero">
          <div className="shell board-page-hero-inner">
            <div>
              <p className="eyebrow">CHARACTER LIBRARY</p>
              <h1>キャラごとに、似合う服を一枚ずつ。</h1>
              <p>複数のキャラクターを切り替えながら、設定と服装候補をそれぞれの資料ボードにまとめられます。</p>
            </div>
            <span className="board-page-hero-icon" aria-hidden="true"><BookmarkCheck size={36} /></span>
          </div>
        </section>
        <div className="shell board-page-shell">
          <CharacterBoardManager brands={brandCatalog} outfits={outfitCatalog} />
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
