import type { Metadata } from "next";
import { BrandMap } from "@/components/BrandMap";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { brands, filterOptions } from "@/lib/brands";
import { buildPageSocialMetadata } from "@/lib/metadata";

const description = "日本の定番ファッションブランドを、価格帯ときれいめ・カジュアルの2軸で比較できます。";
export const metadata: Metadata = {
  title: "ブランドマップ | キャラ服資料館",
  description,
  alternates: { canonical: "/brand-map" },
  ...buildPageSocialMetadata({ title: "ブランドマップ | キャラ服資料館", description, path: "/brand-map" }),
};

export default function BrandMapPage() {
  const mapBrands = brands.map(({ slug, name, accent, gender, style, priceLevel, mapX, mapY, featured }) => ({ slug, name, accent, gender, style, priceLevel, mapX, mapY, featured }));
  return (
    <>
      <SiteHeader />
      <main className="subpage-main" id="main-content">
        <section className="subpage-hero map-hero">
          <div className="shell">
            <p className="eyebrow">BRAND POSITIONING MAP</p>
            <h1>ブランドマップ</h1>
            <p>上ほど価格が高め、右ほどカジュアル。スマートフォンでは同じ位置情報を4分類で見やすく表示します。</p>
          </div>
        </section>
        <div className="shell"><BrandMap mapBrands={mapBrands} styleOptions={filterOptions.styles} /></div>
      </main>
      <SiteFooter />
    </>
  );
}
