import type { Metadata } from "next";
import { CompareTray } from "@/components/CompareTray";
import { brands } from "@/lib/brands";
import { SITE_DESCRIPTION, SITE_NAME, SITE_URL } from "@/lib/site";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: "キャラ服資料館｜このキャラなら何を着る？",
  description: SITE_DESCRIPTION,
  keywords: ["キャラクターデザイン", "ファッション資料", "ブランド", "創作", "衣装設定"],
  openGraph: {
    title: "キャラ服資料館｜そのキャラ、何を着る？",
    description: SITE_DESCRIPTION,
    url: SITE_URL,
    siteName: SITE_NAME,
    locale: "ja_JP",
    type: "website",
    images: [{ url: "/og-p0.png", width: 1728, height: 910, alt: "キャラ服資料館 — このキャラなら何を着る？" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "キャラ服資料館｜そのキャラ、何を着る？",
    description: SITE_DESCRIPTION,
    images: ["/og-p0.png"],
  },
};

const themeScript = `
  let saved = null;
  try { saved = localStorage.getItem('theme'); } catch (_) {}
  const dark = saved === 'dark' || (saved !== 'light' && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
`;

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  const compareCatalog = brands.map(({ slug, name }) => ({ slug, name }));
  return (
    <html lang="ja" suppressHydrationWarning>
      <head><script dangerouslySetInnerHTML={{ __html: themeScript }} /></head>
      <body>
        <a className="skip-link" href="#main-content">本文へ移動</a>
        {children}
        <CompareTray catalog={compareCatalog} />
      </body>
    </html>
  );
}
