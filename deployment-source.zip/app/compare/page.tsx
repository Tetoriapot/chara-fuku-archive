import type { Metadata } from "next";
import { Suspense } from "react";
import { StaticBrandCompare } from "@/components/StaticQueryPages";
import Link from "next/link";
import { ArrowLeftRight, ArrowRight } from "lucide-react";
import { BrandCompare } from "@/components/BrandCompare";
import { SiteFooter } from "@/components/SiteFooter";
import { SiteHeader } from "@/components/SiteHeader";
import { normalizeCompareSlugs } from "@/lib/compare";
import { buildPageSocialMetadata } from "@/lib/metadata";

const description = "最大4ブランドの価格帯、年代、テイスト、人物像、代表アイテムを並べて比べられる創作者向け比較ページ。";
export const metadata: Metadata = {
  title: "ブランドを比較 | キャラ服資料館",
  description,
  alternates: { canonical: "/compare" },
  ...buildPageSocialMetadata({ title: "ブランドを比較 | キャラ服資料館", description, path: "/compare" }),
};

export default async function ComparePage({
  searchParams,
}: {
  searchParams: Promise<{ brands?: string | string[] }>;
}) {
  const isStatic = process.env.NEXT_PUBLIC_STATIC_EXPORT === "true";
  const params = isStatic ? {} : await searchParams;
  const initialSlugs = normalizeCompareSlugs(params.brands);

  return (
    <>
      <SiteHeader />
      <main id="main-content" className="subpage-main compare-page-main">
        <section className="subpage-hero compare-hero">
          <div className="shell compare-hero-inner">
            <div>
              <p className="eyebrow">BRAND COMPARISON</p>
              <h1>ブランドを、同じ物差しで。</h1>
              <p>値段だけでなく、似合う年代・人物像・シーンまで並べると、キャラクターが選ぶ理由が見えてきます。</p>
            </div>
            <span className="compare-hero-icon" aria-hidden="true"><ArrowLeftRight size={34} /></span>
          </div>
        </section>
        <div className="shell">
          {isStatic
            ? <Suspense fallback={<p role="status">比較するブランドを読み込んでいます。</p>}><StaticBrandCompare /></Suspense>
            : <BrandCompare initialSlugs={initialSlugs} restoreStoredSelection={params.brands === undefined} />}
          <nav className="compare-related-links" aria-label="関連ページ">
            <Link href="/brand-map">価格×テイストのブランドマップを見る <ArrowRight size={16} aria-hidden="true" /></Link>
            <Link href="/search">キャラクター設定から探す <ArrowRight size={16} aria-hidden="true" /></Link>
          </nav>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
