import { spawnSync } from "node:child_process";
import { writeFileSync } from "node:fs";

const repository = process.env.GITHUB_REPOSITORY || "Tetoriapot/chara-fuku-archive";
const [owner, name] = repository.split("/");
const basePath = name.toLowerCase() === `${owner.toLowerCase()}.github.io` ? "" : `/${name}`;
const env = {
  ...process.env,
  NEXT_PUBLIC_STATIC_EXPORT: "true",
  NEXT_PUBLIC_BASE_PATH: process.env.NEXT_PUBLIC_BASE_PATH ?? basePath,
  NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL || `https://${owner.toLowerCase()}.github.io${basePath}`,
  NEXT_TELEMETRY_DISABLED: "1",
};

for (const args of [["scripts/generate-catalog-index.mjs"], ["node_modules/next/dist/bin/next", "build", "--webpack"]]) {
  const result = spawnSync(process.execPath, args, { stdio: "inherit", env });
  if (result.error) throw result.error;
  if (result.status !== 0) process.exit(result.status || 1);
}
writeFileSync("out/.nojekyll", "");
