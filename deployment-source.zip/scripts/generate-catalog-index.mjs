import { readFile, writeFile } from "node:fs/promises";
import { listOutfitSourceNames } from "./outfit-source-files.mjs";

const root = new URL("../", import.meta.url);
const dataDirectory = new URL("data/", root);
const outfitSourceNames = await listOutfitSourceNames(dataDirectory);

const [brands, outfitCollections] = await Promise.all([
  readFile(new URL("brands.json", dataDirectory), "utf8").then(JSON.parse),
  Promise.all(
    outfitSourceNames.map(async (name) => {
      const collection = JSON.parse(await readFile(new URL(name, dataDirectory), "utf8"));
      if (!Array.isArray(collection)) throw new TypeError(`${name} must contain a JSON array`);
      return collection;
    }),
  ),
]);
const outfits = outfitCollections.flat();
if (!Array.isArray(brands)) throw new TypeError("brands.json must contain a JSON array");

const duplicates = (values) => values.filter((value, index) => values.indexOf(value) !== index);
const duplicateBrandSlugs = [...new Set(duplicates(brands.map((brand) => brand.slug)))];
const duplicateOutfitIds = [...new Set(duplicates(outfits.map((outfit) => outfit.id)))];
if (duplicateBrandSlugs.length) throw new Error(`Duplicate brand slugs: ${duplicateBrandSlugs.join(", ")}`);
if (duplicateOutfitIds.length) throw new Error(`Duplicate outfit IDs: ${duplicateOutfitIds.join(", ")}`);

const knownBrandSlugs = new Set(brands.map((brand) => brand.slug));
const unknownBrandSlugs = [...new Set(
  outfits.flatMap((outfit) => outfit.brandSlugs ?? []).filter((slug) => !knownBrandSlugs.has(slug)),
)];
if (unknownBrandSlugs.length) throw new Error(`Unknown outfit brand slugs: ${unknownBrandSlugs.join(", ")}`);

async function writeWhenChanged(target, output) {
  let current = "";
  try {
    current = await readFile(target, "utf8");
  } catch {
    // 初回生成時は空として扱います。
  }
  if (current !== output) await writeFile(target, output, "utf8");
}

await writeWhenChanged(
  new URL("outfits.generated.json", dataDirectory),
  `${JSON.stringify(outfits, null, 2)}\n`,
);

const output = `${JSON.stringify({
  brandSlugs: brands.map((brand) => brand.slug),
  outfitIds: outfits.map((outfit) => outfit.id),
}, null, 2)}\n`;
await writeWhenChanged(new URL("catalog-index.json", dataDirectory), output);
