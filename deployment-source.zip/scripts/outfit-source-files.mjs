import { readdir } from "node:fs/promises";

const sourcePattern = /^outfits(?:-[a-z0-9-]+)?\.json$/;
const generatedName = "outfits.generated.json";

export async function listOutfitSourceNames(dataDirectory) {
  const names = await readdir(dataDirectory);
  const outfitJsonNames = names.filter((name) => /^outfits.*\.json$/.test(name));
  const unrecognizedNames = outfitJsonNames.filter(
    (name) => name !== generatedName && !sourcePattern.test(name),
  );
  if (unrecognizedNames.length) {
    throw new Error(
      `Unrecognized outfit data filenames: ${unrecognizedNames.join(", ")}. Use outfits-任意の名前.json.`,
    );
  }

  return outfitJsonNames
    .filter((name) => sourcePattern.test(name))
    .sort((first, second) => {
      if (first === "outfits.json") return -1;
      if (second === "outfits.json") return 1;
      return first.localeCompare(second);
    });
}
